from django.db import models
from django.contrib.auth.models import User
from PIL import Image
import cv2
# Create your models here.
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete = models.CASCADE)
    image = models.ImageField(default = 'default.jpg', upload_to ='profile_pics')
    def __str__(self):
        return f'{self.user.username} Profile'

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        
        img = cv2.imread(self.image.path)
        if img.shape[0] > 300 or img.shape[1] > 300:
            img = cv2.resize(img,(0,0), fx = 0.25,fy = 0.25 )
            cv2.imwrite(self.image.path, img)
            
            
           
            

            
    


    

   
