import numpy as np
import math
from collections import deque
import cv2
from scipy import ndimage as nd

lidar_array = np.arange(1,10,1)
sin_array = np.sin(lidar_array)
cos_array = np.cos(lidar_array)
array = [1,4,2,5,7,6,4,8,3]
array = np.array(array).reshape(9)
new_array = sin_array*array
new_array2 = cos_array*array
new_array2 = new_array2.reshape((9,1))

new_array2 = np.insert(new_array2, 1, new_array, axis =1)
print(new_array)
print("array2")
print(new_array2)
array3 = np.array(([[2],[3]],[[6],[7]],[[10],[7]]))
a = np.array(([[9],[10]],[[5],[3]])).reshape((2,2))
for k,j in enumerate(array3):
    print(j.shape)
    print(a.shape)
    array3[k] = np.dot(a,j)
print(array3)
array4 = np.array(([11,8,9,0,8,11,8,7],[9,8,9,0,6,11,8,7]))
item_indexs = np.where(array4 == 8)
print(item_indexs[0])
moi = np.array(item_indexs[0]).reshape((len(item_indexs[0]),1))
new_matrix = np.insert(moi,1, item_indexs[1],axis = 1)
print("new{}".format(new_matrix[0]))
print ("result: {}".format(item_indexs[0]))
list_color = np.random.randint(255, size = (10,3))
print(list_color[0])
array = [1,3,2,1]
unique, count = np.unique(array, return_counts = True)
print(count)
array3 = np.array(([2,4], [7,8], [9,5], [1,3], [7,6]))
mean_val = np.mean(array3, axis = 0)
array_1, array_2 = np.split(array3,2, axis = 1)
print (array_1)

eig_matrix = np.array([[2,3],[3,4]])
eigh = np.linalg.eigvals(eig_matrix)
print(eigh)
print(np.array([[1,2,1]]).shape)
distribution1 = {
    "mean": np.array([[1,1]]),
    "covariance": np.array([[1, 0.1], [0.1, 1]]),
}


# Distribution 2
distribution2 = {
    "mean": np.array([[1,3]]),
    "covariance": np.array([[1, 0.5], [0.5, 1]]),
}
def bhattacharyya_gaussian_distance(distribution1: "dict", distribution2: "dict",) -> int:
    """ Estimate Bhattacharyya Distance (between Gaussian Distributions)
    
    Args:
        distribution1: a sample gaussian distribution 1
        distribution2: a sample gaussian distribution 2
    
    Returns:
        Bhattacharyya distance
    """
    mean1 = distribution1["mean"]
    print(mean1.shape)
    cov1 = distribution1["covariance"]
    mean2 = distribution2["mean"]
    cov2 = distribution2["covariance"]

    cov = (1 / 2) * (cov1 + cov2)

    T1 = (1 / 8) * (
        np.sqrt((mean1 - mean2) @ np.linalg.inv(cov) @ (mean1 - mean2).T)[0][0]
    )
    T2 = (1 / 2) * np.log(
        np.linalg.det(cov) / np.sqrt(np.linalg.det(cov1) * np.linalg.det(cov2))
    )
    return T1 + T2
print(bhattacharyya_gaussian_distance(distribution1, distribution2))
number = np.array([[3],[5]])
a = np.array([[0, 0, 10, 0, 0, 0, 0],
              [0, 10, 0, 10, 0, 0, 0],
              [10, 0, 0, 0, 10, 0, 0],
              [0, 10, 0, 0, 10, 0, 0],
              [0, 10, 0, 0, 10, 0, 0],
              [0, 0, 10, 0, 0, 0, 0],
              [0, 0, 10, 0, 0, 0, 0],
              [0, 10, 0, 10, 0, 0, 0]])
po = np.zeros((10,10))
po[2][3] = 10
po[7][8] = 10
po[4][9] = 10
def fill_contours_fixed(arr):
    return np.maximum.accumulate(arr, 1) &\
           np.maximum.accumulate(arr[:, ::-1], 1)[:, ::-1] &\
           np.maximum.accumulate(arr[::-1, :], 0)[::-1, :] &\
           np.maximum.accumulate(arr, 0)
array_moi = cv2.GaussianBlur(po,(3,3),0)
print(array_moi)
