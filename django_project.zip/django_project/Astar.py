import subprocess
import signal

import time

cmd = ["roslaunch","mir_navigation","save_map.launch"]
proc = subprocess.Popen(cmd)
time.sleep(10)
#proc.kill()
