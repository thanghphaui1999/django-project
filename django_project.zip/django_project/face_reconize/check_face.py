from deepface import DeepFace
import cv2
import numpy as np
import time
video = cv2.VideoCapture(0)
template_image = "./src/django_project/face_reconize/face_database/template_1.jpg"
database_file = "./src/django_project/face_reconize/face_database/"


while(1):
    if video.isOpened() == True:
        ret, image = video.read()
        cv2.imshow("check_face", image)
        k = cv2.waitKey(1) & 0xff
        if k == ord('c') or k == ord('C'):
            cv2.imwrite( "./src/django_project/face_reconize/face_database/check.jpg",image)
            check_image = image
            break
cv2.destroyAllWindows()
start_time = time.time()
result_val = DeepFace.verify(template_image, database_file + "check.jpg" )

finish_time = time.time()
process_time = finish_time - start_time
print(result_val)






