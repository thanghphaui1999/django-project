import cv2

video = cv2.VideoCapture(0)
#video.set(cv2.CAP_PROP_FRAME_HEIGHT,720)


filename = './src/django_project/face_reconize/face_database/savedImage.jpg'
while(1):
    ret, image = video.read()
    if ret:

        cv2.imshow("face_capture",image)
        
        k = cv2.waitKey(1) & 0xff
        if k == ord('c'):
            cv2.imwrite(filename,image)
            print(image.shape)
            print("save_done")
            
        elif k == ord('s') or k == ord('S'):
            break
    else:
        print("cannot open camera")
video.release()
cv2.destroyAllWindows()
