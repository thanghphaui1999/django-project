import yaml
dic_val = {"image": "anh1.png", "height": "100px", "width": "100px","resolution": 1}

with open('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml', "r") as yamlfile:
    data = yaml.load(yamlfile, Loader=yaml.FullLoader)
    yamlfile.close()
for x,y in data.items():
    for i,j in dic_val.items():
        if x == i:
            data[x] = j
print(data)

