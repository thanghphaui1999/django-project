from django.urls import path
from . import views

urlpatterns = [
    path('chat_view/',views.view_chat),
    path('chat_moi/', views.room, name='room')
]