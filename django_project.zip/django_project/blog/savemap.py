import cv2
import numpy as np
import os
import glob
save_dir = "/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/mapmoi.png"
class save_last_image():
    def modify_last_map(self,dir_name,save_dir):
        image = cv2.imread(dir_name)
        save_image = np.where(image == 2,255, image)
        save_map = cv2.resize(save_image,(0,0),fx = 2, fy = 2)
        cv2.imwrite(save_dir, save_map)
    def savemap(self):
        list_index = []
        all_image = glob.glob(
            "/home/thang/catkin_ws/src/django_project/blog/static/blog/assets/map/*.png")
        last_image = all_image[-1]
        for i in all_image:
            index_image = i.split("_")[-1].split(".")[0]
            index_image = int(index_image)
            list_index.append(index_image)
        list_index_array = np.array(list_index)
        max_val = np.max(list_index_array)
        print(max_val)
        max_arg = np.where(list_index_array == max_val-2)
        print(all_image[max_arg[0][0]])
        self.modify_last_map(all_image[max_arg[0][0]],save_dir)

