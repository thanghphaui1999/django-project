import numpy as numpy

angles = numpy.arange(135,-135,-0.5)
print(angles.shape)
for i,j in enumerate(angles):
    print(i)
    print(j)