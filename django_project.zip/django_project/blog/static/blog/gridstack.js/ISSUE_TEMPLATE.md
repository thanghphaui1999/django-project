## Subject of the issue
Describe your issue here.

## Your environment
* version of gridstack.js
* which browser and its version

## Steps to reproduce
Tell us how to reproduce this issue. Please provide a working demo, you can use [this template](https://jsfiddle.net/adumesny/jqhkry7g) as a base.

## Expected behaviour
Tell us what should happen

## Actual behaviour
Tell us what happens instead
