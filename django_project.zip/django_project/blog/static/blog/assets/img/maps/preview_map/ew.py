import cv2
import numpy as np
img = cv2.imread('/home/thang/catkin_ws/src.pgm')
try:
    
    cv2.imwrite('/home/thang/catkin_ws/src10.png',img)
    print("ok")
except:
    print("error")

print('done')
