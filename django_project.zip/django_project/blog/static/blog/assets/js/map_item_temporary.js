/**
 * @author Nguyen Viet Thang
 */
var TEM_DATA = TEM_DATA || {
    REVISION: '0.1.0'
};

/**
* Temporary memory for update node database
*
* @constructor
* @param options - object with following keys:
    *   * Maxsize (optional) - the maximum number of node for each update time
  
*/

TEM_DATA.Nodes_update = function (options) {
    var that = this;
    this.Maxsize = options.Maxsize || 100
    this.num_node = 0;
    this.Type_nodes = [];
    this.Id_nodes = [];
    this.X_nodes = [];
    this.Y_nodes = [];
    this.Turn_nodes = [];
    this.Nodes_list = [];
    this.Nodes_list_name = [];
   
}
TEM_DATA.Nodes_update.prototype.Nodes_update_map = function (node,name) {
    this.Nodes_list.push(node);
    this.Nodes_list_name.push(name);

}
TEM_DATA.Nodes_update.prototype.Number_nodes = function () {
    return this.num_node
}
TEM_DATA.Nodes_update.prototype.Remove_a_node = function (node_name) {
    var index_node = this.Nodes_list_name.indexOf(node_name);
    this.Nodes_list.splice(index_node,1);
    this.num_node -= 1;

}
TEM_DATA.Nodes_update.prototype.Update_new_node = function (Type, Id, X_coor, Y_coor,Turn) {
    if (this.num_node <= this.Maxsize) {
        this.num_node += 1;
        this.Type_nodes.push(Type);
        this.Id_nodes.push(Id);
        this.X_nodes.push(X_coor);
        this.Y_nodes.push(Y_coor);
        this.Turn_nodes.push(Turn);
    }
    else {
        alert("Don't have enough room for new node")
    }
}
TEM_DATA.Nodes_update.prototype.Remove_all = function () {
    var that = this;
    this.num_item = 0;
    this.Type_nodes = [];
    this.Id_nodes = [];
    this.X_nodes = [];
    this.Y_nodes = [];
    this.Turn_nodes = [];
}
/**
* Temporary memory for update link database
*
* @constructor
* @param options - object with following keys:
    *   * Maxsize (optional) - the maximum number of link for each update time
  
*/
TEM_DATA.Links_update = function (options) {
    this.Maxsize = options.Maxsize || 100;
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Start_nodes = [];
    this.End_nodes = [];
    this.Dis_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.V_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.FB_links = [];
    this.V_Dir_links = [];
    
}
TEM_DATA.Links_update.prototype.Update_new_link = function (Type, ID, Start, End, Ir_f, Ir_b, Ir_l, Ir_r, V, Turn,Distance,Dir, E_Dir,FB,V_Dir) {
    if (this.num_item <= this.Maxsize) {
        this.num_item += 1;
        this.Type_links.push(Type);
        this.Turn_links.push(Turn);
        this.Start_nodes.push(Start);
        this.End_nodes.push(End);
        this.Id_links.push(ID);
        this.Ir_f_links.push(Ir_f);
        this.Ir_b_links.push(Ir_b);
        this.Ir_l_links.push(Ir_l);
        this.Ir_r_links.push(Ir_r);
        this.V_links.push(V);
        this.Dir_links.push(Dir);
        this.E_Dir_links.push(E_Dir);
        this.Dis_links.push(Distance);
        this.FB_links.push(FB);
        this.V_Dir_links.push(V_Dir);
    }
    else
    {
        alert("Don't have enough room for new link");


    }

}
TEM_DATA.Links_update.prototype.Remove_a_link = function()
{
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Start_nodes = [];
    this.End_nodes = [];
    this.Dis_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.V_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.FB_links = [];
    this.V_Dir_links = [];
}
TEM_DATA.Links_update.prototype.Remove_all = function()
{
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Start_nodes = [];
    this.End_nodes = [];
    this.Dis_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.V_links = [];
    this.FB_links = [];
    this.V_Dir_links = []
}
/**
* Temporary memory for update lock zone database
*
* @constructor
* @param options - object with following keys:
    *   * Maxheight (optional) - the maximum height of link for each update time
    *   * Maxwidth (optional) - the maxium width of link for each update time
*/
TEM_DATA.Lockzone_update = function () {

}
/**
* Temporary memory for update link database
*
* @constructor
* @param options - object with following keys:
    *   * Maxsize (optional) - the maximum number of link for each update time
  
*/
TEM_DATA.Links_modify = function (options) {
    this.Maxsize = options.Maxsize || 100;
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.V_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.FB_links = [];
    this.V_Dir_links = [];
}
TEM_DATA.Links_modify.prototype.Update_new_link = function (Type, ID, Ir_f, Ir_b, Ir_l, Ir_r, V, Turn,Dir, E_dir,FB,V_dir) {
    if (this.num_item <= this.Maxsize) {
        this.num_item += 1;
        this.Type_links.push(Type);
        this.Turn_links.push(Turn);
        this.Id_links.push(ID);
        this.Ir_f_links.push(Ir_f);
        this.Ir_b_links.push(Ir_b);
        this.Ir_l_links.push(Ir_l);
        this.Ir_r_links.push(Ir_r);
        this.V_links.push(V);
        this.Dir_links.push(Dir);
        this.E_Dir_links.push(E_dir);
        this.FB_links.push(FB);
        this.V_Dir_links.push(V_dir);
      
    }
    else
    {
        alert("Don't have enough room for new link");


    }

}
TEM_DATA.Links_modify.prototype.Remove_a_link = function()
{
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.V_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.FB_links = [];
    this.V_Dir_links = [];

}
TEM_DATA.Links_modify.prototype.Remove_all = function()
{
    this.num_item = 0;
    this.Type_links = [];
    this.Turn_links = [];
    this.Id_links = [];
    this.Ir_f_links = [];
    this.Ir_b_links = [];
    this.Ir_l_links = [];
    this.Ir_r_links = [];
    this.V_links = [];
    this.Dir_links = [];
    this.E_Dir_links = [];
    this.FB_links = [];
    this.V_Dir_links = [];
}