
/**
 * @author Russell Toris - rctoris@wpi.edu
 */

var ROS2D = ROS2D || {
  REVISION: '0.9.0'
};

// convert the given global Stage coordinates to ROS coordinates
createjs.Stage.prototype.globalToRos = function (x, y) {
  var rosX = (x - this.x) / this.scaleX;
  var rosY = (this.y - y) / this.scaleY;
  return new ROSLIB.Vector3({
    x: rosX,
    y: rosY
  });
};

// convert the given ROS coordinates to global Stage coordinates
createjs.Stage.prototype.rosToGlobal = function (pos) {
  var x = pos.x * this.scaleX + this.x;
  var y = pos.y * this.scaleY + this.y;
  return {
    x: x,
    y: y
  };
};

/**
* A Viewer can be used to render an interactive 2D scene to a HTML5 canvas.
*
* @constructor
* @param options - object with following keys:
    *   * size (optional) - the size of the marker
    *   * strokeSize (optional) - the size of the outline
    *   * strokeColor (optional) - the createjs color for the stroke
    *   * fillColor (optional) - the createjs color for the fill
    *   * width (optional) - the createjs width for area
    *   * length (optional) - the createjs length for area
    *   * callback (otional) - the callback function for press event
*/
ROS2D.Rect_area = function (options) {
  var that = this;
  options = options || {};
  var size = options.size || 10;
  this.strokeSize = options.strokeSize || 0.1;
  this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
  this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0);
  this.width = options.width || 0.5;
  this.length = options.length || 0.5;
  this.callback = options.callback
  this.shape = new createjs.Shape();
  this.shape.name = "rect";
  this.shape.on("pressmove", this.callback)
  this.shape.graphics.clear();
  this.shape.graphics.setStrokeStyle(this.strokeSize);
  this.shape.graphics.beginStroke(this.strokeColor);
  this.shape.graphics.beginFill(this.fillColor);
  this.shape.graphics.drawRect(0 - this.width / 2, 0 - this.length / 2, this.width, this.length);
  this.shape.graphics.endStroke();
  this.shape.graphics.endFill();
};
/**
* A Viewer can be used to render an interactive 2D scene to a HTML5 canvas.
*
* @constructor
* @param options - object with following keys:
  *   * size (optional) - the size of the marker
  *   * strokeSize (optional) - the size of the outline
  *   * strokeColor (optional) - the createjs color for the stroke
  *   * fillColor (optional) - the createjs color for the fill
  *   * radius (optional) - the createjs radius
  *   * rootObject (optional) - the createjs rootObject
  *   * callback (optional) - the callback function  for press event
  
*/
ROS2D.Circle_area = function (options) {
  var that = this;
  options = options || {};
  var size = options.size || 10;
  this.strokeSize = options.strokeSize || 0.1;
  this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
  this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0);
  this.rootObject = options.rootObject || new createjs.Container();
  this.callback = options.callback
  this.radius = options.radius || 0.5;
  this.shape = new createjs.Shape();
  this.shape.name = "circle"
  this.shape.on("pressmove", this.callback);
  this.shape.graphics.clear();
  this.shape.graphics.setStrokeStyle(this.strokeSize);
  this.shape.graphics.beginStroke(this.strokeColor);
  this.shape.graphics.beginFill(this.fillColor)
  this.shape.graphics.drawCircle(0, 0, this.radius);
  this.shape.graphics.endStroke();
  this.shape.graphics.endFill();

};
/**
* A Viewer can be used to render an interactive 2D scene to a HTML5 canvas.
*
* @constructor
* @param options - object with following keys:
   *   * size (optional) - the size of the marker
   *   * strokeSize (optional) - the size of the outline
   *   * strokeColor (optional) - the createjs color for the stroke
   *   * fillColor (optional) - the createjs color for the fill
   *   * length (optional) - the createjs length of the shape
   *   * width (optional) - the createjs width of the shape.
   *   * rootObject (optional) - the createjs root for shape.
   *   * callback (optional) -the callback function for press event
*/
ROS2D.Elipse_area = function (options) {

  var that = this;
  options = options || {};
  var size = options.size || 10;
  this.strokeSize = options.strokeSize || 0.1;
  this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
  this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0);
  this.width = options.width || 0.5;
  this.length = options.length || 0.2;
  this.callback = options.callback
  //this.rootObject = options.rootObject || new createjs.Container();
  this.shape = new createjs.Shape();
  this.shape.name = "elipse";
  this.shape.on("pressmove", this.callback);
  this.shape.graphics.clear();
  this.shape.graphics.setStrokeStyle(this.strokeSize);
  this.shape.graphics.beginStroke(this.strokeColor);
  this.shape.graphics.beginFill(this.fillColor)
  this.shape.graphics.drawEllipse(0 - this.width / 2, 0 - this.length / 2, this.width, this.length);
  this.shape.graphics.endStroke();
  this.shape.graphics.endFill();
  //this.rootObject.addChild(this.shape);


}


/**
 * @author Bart van Vliet - bart@dobots.nl
 */

/**
* A polygon that can be edited by an end user
*
* @constructor
* @param options - object with following keys:
*   * pose (optional) - the first pose of the trace
*   * lineSize (optional) - the width of the lines
*   * lineColor (optional) - the createjs color of the lines
*   * pointSize (optional) - the size of the points
*   * pointColor (optional) - the createjs color of the points
*   * fillColor (optional) - the createjs color to fill the polygon
*   * pointCallBack (optional) - callback function for mouse interaction with a point
*   * rootObject (optional) - Set up rootObject for shape
*   * drag (optional) - callback function for mouse interaction with a point
*/
ROS2D.Line_draw = function (options) {
  //	var that = this;
  options = options || {};
  this.lineSize = options.lineSize || 0.1;
  this.lineColor = options.lineColor || createjs.Graphics.getRGB(0, 0, 255);
  this.pointSize = options.pointSize || 10;
  this.pointColor = options.pointColor || createjs.Graphics.getRGB(255, 0, 0);
  this.fillColor = options.pointColor || createjs.Graphics.getRGB(0, 255, 0, 0.33);
  this.pointCallBack = options.pointCallBack;
  this.rootObject = options.rootObject;
  this.drag = options.drag;

  // Array of point shapes
  //	this.points = [];
  this.pointContainer = new createjs.Container();
  this.lineContainer = new createjs.Container();
  // Container with all the lines and points
  createjs.Container.call(this);
  this.addChild(this.lineContainer);
  this.addChild(this.pointContainer);
};
ROS2D.Line_draw.prototype.addStartPoint = function (input_point) {
  var name = "first";
  var point = this.createPointShape(input_point, name);
  this.pointContainer.addChild(point);
}
ROS2D.Line_draw.prototype.add_Line = function (input_point) {
  var name = "second";

  var point = this.createPointShape(input_point, name);
  this.pointContainer.addChild(point);
  var line = this.createLineShape(this.pointContainer.getChildAt(0), point);
  this.lineContainer.addChild(line);
}



/**
* Internal use only
*/
ROS2D.Line_draw.prototype.createLineShape = function (startPoint, endPoint) {
  var line = new createjs.Shape();
  //	line.graphics.setStrokeStyle(this.strokeSize);
  //	line.graphics.beginStroke(this.strokeColor);
  //	line.graphics.moveTo(startPoint.x, startPoint.y);
  //	line.graphics.lineTo(endPoint.x, endPoint.y);

  this.editLineShape(line, startPoint, endPoint);

  var that = this;

  return line;
};

/**
* Internal use only
*/
ROS2D.Line_draw.prototype.editLineShape = function (line, startPoint, endPoint) {
  line.graphics.clear();
  line.graphics.setStrokeStyle(this.lineSize);
  line.graphics.beginStroke(this.lineColor);
  line.graphics.moveTo(startPoint.x, startPoint.y);
  line.graphics.lineTo(endPoint.x, endPoint.y);
};
/** 
 * Internal use only
*/
ROS2D.Line_draw.prototype.drag_line = function (evt) {

  this.drag(evt);

  //this.rootObject.update();
}

/**
* Internal use only
*/
ROS2D.Line_draw.prototype.createPointShape = function (pos, name) {
  var point = new createjs.Shape();
  this.rootObject.update();
  point.graphics.beginFill(this.pointColor);
  point.graphics.drawCircle(0, 0, this.pointSize);
  point.on("pressmove", this.drag);
  point.x = pos.x;
  point.y = -pos.y;
  point.name = name;
  var that = this;
  point.addEventListener('mousedown', function (event) {
    if (that.pointCallBack !== null && typeof that.pointCallBack !== 'undefined') {
      that.pointCallBack('mousedown', event, that.pointContainer.getChildIndex(event.target));
    }
  });

  return point;
};


/**
* Splits a line of the polygon: inserts a point at the center of the line
*
* @param obj either an index (integer) or a line shape of the polygon
*/

ROS2D.Line_draw.prototype.__proto__ = createjs.Container.prototype;






/**
* Add a line on top of the map
*
* @constructor
* @param options - object with following keys:

 *   * strokeSize (optional) - the size of the outline
 *   * strokeColor (optional) - the createjs color for the stroke
 *   * rootObject (optional) - the createjs root for shape.
 *   * startPoint (optional) - the start point of line
 *   * endPoint (optional) - the end point of line.
*/
ROS2D.Line_area = function (options) {

  var that = this;
  options = options || {};
  this.strokeSize = options.strokeSize || 0.1;
  this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
  this.rootObject = options.rootObject || new createjs.Container();
  this.startPoint = options.startPoint || new createjs.Point(0, 0);
  this.endPoint = options.endPoint || new createjs.Point(0, 0);
  //this.rootObject = options.rootObject || new createjs.Container();
  this.shape = new createjs.Shape();
  this.shape.graphics.clear();
  this.shape.graphics.setStrokeStyle(this.strokeSize);
  this.shape.graphics.beginStroke(this.strokeColor);
  this.shape.graphics.moveTo(this.startPoint.x, this.startPoint.y);
  this.shape.graphics.lineTo(this.endPoint.x, this.endPoint.y);


  //this.rootObject.addChild(this.shape);


}

/**
* Add a ruler on top of the map
*
* @constructor
* @param options - object with following keys:
*   * pose (optional) - the first pose of the trace
*   * rulerSize (optional) - the width of the lines
*   * rulerColor (optional) - the createjs color of the lines
*   * pointSize (optional) - the size of the points
*   * pointColor (optional) - the createjs color of the points
*   * pointCallBack (optional) - callback function for mouse interaction with a point
*   * rootObject (optional) - Set up rootObject for shape
*   * drag (optional) - callback function for mouse interaction with a point
*   * textDistance (optional) - text distance to line.
*   * scalText (optional) - size of text

*/
ROS2D.Ruler_draw = function (options) {
  //	var that = this;
  options = options || {};
  this.rulerSize = options.rulerSize || 0.1;
  this.rulerColor = options.rulerColor || createjs.Graphics.getRGB(0, 0, 255);
  this.pointSize = options.pointSize || 2;
  this.pointColor = options.pointColor || createjs.Graphics.getRGB(255, 0, 0);
  this.textDistance = options.textDistance || 0.5;
  this.pointCallBack = options.pointCallBack;
  this.rootObject = options.rootObject;
  this.scaleText = options.scaleText || 0.5;
  this.drag = options.drag;
  this.radius_text = "";
  this.length_text = "";
  this.pointContainer = new createjs.Container();
  this.lineContainer = new createjs.Container();
  this.textContainer = new createjs.Container();
  this.textDistance_below = 0.8;
  // Container with all the lines and points
  createjs.Container.call(this);
  this.addChild(this.lineContainer);
  this.addChild(this.pointContainer);
  this.addChild(this.textContainer);
};
ROS2D.Ruler_draw.prototype.addStartPoint = function (input_point) {
  var name = "first";
  var point = this.createPointShape(input_point, name);
  this.pointContainer.addChild(point);
}
ROS2D.Ruler_draw.prototype.add_Line = function (input_point) {
  var name = "second";
  var point = this.createPointShape(input_point, name);
  this.pointContainer.addChild(point);
  var line = this.createLineShape(this.pointContainer.getChildAt(0), point);
  this.lineContainer.addChild(line);
  var text = this.calculateTextPosition(this.pointContainer.getChildAt(0), point, "angle");
  this.textContainer.addChild(text);
  var text_2 = this.calculateTextPosition(this.pointContainer.getChildAt(0), point, "length");
  this.textContainer.addChild(text_2);


}
/**
* Internal use only
*/
ROS2D.Ruler_draw.prototype.createLineShape = function (startPoint, endPoint) {
  var line = new createjs.Shape();
  //	line.graphics.setStrokeStyle(this.strokeSize);
  //	line.graphics.beginStroke(this.strokeColor);
  //	line.graphics.moveTo(startPoint.x, startPoint.y);
  //	line.graphics.lineTo(endPoint.x, endPoint.y);

  this.editLineShape(line, startPoint, endPoint);

  var that = this;

  return line;
};

/**
* Internal use only
*/
ROS2D.Ruler_draw.prototype.editLineShape = function (line, startPoint, endPoint) {
  line.graphics.clear();
  line.graphics.setStrokeStyle(this.rulerSize);
  line.graphics.beginStroke(this.rulerColor);
  line.graphics.moveTo(startPoint.x, startPoint.y);
  line.graphics.lineTo(endPoint.x, endPoint.y);

};
/**
* Internal use only
*/
ROS2D.Ruler_draw.prototype.editText = function (text, startPoint, endPoint) {
  var width_line = endPoint.x - startPoint.x;
  var height_line = endPoint.y - startPoint.y;

  var bien = height_line / width_line
  var alpha = Math.atan(bien);
  this.radius_text = alpha * 180 / Math.PI;
  this.radius_text = this.radius_text.toFixed(2);
  text.scaleX = this.scaleText;
  text.scaleY = this.scaleText;
  if (Math.abs(height_line) > 0 || Math.abs(width_line) > 0) {
    est_angular = Math.atan(bien) * 180 / Math.PI;


    text.rotation = est_angular;

  }
  if (text.name === "angle") {
    var base_x_text = (1 / 4) * width_line + startPoint.x + Math.sin(alpha) * this.textDistance;
    var base_y_text = 1 / 4 * height_line + startPoint.y - Math.cos(alpha) * this.textDistance;
    text.x = base_x_text;
    text.y = base_y_text;
    text.text = "Angle: " + this.radius_text + "deg";

  }
  else if (text.name === "length") {
    var length = Math.sqrt(Math.pow(width_line, 2) + Math.pow(height_line, 2));
    length = length.toFixed(2);
    var base_x_text = (1 / 4) * width_line + startPoint.x - Math.sin(alpha) * this.textDistance_below;
    var base_y_text = 1 / 4 * height_line + startPoint.y + Math.cos(alpha) * this.textDistance_below;
    text.x = base_x_text;
    text.y = base_y_text;
    text.text = "Distance: " + length + "m";
  }



};
/** 
 * Internal use only
*/
ROS2D.Ruler_draw.prototype.drag_line = function (evt) {

  this.drag(evt);

  //this.rootObject.update();
}

/**
* Internal use only
*/
ROS2D.Ruler_draw.prototype.createPointShape = function (pos, name) {
  var point = new createjs.Shape();
  this.rootObject.update();
  point.graphics.beginFill(this.pointColor);
  point.graphics.drawCircle(0, 0, this.pointSize);
  point.on("pressmove", this.drag);
  point.x = pos.x;
  point.y = -pos.y;
  point.name = name;
  var that = this;
  point.addEventListener('mousedown', function (event) {
    if (that.pointCallBack !== null && typeof that.pointCallBack !== 'undefined') {
      that.pointCallBack('mousedown', event, that.pointContainer.getChildIndex(event.target));
    }
  });

  return point;
};
/**
* Internal use only
*/
ROS2D.Ruler_draw.prototype.calculateTextPosition = function (startPoint, endPoint, name) {
  var text = new createjs.Text("", "1px Arial", "#ff7700");
  text.textBaseline = "alphabetic";
  text.name = name;
  this.editText(text, startPoint, endPoint);
  return text;

}


/**
* Splits a line of the polygon: inserts a point at the center of the line
*
* @param obj either an index (integer) or a line shape of the polygon
*/

ROS2D.Ruler_draw.prototype.__proto__ = createjs.Container.prototype;
