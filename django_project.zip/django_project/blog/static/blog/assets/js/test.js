var ros = new ROSLIB.Ros({
         url: 'ws://localhost:9090'
    // url: 'ws://'+window.location.hostname+':9090'
    });
    
    console.log(ros)
    ros.on('connection', function () {
    console.log("connected")
    });
    
    ros.on('error', function (error) {
      console.log("error")
    
    });
    
    ros.on('close', function () {
    console.log("close")
    
    });
    
    
    
    
    cmd_vel_listener = new ROSLIB.Topic({
      ros: ros,
      name: "/cmd_vel",
      messageType: 'geometry_msgs/Twist'
    });
    
    move = function (linear, angular) {
    var twist = new ROSLIB.Message({
    linear: {
      x: 0.5,
      y: 0,
      z: 0
    },
    angular: {
      x: 0,
      y: 0,
      z: 0.5
    }
    });
    cmd_vel_listener.publish(twist);
    };
    