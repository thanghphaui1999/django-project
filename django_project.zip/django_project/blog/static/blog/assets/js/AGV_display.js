/**
 * @author Nguyen Viet Thang
 */
var AGV_DISPLAY = AGV_DISPLAY || {
    REVISION: '0.1.0'
};

/**
* Draw AGV shape.
*
* @constructor
* @param options - object with following keys:
    *   * width (optional) - the width of the AGV
    *   * height (optional) - the height of the AGV
    *   * name (optional) - the name of the AGV(E.g "AGV_1")
    *   * rootObject (optional) - the rootObject for display
    *   * scaleText (optional) - the scale of Text
    *   * Scalesize (optional) - the Scalesize of map.
    *   * resolution (optional) - the resolution of map (m/pixel)
*/
class AGV_SHAPE {
    constructor(width, height, Scale, rootObject, resolution, name) {
        this.width = width;
        this.height = height;
        this.Scale = Scale;
        this.name = name || "AGV";
        this.ID = name.split("_")[1];
        this.scaleText = 2;
        this.strokeSize = 2;
        this.resolution = resolution || 0.05;
        this.rootObject = rootObject || new createjs.Stage();
        this.strokeColor = createjs.Graphics.getRGB(255, 0, 0, 1);
        this.fillColor = createjs.Graphics.getRGB(70, 20, 40, 1);
        this.realBoderColor = createjs.Graphics.getRGB(100, 100, 50, 0.25);
        this.Alert_color = createjs.Graphics.getRGB(255, 0, 0, 1);
        this.Working_color = createjs.Graphics.getRGB(0, 255, 0, 1);
        this.pixelWidth = this.ConvertMetToPixel(this.width);
        this.pixelHeight = this.ConvertMetToPixel(this.height);
        this.displayWidth = parseInt(this.pixelWidth / 3);
        this.displayHeight = parseInt(this.pixelHeight / 3);
        this.BorderRound = parseInt(this.pixelWidth / 12);


    }
    get getWidth() {
        console.log("Width of AGV", this.width);
        return this.width;
    }
    get getHeight() {
        console.log("Height of AGV", this.height);
        return this.height;
    }
    get getName() {
        console.log("Name of AGV", this.name)
    }
    set setWidth(width) {
        this.width = width;
    }
    set setHeight(height) {
        this.height = height;
    }
    set setName(name) {
        this.name = name;
    }
    ConvertMetToPixel(realData) {
        var PixelCoordinate = parseInt((realData) / this.resolution);
        return PixelCoordinate;
    }
    ConvertPixelToMet(pixelData) {
        var RealCoordinate = pixelData * this.resolution / (realData * this.ScaleSize);
        return RealCoordinate;
    }
    Draw() {

        this.AGV_shape = new createjs.Shape();
        this.AGV_shape.name = this.name;
        //this.AGV_shape.on("pressmove", this.callback)
        this.AGV_shape.graphics.clear();
        this.AGV_shape.graphics.setStrokeStyle(this.strokeSize);
        this.AGV_shape.graphics.beginStroke(this.strokeColor);
        this.AGV_shape.graphics.beginFill(this.fillColor)
        this.AGV_shape.graphics.drawRoundRect((-this.displayWidth - this.strokeWidthstrokeSize) / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, this.BorderRound);
        this.AGV_shape.graphics.endFill();
        this.AGV_shape.graphics.endStroke();
        this.AGV_shape.graphics.setStrokeStyle(1);
        this.AGV_shape.graphics.beginStroke(this.realBoderColor);
        this.AGV_shape.graphics.drawRoundRect((-this.pixelWidth - this.strokeSize) / 2, 0 - this.pixelHeight / 2, this.pixelWidth, this.pixelHeight, this.BorderRound);
        this.AGV_shape.graphics.endStroke();
        this.AGV_ID = new createjs.Text(this.ID, "10px Arial", "#ff7700");
        this.AGV_ID.font = parseInt(this.displayHeight * 2 / 5) + "px Arial"
        this.AGV_ID.textBaseline = "alphabetic";
        this.AGV_ID.textAlign = "center";
        //this.AGV_ID.scaleX = 1/this.Scale;
        //this.AGV_ID.scaleY = 1/this.Scale;
        this.rootObject.addChild(this.AGV_shape, this.AGV_ID);
    }
    UpdatePosition(posX, posY, angle) {
        this.AGV_shape.x = posX;
        this.AGV_shape.y = posY;
        this.AGV_shape.rotation = angle;
        this.AGV_ID.x = posX;
        this.AGV_ID.y = posY + this.displayHeight / 6;

    }
    GetPosX() {
        return this.AGV_shape.x;
    }
    GetPosY() {
        return this.AGV_shape.y;

    }
    CallbackUpdate = function (posX, posY) {
        this.AGV_shape.graphics.clear();
        this.AGV_shape.graphics.setStrokeStyle(this.strokeSize);
        this.AGV_shape.graphics.beginStroke(this.strokeColor);
        this.AGV_shape.graphics.beginFill(this.fillColor)
        this.AGV_shape.graphics.drawRoundRect((-this.displayWidth) / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, this.BorderRound);
        this.AGV_shape.graphics.endFill();
        this.AGV_shape.graphics.endStroke();
        this.AGV_shape.graphics.setStrokeStyle(1);
        this.AGV_shape.graphics.beginStroke(this.realBoderColor);
        this.AGV_shape.graphics.drawRoundRect((-this.pixelWidth) / 2, 0 - this.pixelHeight / 2, this.pixelWidth, this.pixelHeight, this.BorderRound);
        this.AGV_shape.graphics.endStroke();
        this.UpdatePosition(posX, posY);
    }

    UpdateStrokeColor(color) {
        this.AGV_shape.graphics.clear();
        this.AGV_shape.graphics.setStrokeStyle(this.strokeSize);
        this.AGV_shape.graphics.beginStroke(color);
        this.AGV_shape.graphics.beginFill(this.fillColor)
        this.AGV_shape.graphics.drawRoundRect((-this.displayWidth) / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, this.BorderRound);
        //this.AGV_shape.graphics.drawRoundRect((-this.displayWidth - this.strokeSize) / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, this.BorderRound);
        this.AGV_shape.graphics.endFill();
        this.AGV_shape.graphics.endStroke();
        this.AGV_shape.graphics.setStrokeStyle(1);
        this.AGV_shape.graphics.beginStroke(this.realBoderColor);
        this.AGV_shape.graphics.drawRoundRect((-this.pixelWidth) / 2, 0 - this.pixelHeight / 2, this.pixelWidth, this.pixelHeight, this.BorderRound);
        this.AGV_shape.graphics.endStroke();




    }
}

/**
* Draw TIM320 area.
*
* @constructor
* @param options - object with following keys:

    *   * nameArea (optional) - the name of the TIM area
    *   * rootObject (optional) - the rootObject for display
    *   * Scale (optional) - the Scalesize of map.
    *   * width (optional) - the width of TIM area
    *   * distance(optional) - the distance from display area

*/
class TIM_area {
    constructor(nameArea, Scale, rootObject, width, distance, state) {
        this.nameArea = nameArea;
        this.Scale = Scale;
        this.rootObject = rootObject;
        this.width = width;
        this.Danger_area_color = createjs.Graphics.getRGB(204, 0, 0, 0.5);
        this.Medium_area_color = createjs.Graphics.getRGB(255, 102, 0, 0.5);
        this.Low_area_color = createjs.Graphics.getRGB(255, 255, 102, 0.5);
        this.Normal_color = createjs.Graphics.getRGB(0, 255, 0, 0.5);
        this.distance = distance
        this.TIM_area = 4;
        this.state = state;
    }
    Draw() {
        if (this.state === true) {
            this.TIM_shape = new createjs.Shape();
            this.TIM_shape.graphics.clear();
            this.TIM_shape.graphics.beginFill(this.Danger_area_color);
            this.TIM_shape.graphics.drawRect(this.TIM_area * 0 + 2 + this.distance / 2, - (this.width) / 2, 4, this.width);
            this.TIM_shape.graphics.endFill();
            this.TIM_shape.graphics.beginFill(this.Medium_area_color);
            this.TIM_shape.graphics.drawRect(this.TIM_area * 1 + 2 + this.distance / 2, -(this.width) / 2, 4, this.width);
            this.TIM_shape.graphics.endFill();
            this.TIM_shape.graphics.beginFill(this.Low_area_color);
            this.TIM_shape.graphics.drawRect(this.TIM_area * 2 + 2 + this.distance / 2, -(this.width) / 2, 4, this.width);
            this.TIM_shape.graphics.endFill();
            this.rootObject.addChild(this.TIM_shape);
        }

    }
    UpdatePosition(posX, posY, angle) {
        this.TIM_shape.x = posX;
        this.TIM_shape.y = posY;
        this.TIM_shape.rotation = angle;

    }
    update_color(color1, color2, color3) {
        this.TIM_shape.graphics.clear();
        this.TIM_shape.graphics.beginFill(color1);
        this.TIM_shape.graphics.drawRect(this.TIM_area * 0 + 2 + this.distance / 2, - (this.width) / 2, 4, this.width);
        this.TIM_shape.graphics.endFill();
        this.TIM_shape.graphics.beginFill(color2);
        this.TIM_shape.graphics.drawRect(this.TIM_area * 1 + 2 + this.distance / 2, -(this.width) / 2, 4, this.width);
        this.TIM_shape.graphics.endFill();
        this.TIM_shape.graphics.beginFill(color3);
        this.TIM_shape.graphics.drawRect(this.TIM_area * 2 + 2 + this.distance / 2, -(this.width) / 2, 4, this.width);
        this.TIM_shape.graphics.endFill();
    }

    TIM_callbackUpdate(state, set_area) {
        if (state === "1") {
            this.TIM_shape.visible = true;
            this.state = true;
            var color1 = this.Normal_color;
            var color2 = this.Normal_color;
            var color3 = this.Normal_color;
            if (set_area === "3") {
                color1 = this.Danger_area_color;
                color2 = this.Medium_area_color;
                color3 = this.Low_area_color;
            }
            if (set_area === "2") {
                color2 = this.Medium_area_color;
                color3 = this.Low_area_color;
            }
            if (set_area === "1") {
                color3 = this.Low_area_color;
            }
            this.update_color(color1, color2, color3);
        }
        else if (state === "0") {
            this.TIM_shape.visible = false;
            this.state = false;
        }
    }
}
/**
* A Head arrow is a directed triangle that can be used to display orientation of AGV.
*
* @constructor
* @param options - object with following keys:
*   * Scale(optional) - the Scale of Arrow
*   * strokeColor (optional) - the createjs color for the stroke
*   * fillColor (optional) - the createjs color for the fill
*   * distance(optional) - the distance from display area
*   * pulse (optional) - if the marker should "pulse" over time
*/
class HeadArrow {
    constructor(Scale, rootObject, resolution, size,distance, pulse) {
        this.rootObject = rootObject;
        this.resolution = resolution;
        this.Scale = Scale
        this.color = createjs.Graphics.getRGB(255, 0, 0, 0.5);
        this.arrowSize = size
        this.distance = distance;
        this.pulse = pulse
    }
    Draw()
    {
        var that = this;
        this.arrowShape = new createjs.Shape();
        // line width
        this.arrowShape.graphics.setStrokeStyle(1);
        this.arrowShape.graphics.moveTo(-this.arrowSize / 2.0, -this.arrowSize / 2.0);
        this.arrowShape.graphics.beginStroke(this.color);
        this.arrowShape.graphics.beginFill(this.color);
        this.arrowShape.graphics.lineTo(this.arrowSize, 0);
        this.arrowShape.graphics.lineTo(-this.arrowSize/ 2.0, this.arrowSize/ 2.0);
        this.arrowShape.graphics.closePath();
        this.arrowShape.graphics.endFill();
        this.arrowShape.graphics.endStroke();

        // create the shape
        
        // check if we are pulsing
        if (this.pulse) {
            // have the model "pulse"
            var growCount = 0;
            var growing = true;
            createjs.Ticker.addEventListener('tick', function () {
                if (growing) {
                    that.arrowShape.scaleX *= 1.035;
                    that.arrowShape.scaleY *= 1.035;
                    growing = (++growCount < 10);
                } else {
                    that.arrowShape.scaleX /= 1.035;
                    that.arrowShape.scaleY /= 1.035;
                    growing = (--growCount < 0);
                }
            });
        }
        this.rootObject.addChild(this.arrowShape)
    }
    UpdatePosition(posX,posY, angle)
    {
        this.arrowShape.x = posX - parseInt(0*Math.cos(angle*3.14/180)-this.distance*Math.sin(angle*3.14/180))
        this.arrowShape.y = posY - parseInt(0*Math.sin(angle*3.14/180) + this.distance*Math.cos(angle*3.14/180));
        this.arrowShape.rotation = angle - 90;
    }
}
class AGV_Display extends AGV_SHAPE {
    constructor(width, height, Scale, rootObject, resolution, name, data) {
        super(width, height, Scale, rootObject, resolution, name);
        this.TIM_east = new TIM_area("East", this.Scale, this.rootObject, this.displayHeight + 2, this.displayWidth + 2, true);
        this.TIM_west = new TIM_area("West", this.Scale, this.rootObject, this.displayHeight + 2, this.displayWidth + 2, true);
        this.TIM_south = new TIM_area("South", this.Scale, this.rootObject, this.displayWidth + 2, this.displayHeight + 2, true);
        this.TIM_north = new TIM_area("North", this.Scale, this.rootObject, this.displayWidth + 2, this.displayHeight + 2, true);
        this.HeadArrow = new HeadArrow(this.Scale,this.rootObject,resolution,10 ,this.pixelHeight/2, true)
        this.state = true;
        this.AGV_Height = 1.5;
        this.AGV_Width = 0.7;
    }
    Draw_AGV(posX, posY, angle) {
        this.Draw();
        this.UpdatePosition(posX, posY, angle);
        this.TIM_east.Draw();
        this.TIM_east.UpdatePosition(posX - this.width / 2, posY, 0 + angle)
        this.TIM_west.Draw();
        this.TIM_west.UpdatePosition(posX - this.width / 2, posY, 180 + angle);
        this.TIM_north.Draw();
        this.TIM_north.UpdatePosition(posX - this.width / 2, posY, 270 + angle);
        this.TIM_south.Draw();
        this.TIM_south.UpdatePosition(posX - this.width / 2, posY, 90) + angle;
        this.HeadArrow.Draw();
        this.HeadArrow.UpdatePosition(posX, posY ,0)
       
    }
    //index 0: north area
    //index 1: south area
    //index 2: west area
    //index 3: east area
    ChangeAGV_TIM_Status(list_data) {
        for (var i = 0; i < list_data.length; i++) {
            var info = list_data[i].split("_");
            var state = info[0];
            var level = info[1];
            if (i === 0) {
                this.TIM_north.TIM_callbackUpdate(state, level);
            }
            else if (i === 1) {
                this.TIM_south.TIM_callbackUpdate(state, level);
            }
            else if (i === 2) {
                this.TIM_west.TIM_callbackUpdate(state, level);
            }
            else if (i === 3) {
                this.TIM_east.TIM_callbackUpdate(state, level);
            }
        }
    }
    UpdatePositionAGV(posX, posY, angle) {
       
        if (angle === 90 || angle === -90) {
            angle = angle + 180

        }
        this.UpdatePosition(posX, posY, angle);
        this.TIM_north.UpdatePosition(posX - this.width / 2, posY, 270 + angle);
        this.TIM_east.UpdatePosition(posX - this.width / 2, posY, 0 + angle);
        this.TIM_west.UpdatePosition(posX - this.width / 2, posY, 180 + angle);
        this.TIM_south.UpdatePosition(posX - this.width / 2, posY, 90 + angle);
        this.HeadArrow.UpdatePosition(posX,posY , angle)
    }
    //Check current status of AGV.
    CheckRaiseStatus(movingStatus, activeStatus, chargedStatus, arrivedStatus,
        acquiredStatus, depositStatus, loadedStatus, downStatus) {
        var listStatus = [movingStatus, activeStatus, chargedStatus, arrivedStatus,
            acquiredStatus, depositStatus, loadedStatus, downStatus]
        function find(value) {
            return value > 0;
        }
        return listStatus.findIndex(find);
    }
    // 0: Run - Green.
    // 1: Active - Blue
    // 2: Charge - Purple
    // 3: Arriving - orange
    // 4: Acquire - Yellow
    // 5: Deposit - black
    // 6: loaded - aqua
    // 7: down - gray 
    UpdateAGVstatus(status) {
        var color;
        switch (status) {
            case 0:
                color = "green";
                break;
            case 1:
                color = "blue";
                break;
            case 2:
                color = "purple";
                break;
            case 3:
                color = "orange";
                break;
            case 4:
                color = "yellow";
                break;
            case 5:
                color = "black";
                break;
            case 6:
                color = "aqua";
                break;
            case 7:
                color = "red";
                break;
        }
        this.UpdateStrokeColor(color);
    }
}

class Draw_all_AGV {
    constructor(rootObject, resolution, Scale) {
        this.rootObject = rootObject;
        this.resolution = resolution;
        this.Scale = Scale;
        this.list_AGV = [];
        this.list_AGV_name = [];
    }
    Draw(AGV_data) {
        for (var i in AGV_data) {
            var ID = parseInt(i) + 1;
            var X = AGV_data[i].fields.X;
            var Y = 800 - AGV_data[i].fields.Y;
            var Height = AGV_data[i].fields.Height;
            var Width = AGV_data[i].fields.Width;
            var add_AGV = new AGV_Display(Width, Height, this.Scale, this.rootObject, this.resolution, "AGV_" + ID);
            var status = add_AGV.CheckRaiseStatus(AGV_data[i].fields.moving, AGV_data[i].fields.active,
                AGV_data[i].fields.charging, AGV_data[i].fields.arriving,
                AGV_data[i].fields.acquiring, AGV_data[i].fields.depositing,
                AGV_data[i].fields.loaded, AGV_data[i].fields.down)
            add_AGV.Draw_AGV(X, Y, 0);
            add_AGV.UpdateAGVstatus(parseInt(status));
            var Tim_data = [AGV_data[i].fields.TimNorth, AGV_data[i].fields.TimSouth, AGV_data[i].fields.TimWest, AGV_data[i].fields.TimEast];
            add_AGV.ChangeAGV_TIM_Status(Tim_data);
            this.list_AGV.push(add_AGV);
            this.list_AGV_name.push(ID);
        }
    }
    Acess_item(AGV_name) {
        var AGV_index = this.list_AGV_name.indexOf(AGV_name);
        var AGV = this.list_AGV[AGV_index];
        return AGV;
    }
}

