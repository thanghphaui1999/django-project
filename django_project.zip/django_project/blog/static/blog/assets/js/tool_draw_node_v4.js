
/**
 * @author Nguyen Viet Thang
 */
var TOOL2D = TOOL2D || {
    REVISION: '0.1.0'
};

/**
* Draw a new node on top of canvas.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * strokeSize (optional) - the size of the out
    *   * strokeColor (optional) - the createjs color for the stroke
    *   * fillColor (optional) - the createjs color for the fill
    *   * radius (optional) - the createjs radius for the circle
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * name (optional) - name of node (E.g 'node_12')
    *   * type (optional) - type of node
    *   * effect_area (optional) - the valid area used for merging node
*/

TOOL2D.Draw_node = function (options) {
    var that = this;
    options = options || {};
    this.involve_links = [];
    this.Scalesize = options.size || 0.5;
    this.effect_area = options.effect_area || 6;
    this.name = options.name || "node";
    this.scaleText = options.scaleText || 0.1
    this.strokeSize = options.strokeSize || 0.1;
    this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
    this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0);
    this.radius = options.radius || 0.5
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.type = options.type || 0;
    this.shape = new createjs.Shape();
    this.shape.name = this.name;
    this.shape.on("pressmove", this.callback)
    this.updateTypeNode(this.type)
    this.rootObject.addChild(this.shape);
    this.enable_Text = false;
}
TOOL2D.Draw_node.prototype.updateTypeNode= function(type)
{
    this.type = type
    if (this.type === 0) {

        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endStroke();
        this.shape.graphics.endFill();

    }
    else if (this.type === 1) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endFill();
        this.shape.graphics.endStroke();

    }
    else if (this.type === 2) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endFill();
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endStroke();
    }
    else if (this.type === 3) {
       
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawPolyStar(0, 0, 2*this.radius, 5, 0.6, -90);
        this.shape.graphics.endStroke();
        this.shape.graphics.endFill();
        
    }
}
TOOL2D.Draw_node.prototype.addLink = function (link_name) {
    this.involve_links.push(link_name);

}
TOOL2D.Draw_node.prototype.update_Position = function (X_pos, Y_pos) {
    this.shape.x = X_pos;
    this.shape.y = Y_pos;
}
TOOL2D.Draw_node.prototype.turnLock = function () {
    var color = createjs.Graphics.getRGB(0, 139, 139, 0.25)
    if (this.type === 0) {
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(color);
        this.shape.graphics.beginFill(color);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endStroke();
        this.shape.graphics.endFill();

    }
    else if (this.type === 1) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(color);
        this.shape.graphics.beginFill(color);
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endFill();
        this.shape.graphics.endStroke();
    }
    else if (this.type === 2) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(color);
        this.shape.graphics.beginFill(color);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endFill();
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endStroke();
    }
    this.Text_node.color = createjs.Graphics.getRGB(0,139,139,0.25)
}
TOOL2D.Draw_node.prototype.addText = function (text, posX, posY) {
    this.enable_Text = true;
    this.Text_node = new createjs.Text(text, "10px Arial", "#ff7700");
    this.Text_node.textBaseline = "alphabetic";
    this.Text_node.name = text;
    this.rootObject.addChild(this.Text_node);
    this.Text_node.scaleX = this.scaleText;

    this.Text_node.scaleY = this.scaleText;

    this.Text_node.x = posX - this.radius * 2;
    this.Text_node.y = posY - this.radius * 2;
}
TOOL2D.Draw_node.prototype.callback_update = function (posX, posY) {
    if (this.type === 0) {
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endStroke();
        this.shape.graphics.endFill();
    }
    else if (this.type === 1) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endFill();
        this.shape.graphics.endStroke();
    }
    else if (this.type === 2) {
        var rec_size = (this.radius * 2 + this.strokeSize * 2);
        this.shape.graphics.clear();
        this.shape.graphics.setStrokeStyle(this.strokeSize);
        this.shape.graphics.beginStroke(this.strokeColor);
        this.shape.graphics.beginFill(this.fillColor);
        this.shape.graphics.drawCircle(0, 0, this.radius);
        this.shape.graphics.endFill();
        this.shape.graphics.drawRect(0 - rec_size / 2, 0 - rec_size / 2, rec_size, rec_size);
        this.shape.graphics.endStroke();
    }
    if (this.enable_Text === true) {
        this.Text_node.x = (posX) * this.Scalesize - this.radius * 2;
        this.Text_node.y = (posY) * this.Scalesize - this.radius * 2;
    }
    this.shape.x = posX * this.Scalesize;
    this.shape.y = posY * this.Scalesize;
}
TOOL2D.Draw_node.prototype.Remove_node = function () {
    this.rootObject.removeChild(this.shape);
    if (this.enable_Text === true) {
        this.rootObject.removeChild(this.Text_node);
    }
}
TOOL2D.Draw_node.prototype.RemoveInvolveLink = function (link_name) {
    const index = this.involve_links.indexOf(link_name);
    this.involve_links.splice(index, 1)
}
TOOL2D.Draw_node.prototype.Check_neighbors_node = function (node) {
    var state = []
    var limit_left_x = this.shape.x - this.effect_area;
    var limit_left_y = this.shape.y - this.effect_area;
    var limit_right_x = this.shape.x + this.effect_area;
    var limit_right_y = this.shape.y + this.effect_area;
    if (limit_left_x <= node.shape.x && limit_right_x >= node.shape.x) {
        state.push(true);
    }
    else {
        state.push(false);
    }
    if (limit_left_y <= node.shape.y && limit_right_y >= node.shape.y) {
        state.push(true);
    }
    else {
        state.push(false)
    }
    return state;
}

/**
* Draw a new MAP on top of canvas.
*
* @constructor
* @param options - object with following keys:
    *   * height (optional) - height of the map
    *   * width(optional) - width of the map
    *   * resolution (optional) - the resolution of the map
    *   * parent_div
    *   * map_url
 
*/
TOOL2D.Draw_map = function (options) {
    var that = this;
    options = options || {};
    this.height = options.height || 500;
    this.width = options.width || 500;
    this.resolution = options.resolution || 0.05;
    this.map_url = options.map_url;
    var parent_div = options.parent_div;
    var background = options.background || '#F8F8FF';
    var canvas = document.createElement('canvas');
    document.getElementById(parent_div).appendChild(canvas)
    canvas.width = this.width;
    canvas.height = this.height;
    canvas.style.background = background;
    this.scene = new createjs.Stage(canvas);
    this.map_image = new createjs.Bitmap(this.map_url);
    this.scene.addChild(this.map_image);
    this.scene.update();
    createjs.Ticker.setFPS(30);
    createjs.Ticker.addEventListener('tick', this.scene);
}
TOOL2D.Draw_map.prototype.addObject = function (object) {
    this.scene.addChild(object);
    this.scene.update();
}
TOOL2D.Draw_map.prototype.scaleMap = function (height, width) {
    this.scene.scaleX = this.width / width;
    this.scene.scaleY = this.height / height;
}
/**
* Draw a new AGV on top of canvas.
*
* @constructor
* @param options - object with following keys:
   *   * size (optional) - the size of the circle
    *   * strokeSize (optional) - the size of the out
    *   * strokeColor (optional) - the createjs color for the stroke
    *   * fillColor (optional) - the createjs color for the fill
    *   * height (optional) - the createjs height for the AGV
    *   * width (optional) - the createjs width for the AGV
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * name (optional) - name of node
   
 
*/
TOOL2D.Draw_AGV = function (options) {
    var that = this;
    options = options || {};
    this.Scalesize = options.size || 0.5;
    this.name = options.name || "AGV";
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 255, 0, 0.5);
    this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0, 0.5);
    this.width = options.width || 0.5;
    this.height = options.height || 0.5;
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.shape = new createjs.Shape();
    this.shape.name = this.name;
    this.shape.on("pressmove", this.callback)
    this.shape.graphics.clear();
    this.shape.graphics.setStrokeStyle(this.strokeSize);
    this.shape.graphics.beginStroke(this.strokeColor);
    this.shape.graphics.beginFill(this.fillColor);
    this.shape.graphics.drawRoundRect(0 - this.width / 2, 0 - this.height / 2, this.width, this.height, 3);
    this.shape.graphics.endStroke();
    this.shape.graphics.endFill();
    this.rootObject.addChild(this.shape);
}
TOOL2D.Draw_AGV.prototype.Draw = function (text, posX, posY) {
    this.Text_node = new createjs.Text(text, "10px Arial", "#ff7700");
    this.Text_node.textBaseline = "alphabetic";
    this.Text_node.name = text;
    this.rootObject.addChild(this.Text_node);
    this.Text_node.scaleX = this.scaleText;
    this.Text_node.scaleY = this.scaleText;
    this.Text_node.x = posX - 2;
    this.Text_node.y = posY + 2;
}
TOOL2D.Draw_AGV.prototype.addText = function (text, posX, posY) {
    this.Text_node = new createjs.Text(text, "10px Arial", "#ff7700");
    this.Text_node.textBaseline = "alphabetic";
    this.Text_node.name = text;
    this.rootObject.addChild(this.Text_node);
    this.Text_node.scaleX = this.scaleText;
    this.Text_node.scaleY = this.scaleText;
    this.Text_node.x = posX - 2;
    this.Text_node.y = posY + 2;
}

TOOL2D.Draw_AGV.prototype.callback_update = function (posX, posY) {
    this.shape.graphics.clear();
    this.shape.graphics.setStrokeStyle(this.strokeSize);
    this.shape.graphics.beginStroke(this.strokeColor);
    this.shape.graphics.beginFill(this.fillColor);
    this.shape.graphics.drawRect(0 - this.width / 2, 0 - this.height / 2, this.width, this.height);
    this.shape.graphics.endStroke();
    this.shape.graphics.endFill();
    this.Text_node.x = (posX - 4) * this.Scalesize;
    this.Text_node.y = (posY + 4) * this.Scalesize;
    this.shape.x = posX * this.Scalesize;
    this.shape.y = posY * this.Scalesize;

}

/**
* Draw a new link between 2 nodes on top of canvas.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * strokeSize (optional) - the stroke size of line.
    *   * lineSize (optional) - the size of the out
    *   * lineColor (optional) - the createjs color for the stroke
    *   * fillColor (optional) - the createjs color for the fill
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * name (optional) - name of link
    *   * startNode - start node of link
    *   * endNode - end node of link
*/
TOOL2D.Draw_link = function (options) {
    var that = this;
    options = options || {};
    this.Scalesize = options.size || 0.5;
    this.name = options.name || "link";
    this.scaleText = options.scaleText || 0.1
    this.lineSize = options.lineSize || 0.1;
    this.lineColor = options.lineColor || createjs.Graphics.getRGB(0, 0, 0);
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.startNode = options.startNode;
    this.endNode = options.endNode;
    this.strokeSize = options.strokeSize;
    this.shape = new createjs.Shape();
    this.shape.name = this.name;
    this.shape.graphics.clear();
    this.shape.graphics.setStrokeStyle(this.lineSize);
    this.shape.graphics.beginStroke(this.lineColor);
    this.shape.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.shape.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.rootObject.addChild(this.shape);
    this.enable_Text = false;
}
TOOL2D.Draw_link.prototype.addText = function (text, posX, posY) {
    this.enable_Text = true;
    this.Text_node = new createjs.Text(text, "10px Arial", "#ff7700");
    this.Text_node.textBaseline = "alphabetic";
    this.Text_node.name = text;
    this.rootObject.addChild(this.Text_node);
    this.Text_node.scaleX = this.scaleText;
    this.Text_node.scaleY = this.scaleText;
    this.Text_node.x = posX - 2;
    this.Text_node.y = posY + 4;
}
TOOL2D.Draw_link.prototype.callback_update = function () {
    this.shape.graphics.clear();
    this.shape.graphics.setStrokeStyle(this.strokeSize);
    this.shape.graphics.beginStroke(this.lineColor);
    this.shape.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.shape.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.shape.graphics.endStroke();
    this.shape.graphics.endFill();

}
/**
* Draw all nodes from database.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * fillColor (optional) - the createjs color for the fill
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * strokeSize (optional) - the stroke size
    *   * radius (optional) - the radius of node
*/
TOOL2D.Draw_all_nodes = function (options) {
    var that = this;
    this.node_list = [];
    this.node_list_name = [];
    options = options || {};
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.fillColor = options.fillColor || createjs.Graphics.getRGB(0, 0, 0);
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.radius = options.radius
    this.enable_Text = false;
    this.callback = options.callback;


}
TOOL2D.Draw_all_nodes.prototype.Add_node = function (node_id, node_X, node_Y, node_type) {
    var node_name = "node_" + node_id;
    var create_node = new TOOL2D.Draw_node({
        name: node_name,
        size: this.Scalesize,
        strokeSize: 1,
        rootObject: this.rootObject,
        strokeColor: createjs.Graphics.getRGB(255, 0, 255),
        fillColor: createjs.Graphics.getRGB(255, 0, 0),
        callback: this.callback,
        radius: this.radius,
        type: 1,
        scaleText: 1.0,
        type: node_type
    })
    this.node_list.push(create_node);
    this.node_list_name.push(node_name)
    create_node.update_Position(node_X, node_Y)
    create_node.addText(node_id, node_X, node_Y);
}

TOOL2D.Draw_all_nodes.prototype.Remove_node = function (node_name) {
    var node_index = this.node_list_name.indexOf(node_name);
    var node = this.node_list[node_index]
    node.Remove_node();
    this.node_list.splice(node_index, 1);
    this.node_list_name.splice(node_index, 1);
 
}

TOOL2D.Draw_all_nodes.prototype.Remove_multiple_nodes_by_index = function (index, number) {
    for (var i = index; i <= index + number; i++) {
        var node = this.node_list[i];
        node.Remove_node();
    }
    this.node_list.splice(index, number);
    this.node_list_name.splice(index, number);
}
TOOL2D.Draw_all_nodes.prototype.Number_nodes = function () {
    var Current_number_nodes = this.node_list.length;
    return Current_number_nodes
}
TOOL2D.Draw_all_nodes.prototype.RemoveAll_node = function () {

}
TOOL2D.Draw_all_nodes.prototype.Draw = function (node_database) {

    for (var i in node_database) {

        var node_id = node_database[i].fields.ID_NODE;
        var node_X = parseInt(node_database[i].fields.X);
        var node_Y = parseInt(node_database[i].fields.Y);
        var node_type = parseInt(node_database[i].fields.TYPE)
        var node_name = "node_" + node_id;
        var create_node = new TOOL2D.Draw_node({
            name: node_name,
            size: this.Scalesize,
            strokeSize: 1,
            rootObject: this.rootObject,
            strokeColor: createjs.Graphics.getRGB(255, 0, 255),
            fillColor: createjs.Graphics.getRGB(255, 0, 0),
            callback: this.callback,
            radius: this.radius,
            type: 1,
            scaleText: 1.0,
            type: node_type
        })
        this.node_list.push(create_node);
        this.node_list_name.push(node_name)
        create_node.update_Position(node_X, node_Y)
        create_node.addText(node_id, node_X, node_Y);
    }

}
TOOL2D.Draw_all_nodes.prototype.Acess_item = function (node_name) {

    var node_index = this.node_list_name.indexOf(node_name);
    var node = this.node_list[node_index];
    return node;
}

/**
* Draw all links from database.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * lineColor (optional) - the createjs color for the line
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * strokeSize (optional) - the stroke size
*/
TOOL2D.Draw_all_links = function (options) {
    var that = this;
    this.links_list = [];
    this.links_list_name = [];
    options = options || {};
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.lineColor = options.fillColor || createjs.Graphics.getRGB(0, 0, 0);
    this.rootObject = options.rootObject || new createjs.Stage();
    this.enable_Text = false;
}
TOOL2D.Draw_all_links.prototype.Draw = function (link_database, nodes_list, nodes_list_name) {

    for (var i in link_database) {
        var link_id = link_database[i].fields.ID_LINK;
        var link_name = "link_" + link_id;
        var start_index = nodes_list_name.indexOf("node_" + link_database[i].fields.START);
        var end_index = nodes_list_name.indexOf("node_" + link_database[i].fields.END);
        var start_node = nodes_list[start_index];
        start_node.addLink(link_name);

        var end_node = nodes_list[end_index];
        end_node.addLink(link_name);
        if (start_node.shape.x <= end_node.shape.x) {
            var new_link = new TOOL2D.Draw_link({
                startNode: start_node,
                endNode: end_node,
                rootObject: this.rootObject,
                lineColor: createjs.Graphics.getRGB(0, 255, 56),
                lineSize: 1,
            })
            this.links_list.push(new_link);
        }
        else {
            var new_link = new TOOL2D.Draw_link({
                startNode: start_node,
                endNode: end_node,
                rootObject: this.rootObject,
                lineColor: createjs.Graphics.getRGB(89, 0, 56),
                lineSize: 1,
            })
            this.links_list.push(new_link);
        }
        this.links_list_name.push(link_name);
    }
}
TOOL2D.Draw_all_links.prototype.Acess_item = function (link_name) {
    var link_index = this.link_list_name.indexOf(link_name);
    var link = this.link_list[link_index];
    return link;
}

/**
* Draw multiple offset of a node on top of canvas.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * strokeSize (optional) - the size of the out
    *   * strokeColor (optional) - the createjs color for the stroke
    *   * fillColor (optional) - the createjs color for the fill
    *   * radius (optional) - the createjs radius for the circle
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * name (optional) - name of node
    *   * x_offset (optional) - offset along x axis
    *   * y_offset (optional) - offset along y axis
    *   * number_along_x (optional) - number offset nodes along x axis
    *   * number_along_y (optional) - number offset nodes along y axis
*/

TOOL2D.Draw_offset_nodes = function (options) {
    var that = this;
    options = options || {};
    this.involve_links = [];
    this.Scalesize = options.size || 0.5;
    this.name = options.name || "node";
    this.scaleText = options.scaleText || 0.1
    this.strokeSize = options.strokeSize || 0.1;
    this.strokeColor = options.strokeColor || createjs.Graphics.getRGB(0, 0, 0);
    this.fillColor = options.fillColor || createjs.Graphics.getRGB(255, 0, 0);
    this.radius = options.radius || 0.5
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.x_offset = options.x_offset || 40;
    this.y_offset = options.y_offset || 40;
    this.number_along_x = options.number_along_x || 3;
    this.number_along_y = options.number_along_y || 3;
}
TOOL2D.Draw_offset_nodes.prototype.Draw = function (start_id, startX, startY) {
    id = parseInt(start_id);

    for (var i = 0; i <= this.number_along_x; i++) {
        for (var j = 0; j <= this.number_along_y; j++) {
            console.log(id);
            id += 1;
            var create_node = new TOOL2D.Draw_node({
                name: "node_" + id,
                size: this.Scalesize,
                strokeSize: 1,
                rootObject: this.rootObject,
                strokeColor: this.strokeColor,
                fillColor: this.fillColor,
                callback: this.callback,
                radius: 3,
                scaleText: 1.0
            })
            x_coor = startX + i * this.x_offset;
            y_coor = startY + j * this.y_offset;
            create_node.shape.x = x_coor
            create_node.shape.y = y_coor
            create_node.addText(id, x_coor, y_coor);

        }
    }
}
TOOL2D.Draw_offset_nodes.prototype.addText = function (text, posX, posY) {
    this.enable_Text = true;
    console.log('ok')
    this.Text_node = new createjs.Text(text, "10px Arial", "#ff7700");
    this.Text_node.textBaseline = "alphabetic";
    this.Text_node.name = text;
    this.rootObject.addChild(this.Text_node);
    this.Text_node.scaleX = this.scaleText;
    this.Text_node.scaleY = this.scaleText;
    this.Text_node.x = posX - 5;
    this.Text_node.y = posY - 5;
}
TOOL2D.Draw_node.prototype.Remove_node = function () {
    this.rootObject.removeChild(this.shape);
    if (this.enable_Text === true) {

        this.rootObject.removeChild(this.Text_node);
    }
}
/**
* Draw a new link between 2 nodes on top of canvas.
*
* @constructor
* @param options - object with following keys:
    *   * size (optional) - the size of the  arrowline
    *   * Scalesize (optional) - the size of the circle
    *   * strokeSize (optional) - the stroke size of line.
    *   * lineSize (optional) - the size of the out
    *   * callback (otional) - the callback function for press event
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * name (optional) - name of link(E.g "link_2")
    *   * startNode - start node of link
    *   * endNode - end node of link
    *   * dir (optional) - dir of link
    *   * enableArrow (optional) - Turn Arrowhead
*/
TOOL2D.Draw_arrowline = function (options) {
    var that = this;
    options = options || {};
    this.height_robot = 20;
    this.dir = options.dir || 0;
    this.size = options.size || 3;
    this.Scalesize = options.Scalesize || 0.5;
    this.name = options.name || "link";
    this.scaleText = options.scaleText || 0.1
    this.lineSize = options.lineSize || 0.1;
    this.callback = options.callback;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.startNode = options.startNode;
    this.endNode = options.endNode;
    this.strokeSize = options.strokeSize;
    this.enable_Text = false;
    this.arrow_container = new createjs.Container();
    this.enableArrow = options.enableArrow
}
TOOL2D.Draw_arrowline.prototype.drawLine = function (line_color) {
    this.line = new createjs.Shape();
    this.line.name = this.name;
    this.line.graphics.clear();
    this.line.graphics.setStrokeStyle(this.lineSize);
    this.line.graphics.beginStroke(line_color);
    this.line.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.line.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.rootObject.addChild(this.line);
}
TOOL2D.Draw_arrowline.prototype.turnLock = function () {
    var angle = this.lineAngle();
    var color = createjs.Graphics.getRGB(0, 139, 139, 0.15);
    if(this.enableArrow === true)
    {
        this.modify_arrowhead(this.arrow_container.getChildAt(0), this.endNode.shape.x, this.endNode.shape.y, angle, color);

    }
    this.line.graphics.clear();
    this.line.graphics.setStrokeStyle(this.lineSize);
    this.line.graphics.beginStroke(color);
    this.line.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.line.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.line.graphics.endStroke();
    this.line.graphics.endFill();

}
TOOL2D.Draw_arrowline.prototype.activeLink = function(){
    var angle = this.lineAngle();
    var color = createjs.Graphics.getRGB(255, 0, 0, 1);
    if(this.enableArrow === true)
    {
        this.modify_arrowhead(this.arrow_container.getChildAt(0), this.endNode.shape.x, this.endNode.shape.y, angle, color);
    }
    this.line.graphics.clear();
    this.line.graphics.setStrokeStyle(this.lineSize);
    this.line.graphics.beginStroke(color);
    this.line.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.line.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.line.graphics.endStroke();
    this.line.graphics.endFill();

}
TOOL2D.Draw_arrowline.prototype.nonactiveLink = function(){
    var angle = this.lineAngle();
    var color = createjs.Graphics.getRGB(0, 0, 0, 1);
    if(this.enableArrow === true)
    {
        this.modify_arrowhead(this.arrow_container.getChildAt(0), this.endNode.shape.x, this.endNode.shape.y, angle, color);
    }
    this.line.graphics.clear();
    this.line.graphics.setStrokeStyle(this.lineSize);
    this.line.graphics.beginStroke(color);
    this.line.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.line.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.line.graphics.endStroke();
    this.line.graphics.endFill();
}

TOOL2D.Draw_arrowline.prototype.addText = function (text) {
    this.enable_Text = true;
    this.Text_link = new createjs.Text(text, "6px Arial", "#7FFF00");
    this.Text_link.textBaseline = "alphabetic";
    this.rootObject.addChild(this.Text_link);
    //this.Text_link.scaleX = this.scaleText;
    //this.Text_link.scaleY = this.scaleText;
    var distance_from_line = 7;
    var link_width = Math.sqrt(Math.pow((this.startNode.shape.x - this.endNode.shape.x), 2) + Math.pow((this.startNode.shape.y - this.endNode.shape.y), 2))
    //console.log("width",link_width)
    var hypotenuse = (0.3 * link_width)
    var small_angle = Math.atan(distance_from_line / hypotenuse)
    var small_hypotenuse = Math.sqrt(Math.pow(hypotenuse, 2) + Math.pow(distance_from_line, 2));
    if (this.endNode.shape.x >= this.startNode.shape.x) {
        var link_angle = Math.atan(Math.abs(this.startNode.shape.y - this.endNode.shape.y) / Math.abs(this.startNode.shape.x - this.endNode.shape.x - 0.001))

        //var foot_x = hypoteus*Math.cos(link_angle) + this.startNode.shape.x;
        //var foot_y = hypoteus*Math.sin(link_angle) + this.endNode.shape.y;
        var total_angle = small_angle + link_angle;
        this.Text_link.x = parseInt(small_hypotenuse * Math.cos(total_angle)) + this.startNode.shape.x;
        if (this.endNode.shape.y < this.startNode.shape.y) {
            this.Text_link.y = this.startNode.shape.y - parseInt(small_hypotenuse * Math.sin(total_angle));

        }
        else {
            this.Text_link.y = parseInt(small_hypotenuse * Math.sin(total_angle)) + this.startNode.shape.y;

        }


    }
    else if (this.startNode.shape.x > this.endNode.shape.x) {
        var link_angle = Math.atan(Math.abs(this.startNode.shape.x - this.endNode.shape.x) / Math.abs(this.startNode.shape.y - this.endNode.shape.y - 0.001))

        var total_angle = small_angle + link_angle;

        this.Text_link.x = this.startNode.shape.x - parseInt(small_hypotenuse * Math.sin(total_angle));
        if (this.endNode.shape.y < this.startNode.shape.y) {
            this.Text_link.y = this.startNode.shape.y - parseInt(small_hypotenuse * Math.sin(total_angle));

        }
        else if (this.endNode.shape.y = this.startNode.shape.y) {
            this.Text_link.y = this.startNode.shape.y - distance_from_line
        }
        else {
            this.Text_link.y = parseInt(small_hypotenuse * Math.sin(total_angle)) + this.startNode.shape.y;

        }
    }

}
TOOL2D.Draw_arrowline.prototype.removeText = function () {
    this.rootObject.removeChild(this.Text_link);
}
TOOL2D.Draw_arrowline.prototype.arrowhead = function (posX, posY, angle, color) {

    var headLen = this.height_robot / 3;
    var headWidth = headLen * 2.0 / 3.0;
    var arrow_head = new createjs.Shape();
    arrow_head.graphics.clear();
    arrow_head.graphics.setStrokeStyle(this.strokeSize);
    arrow_head.graphics.beginStroke(color);
    arrow_head.graphics.beginFill(color);
    arrow_head.graphics.moveTo(this.size - 3, 0);
    arrow_head.graphics.lineTo(this.size - headLen, headWidth / 2.0);
    arrow_head.graphics.lineTo(this.size - headLen, -headWidth / 2.0);
    arrow_head.graphics.closePath();
    arrow_head.graphics.endFill();
    arrow_head.graphics.endStroke();
    arrow_head.rotation = angle;
    arrow_head.x = posX - 6 * Math.cos(angle * 3.14 / 180);
    arrow_head.y = posY - 6 * Math.sin(angle * 3.14 / 180);
    return arrow_head;
}
TOOL2D.Draw_arrowline.prototype.Remove_arrowline = function () {
    this.rootObject.removeChild(this.arrow_container);
    this.rootObject.removeChild(this.line);

    if (this.enable_Text === true) {


    }

}
TOOL2D.Draw_arrowline.prototype.Draw_arrowline = function () {

    var angle = this.lineAngle();
    var color = createjs.Graphics.getRGB(0, 0, 0, 0.5);
    if (this.enableArrow === true) {

        if (this.dir === 0) {
            color = createjs.Graphics.getRGB(0, 255, 0, 0.4);
        }
        else if (this.dir === 1) {
            color = createjs.Graphics.getRGB(200, 50, 0, 0.4);
        }
        else if (this.dir === 2) {
            color = createjs.Graphics.getRGB(100, 50, 150, 0.4);
        }
        else if (this.dir === 3) {
            color = createjs.Graphics.getRGB(20, 50, 150, 0.4);
        }
        else if (this.dir === 4) {
            color = createjs.Graphics.getRGB(90, 70, 130, 0.4);
        }
        var arrow = this.arrowhead(this.endNode.shape.x, this.endNode.shape.y, angle, color);
        this.arrow_container.addChild(arrow);
        this.rootObject.addChild(this.arrow_container);
    }
    this.drawLine(color)
}
TOOL2D.Draw_arrowline.prototype.callback_update = function () {
    var angle = this.lineAngle();
    var color;
    if (this.dir === 0) {
        color = createjs.Graphics.getRGB(0, 255, 0, 0.7);
    }
    else if (this.dir === 1) {
        color = createjs.Graphics.getRGB(200, 50, 0, 0.7);

    }
    else if (this.dir === 2) {
        color = createjs.Graphics.getRGB(100, 50, 150, 0.7);

    }
    else if (this.dir === 3) {
        color = createjs.Graphics.getRGB(20, 50, 150, 0.7);

    }
    this.modify_arrowhead(this.arrow_container.getChildAt(0), this.endNode.shape.x, this.endNode.shape.y, angle, color);
    this.line.graphics.clear();
    this.line.graphics.setStrokeStyle(this.lineSize);
    this.line.graphics.beginStroke(color);
    this.line.graphics.moveTo(this.startNode.shape.x, this.startNode.shape.y);
    this.line.graphics.lineTo(this.endNode.shape.x, this.endNode.shape.y);
    this.line.graphics.endStroke();
    this.line.graphics.endFill();
}
TOOL2D.Draw_arrowline.prototype.lineAngle = function () {
    var val = (this.startNode.shape.y - this.endNode.shape.y) / (this.startNode.shape.x - this.endNode.shape.x)
    var angle = Math.atan(val) * 180 / 3.14;
    if (this.startNode.shape.x >= this.endNode.shape.x) {
        angle = angle - 180;
    }
    return angle;
}
TOOL2D.Draw_arrowline.prototype.modify_arrowhead = function (arrow_head, posX, posY, angle, color) {
    var headLen = this.height_robot / 3;
    var headWidth = headLen * 2.0 / 3.0;
    arrow_head.graphics.clear();
    arrow_head.graphics.setStrokeStyle(this.strokeSize);
    arrow_head.graphics.beginStroke(color);
    arrow_head.graphics.beginFill(color);
    arrow_head.graphics.moveTo(this.size - 3, 0);
    arrow_head.graphics.lineTo(this.size - headLen, headWidth / 2.0);
    arrow_head.graphics.lineTo(this.size - headLen, -headWidth / 2.0);
    arrow_head.graphics.closePath();
    arrow_head.graphics.endFill();
    arrow_head.graphics.endStroke();
    arrow_head.rotation = angle;
    arrow_head.x = posX - 6 * Math.cos(angle * 3.14 / 180);
    arrow_head.y = posY - 6 * Math.sin(angle * 3.14 / 180);
}
/**
* Draw all links from database.
*
* @constructor
* @param options - object with following keys:
    *   * Scalesize (optional) - the size of the circle
    *   * lineColor (optional) - the createjs color for the line
    *   * rootObject (optional) - the rootObject
    *   * scaleText (optional) - the scale of Text
    *   * strokeSize (optional) - the stroke size
    *   * enableArrow (optional) - Turn on Arrow
    *   * lineSize(optional) - Line size value
*/
TOOL2D.Draw_all_links_v2 = function (options) {
    var that = this;
    this.links_list = [];
    this.links_list_name = [];
    options = options || {};
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.lineColor = options.fillColor || createjs.Graphics.getRGB(0, 0, 0);
    this.rootObject = options.rootObject || new createjs.Stage();
    this.lineSize = options.lineSize || 2;
    this.enable_Text = false;
    this.enableArrow = options.enableArrow
}
TOOL2D.Draw_all_links_v2.prototype.Draw = function (link_database, nodes_list, nodes_list_name) {
    for (var i in link_database) {
        var link_id = link_database[i].fields.ID_LINK;
        var link_name = "link_" + link_id;
        var start_index = nodes_list_name.indexOf("node_" + link_database[i].fields.START);
        var end_index = nodes_list_name.indexOf("node_" + link_database[i].fields.END);
        var link_dir = parseInt(link_database[i].fields.DIR);
        var start_node = nodes_list[start_index];
        start_node.addLink(link_name);
        var end_node = nodes_list[end_index];
        end_node.addLink(link_name);
        var new_link = new TOOL2D.Draw_arrowline({
            size: 2,
            Scalesize: 2,
            startNode: start_node,
            endNode: end_node,
            rootObject: this.rootObject,
            lineSize: this.lineSize,
            dir: link_dir,
            name: link_name,
            enableArrow: this.enableArrow
        })
        new_link.Draw_arrowline();
        this.links_list.push(new_link);
        this.links_list_name.push(link_name);
    }
}
TOOL2D.Draw_all_links_v2.prototype.Acess_item = function (link_name) {

    var link_index = this.links_list_name.indexOf(link_name);
    var link = this.links_list[link_index];
    return link;
}

TOOL2D.Draw_all_links_v2.prototype.Remove_link = function (link_name) {
    var link_index = this.links_list_name.indexOf(link_name);
    this.links_list[link_index].endNode.RemoveInvolveLink(link_name);
    this.links_list[link_index].startNode.RemoveInvolveLink(link_name);
    this.links_list[link_index].Remove_arrowline();
    this.links_list.splice(link_index, 1);
    this.links_list_name.splice(link_index, 1);
}
/**
* Draw all links from database.
*
* @constructor
* @param options - object with following keys:
    *   * width (optional) - the width of the AGV
    *   * height (optional) - the height of the AGV
    *   * name (optional) - the name of the AGV
    *   * rootObject (optional) - the rootObject for display
    *   * scaleText (optional) - the scale of Text
    *   * Scalesize (optional) - the Scalesize of map.
    *   * resolution_map (optional) - the resolution of map (m/pixel)
*/
TOOL2D.AGV = function (options) {
    var that = this;
    options = options || {};
    var width = options.width;
    var height = options.height;
    this.pixelWidth = ConvertMetToPixel(width);
    this.pixelHeight = ConvertMetToPixel(height);
    this.name = options.name || 'AGV';
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.resolution = options.resolution || 0.05;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.strokeSize = 1;
    this.strokeColor = createjs.Graphics.getRGB(0, 255, 56, 0.5);
    this.displayWidth = 20;
    this.displayHeight = 20;
    this.BorderRound = 3;
}
TOOL2D.AGV.prototype.Draw = function () {
    this.AGV_shape = new createjs.Shape();
    this.AGV_shape.name = this.name;
    this.AGV_shape.on("pressmove", this.callback)
    this.AGV_shape.graphics.clear();
    this.AGV_shape.graphics.setStrokeStyle(this.strokeSize);
    this.AGV_shape.graphics.beginStroke(this.strokeColor);
    this.AGV_shape.graphics.beginFill(this.fillColor);
    this.AGV_shape.graphics.drawRoundRect(0 - this.displayWidth / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, this.BorderRound);
    this.AGV_shape.graphics.endFill();
    this.AGV_shape.graphics.drawRect(0 - this.pixelWidth / 2, 0 - this.pixelHeight / 2, this.pixelWidth, this.pixelHeight);
    this.AGV_shape.graphics.endStroke();
    this.rootObject.addChild(this.AGV_shape);
}
TOOL2D.AGV.prototype.ConvertMetToPixel = function (realData) {
    var PixelCoordinate = (realData * this.ScaleSize) / this.resolution;
    return PixelCoordinate;
}
TOOL2D.AGV.prototype.ConvertPixelToMet = function (pixelData) {
    var RealCoordinate = pixelData * this.resolution / (realData * this.ScaleSize);
    return RealCoordinate;
}
TOOL2D.AGV.prototype.UpdatePosition = function (posX, posY) {
    this.AGV_shape.x = posX;
    this.AGV_shape.y = posY;
}
TOOL2D.AGV.prototype.GetXCoordinate = function () {
    return this.AGV_shape.x;
}
TOOL2D.AGV.prototype.GetYCoordinate = function () {
    return this.AGV_shape.y;
}
TOOL2D.AGV.prototype.Remove_link = function (link_name) {

}
/**
* Draw a Port.
*
* @constructor
* @param options - object with following keys:
    *   * width (optional) - the width of the AGV
    *   * height (optional) - the height of the AGV
    *   * name (optional) - the name of the AGV
    *   * rootObject (optional) - the rootObject for display
    *   * scaleText (optional) - the scale of Text
    *   * Scalesize (optional) - the Scalesize of map.
    *   * resolution_map (optional) - the resolution of map (m/pixel)
    *   * Port size (optional) - the icon size of map(pixel)
*/
TOOL2D.Port = function (options) {
    var that = this;
    options = options || {};
    var width = options.width;
    var height = options.height;
    this.pixelWidth = this.ConvertMetToPixel(width);
    this.pixelHeight = this.ConvertMetToPixel(height);
    this.name = options.name || 'AGV';
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.resolution = options.resolution || 0.05;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.strokeSize = 1;
    this.strokeColor = createjs.Graphics.getRGB(0, 255, 56, 0.5);
    this.BorderRound = 3;
    this.displayWidth = 50;
    this.displayHeight = 23;
    this.Port_state = false;
}
TOOL2D.Port.prototype.Draw = function (posX, posY) {
    this.PortShape = new createjs.Shape();
    this.PortShape.graphics.clear();
    this.PortShape.graphics.setStrokeStyle(this.strokeSize);
    this.PortShape.graphics.beginStroke(this.strokeColor);
    this.PortShape.graphics.beginFill(createjs.Graphics.getRGB(0, 255, 255, 0.5));
    this.PortShape.graphics.drawRoundRect(0 - this.displayWidth / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, 4);
    this.PortShape.graphics.endFill();
    this.PortShape.graphics.endStroke();
    this.PortShape.graphics.beginFill(createjs.Graphics.getRGB(255, 0, 0, 0.7));
    this.PortShape.graphics.drawRoundRect(0 - this.displayWidth / 4, 0 - this.displayHeight / 2, this.displayWidth / 2, this.displayHeight / 2, 2);
    this.PortShape.graphics.endFill();
    this.StateText = new createjs.Text("", "7px Arial", "black");
    this.StateText.textBaseline = "alphabetic";
    this.StateText.textAlign = "center";
    this.StateText.x = posX;
    this.StateText.y = posY - 5;
    this.rootObject.addChild(this.PortShape, this.StateText);
    this.UpdatePosition(posX, posY);
    this.addText(this.name, posX, posY + 10);
    //this.addStateBox(posX,posY);
}
TOOL2D.Port.prototype.UpdatePosition = function (posX, posY) {
    this.PortShape.x = posX;
    this.PortShape.y = posY;
}
TOOL2D.Port.prototype.addText = function (text, posX, posY) {
    this.Text_Port = new createjs.Text(text, "7px Arial", "black");
    this.Text_Port.textBaseline = "alphabetic";
    this.Text_Port.textAlign = "center";
    this.rootObject.addChild(this.Text_Port);
    this.Text_Port.x = posX;
    this.Text_Port.y = posY;
}
TOOL2D.Port.prototype.UpdateState = function (state) {
    var color;
    if (state === true) {
        this.StateText.text = "Up";
        color = createjs.Graphics.getRGB(0, 255, 0, 0.7)
    }
    else {
        this.StateText.text = "Down"
        color = createjs.Graphics.getRGB(255, 0, 0, 0.7)

    }
    this.UpdateColor(color)
}
TOOL2D.Port.prototype.UpdateColor = function (color) {
    this.PortShape.graphics.clear();
    this.PortShape.graphics.setStrokeStyle(this.strokeSize);
    this.PortShape.graphics.beginStroke(this.strokeColor);
    this.PortShape.graphics.beginFill(createjs.Graphics.getRGB(0, 255, 255, 0.5));
    this.PortShape.graphics.drawRoundRect(0 - this.displayWidth / 2, 0 - this.displayHeight / 2, this.displayWidth, this.displayHeight, 4);
    this.PortShape.graphics.endFill();
    this.PortShape.graphics.endStroke();
    this.PortShape.graphics.beginFill(color);
    this.PortShape.graphics.drawRoundRect(0 - this.displayWidth / 4, 0 - this.displayHeight / 2, this.displayWidth / 2, this.displayHeight / 2, 2);
    this.PortShape.graphics.endFill();

}
TOOL2D.Port.prototype.ConvertMetToPixel = function (realData) {
    var PixelCoordinate = (realData * this.ScaleSize) / this.resolution;
    return PixelCoordinate;
}
TOOL2D.Port.prototype.ConvertPixelToMet = function (pixelData) {
    var RealCoordinate = pixelData * this.resolution / (realData * this.ScaleSize);
    return RealCoordinate;
}
TOOL2D.Port.prototype.GetXCoordinate = function () {
    return this.PortShape.x;
}
TOOL2D.Port.prototype.GetYCoordinate = function () {
    return this.PortShape.y;
}

/**
* Draw all Ports from database.
*
* @constructor
* @param options - object with following keys:
    *   * width (optional) - the width of the AGV
    *   * height (optional) - the height of the AGV
    *   * name (optional) - the name of the AGV
    *   * rootObject (optional) - the rootObject for display
    *   * scaleText (optional) - the scale of Text
    *   * Scalesize (optional) - the Scalesize of map.
    *   * resolution_map (optional) - the resolution of map (m/pixel)
*/
TOOL2D.Draw_all_Ports = function (options) {
    var that = this;
    options = options || {};
    this.Scalesize = options.Scalesize || 0.5;
    this.scaleText = options.scaleText || 0.1;
    this.strokeSize = options.strokeSize || 0.1;
    this.resolution = options.resolution || 0.05;
    this.rootObject = options.rootObject || new createjs.Stage();
    this.Port_list = [];
}
TOOL2D.Draw_all_Ports.prototype.Draw = function (Port_data) {
    for (var i in Port_data) {
        var Port_X = parseInt(Port_data[i].fields.Monitor_X);
        var Port_Y = parseInt(Port_data[i].fields.Monitor_Y);
        var Port_Direct = parseInt(Port_data[i].fields.Direct);
        var new_Port = new TOOL2D.Port({
            width: 100,
            height: 200,
            Scalesize: this.Scalesize,
            scaleText: 0.1,
            strokeSize: 0.1,
            rootObject: this.rootObject,
            name: Port_data[i].fields.PORT_name
        })
        if (Port_Direct === 0) {
            Port_X = Port_X + 10 + new_Port.displayWidth / 2;
        }
        else if (Port_Direct === 1) {
            Port_X = Port_X - (new_Port.displayWidth / 2) - 10;
            Port_Y = Port_Y;
        }
        else if (Port_Direct === 2) {
            Port_X = Port_X;
            Port_Y = Port_Y + 10 + new_Port.displayHeight / 2;
        }
        else if (Port_Direct === 3) {
            Port_X = Port_X;
            Port_Y = Port_Y - 10 - new_Port.displayHeight / 2;
        }
        new_Port.Draw(Port_X, Port_Y)
        new_Port.UpdateState(true);
    }
    this.Port_list.push(new_Port);
}





