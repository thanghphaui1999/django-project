var height_image = 800;//default 400
var width_image = 490;//default 400
var map_ratio = 0.02
var socketPort = 4000;// port 
var IP_domain= "192.168.100.33";//IP domain of page
module.exports = {
    height_image_data: height_image,
    width_image_data: width_image,
    map_ratio_data: map_ratio,
    socketPort_data: socketPort,
    IP_domain_data: IP_domain

}
