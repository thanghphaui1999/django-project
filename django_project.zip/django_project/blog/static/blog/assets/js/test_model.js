$("#new_frame").onmousedown(function(event){
    console.log(event.client.X,event.client.Y)

})