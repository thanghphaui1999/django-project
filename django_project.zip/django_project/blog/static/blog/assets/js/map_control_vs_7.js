; // Connect to ROS.
var ros = new ROSLIB.Ros({
  url: 'ws://localhost:9090'
});
ros.on('start', function () {
  console.log("Connected to ROS");
  document.getElementById("status").innerHTML = "Connected";
});
ros.on('error', function (error) {
  console.log("Error happened when connect to ROS", error);
  document.getElementById("status").innerHTML = "Error";
});
ros.on('close', function () {
  console.log('Stop connecting to ROS');
  document.getElementById("status").innerHTML = "Closed";
});

var txt_listener = new ROSLIB.Topic({
  ros: ros,
  name: '/txt_msg',
  messageType: 'std_msgs/String'
});

txt_listener.subscribe(function (m) {
  document.getElementById("msg").innerHTML = m.data;
  move(1, 0);
});

cmd_vel_listener = new ROSLIB.Topic({
  ros: ros,
  name: "/cmd_vel",
  messageType: 'geometry_msgs/Twist'
});


var selectedPointIndex = null
move = function (linear, angular) {
  var twist = new ROSLIB.Message({
    linear: {
      x: linear,
      y: 0,
      z: 0
    },
    angular: {
      x: 0,
      y: 0,
      z: angular
    }
  });
  cmd_vel_listener.publish(twist);
}

createJoystick = function () {
  var options = {
    zone: document.getElementById('zone_joystick'),
    threshold: 0.1,
    position: { left: 50 + '%' },
    mode: 'static',
    size: 140,
    color: '#A9A9A9',
  };
  manager = nipplejs.create(options);

  linear_speed = 0;
  angular_speed = 0;

  manager.on('start', function (event, nipple) {
    timer = setInterval(function () {
      move(linear_speed, angular_speed);
    }, 25);
  });

  manager.on('move', function (event, nipple) {
    max_linear = 5.0; // m/s
    max_angular = 2.0; // rad/s
    max_distance = 75.0; // pixels;
    linear_speed = Math.sin(nipple.angle.radian) * max_linear * nipple.distance / max_distance;
    angular_speed = -Math.cos(nipple.angle.radian) * max_angular * nipple.distance / max_distance;
  });

  manager.on('end', function () {
    if (timer) {
      clearInterval(timer);
    }
    self.move(0, 0);
  });
}
var z_quar = 0;
var w_quar = 0;
var est_angular = 0;
var setup_missons = document.createElement("div");
setup_missons.id = "misson_form";
setup_missons.innerHTML = `<div class = "container-fluid pt-2 pb-3 rounded" style = 
"width:97%;background-color: rgb(43, 214, 226);box-shadow: 5px 10px rgb(37, 35, 35);"> 
<form>
<div class = "form-inline">
    <label class="my-1 mr-2" for="inlineFormCustomSelectPref"><b>Number of goals</b></label>
    <select class="custom-select my-1 mr-sm-2" id="choose_number">
        <option selected>Choose</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
        <option value="5">5</option>
        <option value="6">6</option>
        <option value="7">7</option>
    </select>
    <button type="submit" class="btn btn-primary mb-2" id = "take_done" onclick = "complete_select()">Ok</button>
</div>
</form>
</div>`
var setup_map_content = document.createElement("div");
setup_map_content.id = "setup_map_form";
setup_map_content.innerHTML =
  `
  <form class = "px-4 pt-2 pb-3 rounded" style = "background-color: rgb(43, 214, 226);box-shadow: 5px 10px rgb(37, 35, 35);">
    <div class = "py-3 mx-auto">
      <h4 style = "margin:auto;"><b>SETUP NEW AREA</b></h4>  
    </div>                               
    <div class = "form-group">
        <label for = "name_section">Name: </label>
        <input type = "text" id = "name_section" class = "float-right" placeholder="Name of area">
    </div>
    <div class = "form-group">
      <label for = "length_section">Length: </label>
      <input type = "text" id ="length_section" class = "float-right" placeholder="Length of area">
    </div>
    <div for = "form-group">
      <label for = "width_section">Width: </label>
      <input type = "text" id = "width_section" class ="float-right" placeholder="Width of area">
    </div>
    <div class = "py-1 mx-auto">
      <p class = "float-center mx-auto"><b>SETUP COLOR</b></p>
    </div>   
    <div class = "form-group">
      <label class = "my-1 mr-2" for="red_section">Red range</label>
      <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="red_section" style = "width: 60%">
    </div>
    <div class = "form-group">
      <label class = "my-1 mr-2" for="green_section">Green range</label>
      <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="green_section" style = "width: 60%">
    </div>
    <div class = "form-group">
      <label class = "my-1 mr-2" for="blue_section">Blue range</label>
      <input type = "range" class="form-range float-right my-1" min = "0" max = "255" step = "1" id="blue_section" style = "width: 60%">
    </div>
    <div>
      <button class="btn btn-primary" type="submit" onclick = "setup_new_area">Set up</button>
      <button class="btn btn-primary" type="submit" onclick = "done_setup"></button>
    </div>
  </form>
`
var setup_static_pos = document.createElement('div');
setup_static_pos.id = "static-pos";
setup_static_pos.innerHTML =
  window.onload = function () {
    createJoystick();
    var index = 0;
    var zoomLevel = 50;
    var x_coordinate = 0;
    var y_coordinate = 0;
    var positionVec3 = new ROSLIB.Vector3(null);
    var orientation = new ROSLIB.Quaternion({ x: 0, y: 0, z: 0, w: 1.0 });
    var goal_array = [];
    var goal_markers = [];
    var goal_for_send = [];
    var cancel_state = false;
    var enable_angular = false;
    var first_point_x = 0;
    var first_point_y = 0;
    var second_point_x = 0;
    var second_point_y = 0;
    var display_trace = true;
    var display_path = true;
    var complete_misson = true;
    var total_goal = 0;
    var ready_set = 0;
    var misson_text = [];
    var enable_setup_area = false;
    // Create the main viewer for AGV robot
    var viewer = new ROS2D.Viewer({
      divID: 'map',
      width: 600,
      height: 600,
      background: '#DCDCDC'
    });
    var edit_text = new createjs.Text("New misson", "1px Arial", "#ff7700");
    edit_text.x = 10;
    edit_text.y = -10;
    edit_text.textBaseline = "alphabetic";
    var gridClient = new ROS2D.OccupancyGridClient({
      ros: ros,
      rootObject: viewer.scene
    });
    // Scale the canvas to fit to the map
    gridClient.on('change', function () {
      viewer.scaleToDimensions(gridClient.currentGrid.width, gridClient.currentGrid.height);
    });
    //------------------------------------
    var robot_direction = new ROS2D.ArrowShape({
      size: 1,
      strokeSize: 0.07,
      pulse: false,
      fillColor: createjs.Graphics.getRGB(0, 255, 0, 0.65)
    });
    //show pLANE PATH of AGV
    var pathShape = new ROS2D.PathShape({
      strokeSize: 0.3,
      strokeColor: createjs.Graphics.getRGB(255, 255, 0, 0.5),
    });
    //create arrow of robot in map
    var robotMarker = new ROS2D.NavigationArrow({
      size: 0.5,
      strokeSize: 0.3,
      pulse: true,
      fillColor: createjs.Graphics.getRGB(255, 255, 0, 0.65)
    });

    var traceShape = new ROS2D.TraceShape({
      strokeSize: 0.1,
      strokeColor: createjs.Graphics.getRGB(255, 0, 0, 1),
      maxPoses: 250
    });
    var path_listener = new ROSLIB.Topic({
      ros: ros,
      name: '/move_base_node/SBPLLatticePlanner/plan',
      messageType: 'nav_msgs/Path'
    });
    var poseTopic = new ROSLIB.Topic({
      ros: ros,
      name: '/amcl_pose',
      messageType: 'geometry_msgs/PoseWithCovarianceStamped'
    });
    var goalTopic = new ROSLIB.Topic({
      ros: ros,
      name: '/move_base/goal',
      messageType: 'move_base_msgs/MoveBaseActionGoal'
    });

    var main_AGV = new ROS2D.Add_Robot2({
      strokeSize: 0.05,
      size: 0.4,
      width: 0.59,
      height: 0.95,

      strokeColor: createjs.Graphics.getRGB(255, 255, 0, 0.5),
      fillColor: createjs.Graphics.getRGB(0, 255, 0, 0.5),
    })

    var actionClient = new ROSLIB.ActionClient({
      ros: ros,
      serverName: '/move_base',
      actionName: 'move_base_msgs/MoveBaseAction'
    });
    //zoom and focus on map.
    var zoomView = new ROS2D.ZoomView({
      rootObject: viewer.scene
    });
    var myimage = viewer.scene.canvas;//document.getElementById("map");
    if (myimage.addEventListener) {
      // IE9, Chrome, Safari, Opera
      myimage.addEventListener("mousewheel", MouseWheelHandler, false);
      // Firefox
      myimage.addEventListener("DOMMouseScroll", MouseWheelHandler, false);

    }
    // IE 6/7/8
    else myimage.attachEvent("onmousewheel", MouseWheelHandler);

    function MouseWheelHandler(e) {
      // cross-browser wheel delta
      var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));

      if (delta > 0) {
        if (zoomLevel > 0) {
          zoomView.zoom(1.1);
          zoomLevel = zoomLevel - 5;
        }
      }
      else {
        if (zoomLevel < 300) {
          zoomView.zoom(1 / 1.1);
          zoomLevel = zoomLevel + 5;
        }
      }

      e.preventDefault();
      return false;
    }

    function getMousePos(canvas, evt) {
      var rect = canvas.getBoundingClientRect();
      return {
        x: evt.clientX - rect.left,
        y: evt.clientY - rect.top
      };
    }

    viewer.scene.canvas.addEventListener('mousemove', function (evt) {
      var mousePos = getMousePos(viewer.scene.canvas, evt);

      zoomView.startZoom(mousePos.x, mousePos.y);
    }, false);


    //------------------------------------

    //public goal to ROS 
    send_goal = function () {

      ready_set += 1;

      if (ready_set <= total_goal) {
        var goal_marker = new ROS2D.Robot_Goal({
          strokeSize: 0.1,
          size: 0.4,
          width: 0.59,
          height: 0.95,

          strokeColor: createjs.Graphics.getRGB(0, 255, 255, 0.5),
          fillColor: createjs.Graphics.getRGB(0, 255, 255, 0.5),

        })

        if (enable_setup_area === true) {
          var index_area = document.querySelector('#choose_area').selectedIndex - 1;
          var posx = parseFloat(data_json[index_area].fields.posX);
          var posy = parseFloat(data_json[index_area].fields.posY);
          var quaZ = parseFloat(data_json[index_area].fields.quaZ);
          var quaW = parseFloat(data_json[index_area].fields.quaW);
          var degreeZ = - Math.atan2(2 * (quaW * quaZ), 1 - 2 * (quaZ * quaZ)) * 180 / Math.PI;
          var object_goal = { x_pos: posx, y_pos: posy, z_ros: -quaZ, w_ros: quaW, show_angular: degreeZ };
          goal_array.push(object_goal);
          goal_marker.arrow_head.x = posx;
          goal_marker.arrow_head.y = -posy;
          goal_marker.arrow_head.rotation = degreeZ;
          goal_markers.push(goal_marker.arrow_head);
          var edit_text = new createjs.Text(ready_set, "1px Arial", "#ff7700");
          edit_text.x = posx;
          edit_text.y = -posy - 0.4;
          edit_text.textBaseline = "alphabetic";
          misson_text.push(edit_text);
          var pos_vector = new ROSLIB.Vector3({ x: posx, y: posy, z: 0 });
          var orien_vector = new ROSLIB.Quaternion({ x: 0, y: 0, z: quaZ, w: quaW });
          var new_pose = new ROSLIB.Pose({
            position: pos_vector,
            orientation: orien_vector
          });
          goal_for_send.push(new_pose);
          enable_setup_area = false;


        }
        else {
          var object_goal = { x_pos: x_coordinate, y_pos: y_coordinate, z_ros: -z_quar, w_ros: w_quar, show_angular: est_angular };
          goal_array.push(object_goal);
          goal_marker.arrow_head.x = x_coordinate;
          goal_marker.arrow_head.y = -y_coordinate;
          goal_marker.arrow_head.rotation = est_angular;
          goal_markers.push(goal_marker.arrow_head);
          var edit_text = new createjs.Text(ready_set, "1px Arial", "#ff7700");
          edit_text.x = x_coordinate;
          edit_text.y = -y_coordinate - 0.4;
          edit_text.textBaseline = "alphabetic";
          misson_text.push(edit_text);
          var pos_vector = new ROSLIB.Vector3({ x: x_coordinate, y: y_coordinate, z: 0 });
          var orien_vector = new ROSLIB.Quaternion({ x: 0, y: 0, z: -z_quar, w: w_quar });
          var new_pose = new ROSLIB.Pose({
            position: pos_vector,
            orientation: orien_vector
          });
          goal_for_send.push(new_pose);
        }
        for (var t = 0; t < goal_markers.length; t++) {
          gridClient.rootObject.addChild(goal_markers[t]);
          gridClient.rootObject.addChild(misson_text[t]);
        }

      }

      else if (ready_set > total_goal) {
        alarm("You only set ", total_goal, " goal.")
      }

    }

    //----------------------------------------------

    //Cancel all mission

    cancel_goal = function () {
      actionClient.cancel();
      for (var i = 0; i < goal_array.length; i++) {
        gridClient.rootObject.removeChild(goal_markers[i]);
        gridClient.rootObject.removeChild(misson_text[i]);
      }

      cancel_state = true;
      goal_markers = [];
      goal_array = [];
      goal_for_send = [];
      ready_set = 0;
      index = 0;
      ready_misson = false;
      misson_text = [];
      alarm("Cancel all missons done")
    }

    var createFunc = function (handlerToCall, discriminator, robotMarker, robot_direction) {
      return discriminator.subscribe(function (pose) {
        traceShape.addPose(pose.pose.pose);
        main_AGV.arrow_head.x = pose.pose.pose.position.x;
        main_AGV.arrow_head.y = -pose.pose.pose.position.y;
        main_AGV.icon_robot.x = pose.pose.pose.position.x;
        main_AGV.icon_robot.y = -pose.pose.pose.position.y;
        var quaZ = pose.pose.pose.orientation.z;
        var quaX = pose.pose.pose.orientation.x;
        var quaY = pose.pose.pose.orientation.y;
        var quaW = pose.pose.pose.orientation.w;
        var degreeZ = - Math.atan2(2 * (quaW * quaZ + quaX * quaY), 1 - 2 * (quaY * quaY + quaZ * quaZ)) * 180 / Math.PI;
        console.log("Robot degree", degreeZ)
        $("#X_val").text(robotMarker.x);
        $("#Y_val").text(robotMarker.y);
        $("#Angular_val").text(degreeZ);
        main_AGV.arrow_head.rotation = degreeZ;
        main_AGV.icon_robot.rotation = degreeZ;
        cmd_vel_listener.subscribe(function (mess) {
          $("#val-1").text(mess.linear.x.toFixed(3));
          $("#val-2").text(mess.angular.z.toFixed(3));
        });
      })
    }

    path_listener.subscribe(function (message) {
      console.log(message);
      pathShape.setPath(message);
      //listener.unsubscribe();
    });
    //-------------------------------------------------
    //setup display

    enable_trace = function () {
      if (display_trace === true) {
        display_trace = false;
        gridClient.rootObject.addChild(traceShape);
        $("#trace_setting").text("Off trace");
      }
      else {
        display_trace = true;
        gridClient.rootObject.removeChild(traceShape);
        $("#trace_setting").text("On trace");

      }
      console.log('display trace', display_trace);
    }
    enable_path = function () {
      if (display_path === true) {
        display_path = false;
        gridClient.rootObject.addChild(pathShape);
        $("#path_setting").text("Off path");

      }
      else {
        display_path = true;
        gridClient.rootObject.removeChild(pathShape);
        $("#path_setting").text("On path");

      }
      console.log('display path', display_path);
    }

    //------------------------------------

    //Add all things into AGV map
    createFunc('subscribe', poseTopic, robotMarker, robot_direction);
    //gridClient.rootObject.addChild(robotMarker);
    gridClient.rootObject.addChild(main_AGV.arrow_head);
    gridClient.rootObject.addChild(main_AGV.icon_robot);



    //-------------------------------------------
    viewer.scene.addEventListener('stagemousedown', function (event) {

      if (selectedPointIndex !== null) {
        selectedPointIndex = null;
      }
      else if (viewer.scene.mouseInBounds === true) {
        var pos = viewer.scene.globalToRos(event.stageX, event.stageY);
        x_coordinate = pos.x;
        y_coordinate = pos.y;
        robot_direction.x = pos.x;
        robot_direction.y = -pos.y;
        first_point_x = 0;
        first_point_y = 0;
        first_point_x = event.stageX;
        first_point_y = event.stageY;
        gridClient.rootObject.addChild(robot_direction);
        enable_angular = true;

      }

    });

    viewer.scene.addEventListener('stagemousemove', event => {
      if (enable_angular === true) {
        second_point_x = event.stageX;
        second_point_y = event.stageY;
        //console.log("show second point: ", second_point_x,second_point_y);
        //var est_distance = Math.sqrt(Math.pow((second_point_x - first_point_x),2) + Math.pow((second_point_y - first_point_y),2));
        var horizon_dis = second_point_x - first_point_x;
        var vertical_dis = second_point_y - first_point_y;
        var bien = vertical_dis / horizon_dis;

        if (Math.abs(horizon_dis) > 0 || Math.abs(vertical_dis) > 0) {
          est_angular = Math.atan(bien) * 180 / Math.PI;
          if (horizon_dis < 0 && vertical_dis < 0) {
            est_angular = -180 + est_angular;
          }
          else if (horizon_dis < 0 && vertical_dis > 0) {
            est_angular = -180 + est_angular;

          }
          robot_direction.rotation = est_angular;

          var radian_convert = est_angular * Math.PI / 180;
          w_quar = Math.cos(radian_convert / 2);
          z_quar = Math.sin(radian_convert / 2);

          orientation.w = w_quar;
          orientation.z = -z_quar;

          //console.log("Show new robot angular:", w_quar,z_quar);
        }
      }
    });

    viewer.scene.addEventListener('stagemouseup', event => {
      enable_angular = false;
      gridClient.rootObject.removeChild(robot_direction);

    });
    //receive state of number goal

    set_number_goals = function () {
      $("#new_frame").append(setup_missons);
      console.log("Set up new misson");
      ready_misson = true;

    }

    start_run = function () {
      var goal = new ROSLIB.Goal({
        actionClient: actionClient,
        goalMessage: {
          target_pose: {
            header: {
              frame_id: 'map'
            },
            pose: goal_for_send[index]
          }
        }
      });
      goal.on('result', function () {
        if (cancel_state === false) {
          alert("Complete a node");
          gridClient.rootObject.removeChild(goal_markers[index]);
          gridClient.rootObject.removeChild(misson_text[index]);
          index = index + 1;
          if (index >= goal_array.length) {
            alert("Complete all missons");
            goal_markers = [];
            goal_array = [];
            goal_for_send = [];
            ready_set = 0;
            index = 0;
            ready_misson = false;
            misson_text = [];
          }
        }
        else {
          alert("Cancel misson");
          cancel_state = false;
        }
      });
      goal.send();
    }
    complete_select = function () {
      total_goal = document.querySelector('#choose_number').selectedIndex;
      console.log("total_goal", total_goal);
      document.querySelector("#misson_form").remove(setup_missons);

    }
    setup_area = function () {
      $("#new_frame").replaceWith(setup_map_content.innerHTML);


    }
    select_area = function () {
      enable_setup_area = true;
      var index = document.querySelector('#choose_area').selectedIndex - 1;
      console.log("index",index)
      var posX = parseFloat(data_json[index].fields.posX);
      var posY = parseFloat(data_json[index].fields.posY);
      var quaW = parseFloat(data_json[index].fields.quaW);
      var quaZ = parseFloat(data_json[index].fields.quaZ);
      var name_area = data_json[index ].fields.name;
      var new_AGV_area = new ROS2D.Add_Robot2(
        {
          strokeSize: 0.05,
          size: 0.4,
          width: 0.59,
          height: 0.95,
          strokeColor: createjs.Graphics.getRGB(0, 0, 255, 1),
          fillColor: createjs.Graphics.getRGB(0, 0, 255, 0.3),
        }
      )
      var degreeZ = - Math.atan2(2 * (quaW * quaZ), 1 - 2 * (quaZ * quaZ)) * 180 / Math.PI;
      new_AGV_area.icon_robot.x = posX;
      new_AGV_area.icon_robot.y = -posY
      new_AGV_area.arrow_head.x = posX;
      new_AGV_area.arrow_head.y = -posY;
      new_AGV_area.arrow_head.rotation = degreeZ;
      new_AGV_area.icon_robot.rotation = degreeZ;
      gridClient.rootObject.addChild(new_AGV_area.arrow_head);
      gridClient.rootObject.addChild(new_AGV_area.icon_robot);

    }
    var load_map_data = function () {
      var select = document.getElementById("choose_area");

      for (var x in data_json) {
        var opt = document.createElement('option');
        opt.value = x;
        opt.innerHTML = data_json[x].fields.name;
        select.appendChild(opt);

        //var posX = parseFloat(data_json[x].fields.posX);
        //var posY = parseFloat(data_json[x].fields.posY);
        //var quaW = parseFloat(data_json[x].fields.quaW);
        //var quaZ = parseFloat(data_json[x].fields.quaZ);
        //var name_area = data_json[x].fields.name;
        //var new_AGV_area = new ROS2D.Add_Robot2(
        // {
        //   strokeSize : 0.05,
        // size: 0.4,
        //width: 0.59,
        //height: 0.95,
        //strokeColor: createjs.Graphics.getRGB(0,0,255,1),
        //fillColor: createjs.Graphics.getRGB(0,0,255,0.3),
        //}
        //)
        //var degreeZ = - Math.atan2(2*(quaW*quaZ), 1 - 2 * (quaZ*quaZ)) * 180/Math.PI;
        //new_AGV_area.icon_robot.x = posX;
        //new_AGV_area.icon_robot.y = -posY
        //new_AGV_area.arrow_head.x = posX;
        //new_AGV_area.arrow_head.y = -posY;
        //new_AGV_area.arrow_head.rotation = degreeZ;
        //new_AGV_area.icon_robot.rotation = degreeZ;
        //gridClient.rootObject.addChild(new_AGV_area.arrow_head);
        //gridClient.rootObject.addChild(new_AGV_area.icon_robot);


      }
    }
    load_map_data();





    //gridClient.rootObject.addChild(edit_text);

    //------------------------------------
    //turn on setup map 

  }













