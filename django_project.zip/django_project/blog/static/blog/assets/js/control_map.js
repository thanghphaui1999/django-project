; // Connect to ROS.
var ros = new ROSLIB.Ros({
  url : 'ws://localhost:9090'
});
ros.on('start', function(){
console.log("Connected to ROS");
document.getElementById("status").innerHTML = "Connected";
});
ros.on('error',function(error){
console.log("Error happened when connect to ROS",error);
document.getElementById("status").innerHTML = "Error";
});
ros.on('close',function(){
console.log('Stop connecting to ROS');
document.getElementById("status").innerHTML = "Closed";
});

var txt_listener = new ROSLIB.Topic({
ros: ros,
name: '/txt_msg',
messageType: 'std_msgs/String'
});

txt_listener.subscribe(function (m) {
document.getElementById("msg").innerHTML = m.data;
move(1, 0);
});

cmd_vel_listener = new ROSLIB.Topic({
ros: ros,
name: "/cmd_vel",
messageType: 'geometry_msgs/Twist'
});




var selectedPointIndex = null
move = function (linear, angular) {
var twist = new ROSLIB.Message({
  linear: {
    x: linear,
    y: 0,
    z: 0
  },
  angular: {
    x: 0,
    y: 0,
    z: angular
  }
});
cmd_vel_listener.publish(twist);
}

createJoystick = function () {
var options = {
  zone: document.getElementById('zone_joystick'),
  threshold: 0.1,
  position: { left: 50 + '%' },
  mode: 'static',
  size: 140,
  color: '#A9A9A9',
};
manager = nipplejs.create(options);

linear_speed = 0;
angular_speed = 0;

manager.on('start', function (event, nipple) {
 timer = setInterval(function () {
   move(linear_speed, angular_speed);
 }, 25);
});

manager.on('move', function (event, nipple) {
 max_linear = 5.0; // m/s
 max_angular = 2.0; // rad/s
 max_distance = 75.0; // pixels;
 linear_speed = Math.sin(nipple.angle.radian) * max_linear * nipple.distance/max_distance;
         angular_speed = -Math.cos(nipple.angle.radian) * max_angular * nipple.distance/max_distance;
});

manager.on('end', function () {
 if (timer) {
   clearInterval(timer);
 }
 self.move(0, 0);
});
}
var z_quar = 0;
var w_quar = 0;
var est_angular = 0;
window.onload = function () {
createJoystick();
var single_goal_state = true;
var index = 0;
var zoomLevel = 50;
var x_coordinate = 0;
var y_coordinate = 0;
var positionVec3 = new ROSLIB.Vector3(null);
var orientation = new ROSLIB.Quaternion({x:0, y:0, z:0, w:1.0});
var goal_array = [];
var goal_markers = [];
var goal_for_send = [];
var cancel_state = false;
var enable_angular = false;
var first_point_x = 0;
var first_point_y = 0;
var second_point_x = 0;
var second_point_y =0;
var goals_array = [];
var display_trace = true;
var display_path = true;


// Create the main viewer for AGV robot
var viewer = new ROS2D.Viewer({
divID : 'map',
width :600,
height :600,
background: '#DCDCDC'
});
var gridClient = new ROS2D.OccupancyGridClient({
  ros : ros,
  rootObject : viewer.scene
  });
  // Scale the canvas to fit to the map
  gridClient.on('change', function(){
    viewer.scaleToDimensions(gridClient.currentGrid.width, gridClient.currentGrid.height);
    
  });
//------------------------------------
var robot_direction = new ROS2D.ArrowShape({
  size : 1,
  strokeSize : 0.05,
  pulse: false,
  fillColor: createjs.Graphics.getRGB(255,0, 0, 0.65)
  });
//show pLANE PATH of AGV
var pathShape = new ROS2D.PathShape({
    strokeSize : 0.3,
    strokeColor : createjs.Graphics.getRGB(0, 255, 0,0.5),
  });
//create arrow of robot in map
var robotMarker = new ROS2D.NavigationArrow({
  size : 0.5,
  strokeSize : 0.05,
  pulse: true,
  fillColor: createjs.Graphics.getRGB(255,0, 0, 0.65)
});

//goal for robot
var robotGoal = new ROS2D.NavigationArrow({
size : 0.5,
strokeSize : 0.05,
pulse: false,
fillColor: createjs.Graphics.getRGB(255,255, 0, 0.65)
});
var traceShape = new ROS2D.TraceShape({
  strokeSize : 0.1,
  strokeColor : createjs.Graphics.getRGB(255, 0, 0,1),
  maxPoses  : 250
  });
var path_listener = new ROSLIB.Topic ({
    ros : ros,
    name : '/move_base_node/SBPLLatticePlanner/plan',
    messageType : 'nav_msgs/Path'
}); 
var poseTopic = new ROSLIB.Topic({
       ros: ros,
       name: '/amcl_pose',
       messageType: 'geometry_msgs/PoseWithCovarianceStamped'
   });
var goalTopic = new ROSLIB.Topic({
ros: ros,
name: '/move_base/goal',
messageType: 'move_base_msgs/MoveBaseActionGoal'
});

var actionClient = new ROSLIB.ActionClient({
ros : ros,
serverName : '/move_base',
actionName : 'move_base_msgs/MoveBaseAction'
});  
//zoom and focus on map.
var zoomView = new ROS2D.ZoomView({
rootObject : viewer.scene
});
var myimage = viewer.scene.canvas;//document.getElementById("map");
if (myimage.addEventListener) {
// IE9, Chrome, Safari, Opera
  myimage.addEventListener("mousewheel", MouseWheelHandler, false);
  // Firefox
  myimage.addEventListener("DOMMouseScroll", MouseWheelHandler, false);
}
// IE 6/7/8
else myimage.attachEvent("onmousewheel", MouseWheelHandler);

function MouseWheelHandler(e) {
// cross-browser wheel delta
var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));

if(delta > 0) {
  if(zoomLevel > 0) {
    zoomView.zoom(1.1);
    zoomLevel = zoomLevel - 5;
  }
}
else {
  if(zoomLevel < 300 ) {
    zoomView.zoom(1/1.1);
    zoomLevel = zoomLevel + 5;
  }
}

e.preventDefault();
return false;
}

function getMousePos(canvas, evt) {
var rect = canvas.getBoundingClientRect();
return {
  x: evt.clientX - rect.left,
  y: evt.clientY - rect.top
};
}

viewer.scene.canvas.addEventListener('mousemove', function(evt) {
    var mousePos = getMousePos(viewer.scene.canvas, evt);

    zoomView.startZoom(mousePos.x, mousePos.y);
  }, false);


//------------------------------------

//public goal to ROS 
send_goal = function()
{
  if(single_goal_state === true)
  {
    robotGoal.x = x_coordinate;
    robotGoal.y = -y_coordinate;
    positionVec3.x = x_coordinate;
    positionVec3.y = y_coordinate;          
  }
  else
  {
    var object_goal = {x_pos: x_coordinate,y_pos: y_coordinate,z_ros: z_quar, w_ros: w_quar,show_angular: est_angular};
    goal_array.push(object_goal);
    for(var i = 0;i  < goal_array.length; i++)
    {
      var goal_marker = new ROS2D.NavigationArrow({
        size: 0.25,
        strokeSize: 0.05,
        pulse: false,
        fillColor: createjs.Graphics.getRGB(70, 50, 255, 0.65)

      })
      goal_marker.x = goal_array[i].x_pos;
      goal_marker.y = -goal_array[i].y_pos;
      goal_marker.rotation = goal_array[i].show_angular;
      console.log("value", goal_array[i].z_ros)
      goal_markers.push(goal_marker);
      var pos_vector = new ROSLIB.Vector3({x:goal_array[i].x_pos,y: goal_array[i].y_pos,z:0});
      var orien_vector = new ROSLIB.Quaternion({x:0, y:0, z:goal_array[i].z_ros, w:goal_array[i].w_ros});
      var new_pose = new ROSLIB.Pose({
        position : pos_vector,
        orientation : orien_vector
        });
      goal_for_send.push(new_pose);
    }
    for(var t = 0;t<goal_markers.length;t++)
    {
    console.log("dat x:",goal_markers[t].x,goal_markers[t].y)
    gridClient.rootObject.addChild(goal_markers[t]);
    }
  }
}

//----------------------------------------------

//Cancel all mission

cancel_goal = function()
{
  actionClient.cancel();
  cancel_state = true;
}

var createFunc = function (handlerToCall, discriminator, robotMarker,robot_direction) {
 return discriminator.subscribe(function(pose){
    traceShape.addPose(pose.pose.pose);
     robotMarker.x = pose.pose.pose.position.x;
     robotMarker.y = -pose.pose.pose.position.y;
     var quaZ = pose.pose.pose.orientation.z;
     var quaX = pose.pose.pose.orientation.x;
     var quaY = pose.pose.pose.orientation.y;
     var quaW = pose.pose.pose.orientation.w;        
     var degreeZ = - Math.atan2(2*(quaW*quaZ + quaX*quaY), 1 - 2 * (quaY*quaY +quaZ*quaZ)) * 180/Math.PI;
     console.log("Robot degree", degreeZ)
     robotMarker.rotation = degreeZ;

     $("#X_val").text(robotMarker.x);
     $("#Y_val").text(robotMarker.y);
     $("#Angular_val").text(degreeZ);
     cmd_vel_listener.subscribe(function(mess){
       $("#val-1").text(mess.linear.x.toFixed(3));
       $("#val-2").text(mess.angular.z.toFixed(3));

     });
 })
}

path_listener.subscribe(function(message) {
  console.log(message);
  pathShape.setPath(message);
  //listener.unsubscribe();
});
//-------------------------------------------------
//setup display

enable_trace = function(){
  if(display_trace === true)
  {
    display_trace = false;
    gridClient.rootObject.addChild(traceShape);
    $("#trace_setting").text("Off trace");
  }
  else
  {
    display_trace = true;
    gridClient.rootObject.removeChild(traceShape);
    $("#trace_setting").text("On trace");
 
  }
  console.log('display trace', display_trace);
}
enable_path = function(){
  if(display_path ===true)
  {
    display_path  = false;
    gridClient.rootObject.addChild(pathShape);
    $("#path_setting").text("Off path");
    console.log("angular:",z_quar,w_quar);
  }
  else
  {
    display_path = true;
    gridClient.rootObject.removeChild(pathShape);
    $("#path_setting").text("On path");
  
  }
  console.log('display path',9);
  console.log('display path',2);

}

//------------------------------------

//Add all things into AGV map
createFunc('subscribe', poseTopic, robotMarker,robot_direction);
//gridClient.rootObject.addChild(robot_direction);

gridClient.rootObject.addChild(robotMarker);
//gridClient.rootObject.addChild(robotGoal);
if(single_goal_state === true)
{
  gridClient.rootObject.addChild(robotGoal);

}
else
{
  for(var t = 0;t<goal_markers.length;t++)
  {
    console.log("dat x:",goal_markers[t].x,goal_markers[t].y)
    gridClient.rootObject.addChild(goal_markers[t]);
  }

}

//-------------------------------------------
viewer.scene.addEventListener('stagemousedown', function(event) {
  
  if (selectedPointIndex !== null) {
      selectedPointIndex = null;
  }
  else if (viewer.scene.mouseInBounds === true) {
      var pos = viewer.scene.globalToRos(event.stageX, event.stageY);	
  x_coordinate = pos.x;
  y_coordinate = pos.y;
  robot_direction.x = pos.x;
  robot_direction.y = -pos.y;
  first_point_x = 0;
  first_point_y = 0;
  first_point_x = event.stageX;
  first_point_y = event.stageY;
  gridClient.rootObject.addChild(robot_direction);
  enable_angular = true;
 
  

//Show_flag(event.stageX,event.stageY);
//console.log(pos.x,pos.y)
//send_goal(pos.x,pos.y)
  }

});

viewer.scene.addEventListener('stagemousemove',event =>{
  if(enable_angular === true)
  {
  second_point_x = event.stageX;
  second_point_y = event.stageY;
  //console.log("show second point: ", second_point_x,second_point_y);
  //var est_distance = Math.sqrt(Math.pow((second_point_x - first_point_x),2) + Math.pow((second_point_y - first_point_y),2));
  var horizon_dis = second_point_x - first_point_x;
  var vertical_dis = second_point_y - first_point_y;
  var bien = vertical_dis/horizon_dis;


  if(Math.abs(horizon_dis) > 0 || Math.abs(vertical_dis) > 0)
  { 
    est_angular = Math.atan(bien)*180/Math.PI;
    if (horizon_dis < 0 && vertical_dis < 0)
    {
      est_angular = -180 + est_angular;
    }
    else if(horizon_dis < 0 && vertical_dis > 0)
    {
      est_angular = -180 + est_angular;

    }   
    robot_direction.rotation = est_angular;
    robotGoal.rotation = est_angular;
    var radian_convert = est_angular*Math.PI/180;
    w_quar = Math.cos(radian_convert/2);
    z_quar = Math.sin(radian_convert/2);
  
    orientation.w = w_quar;
    orientation.z = -z_quar;
    
  

    //console.log("Show new robot angular:", w_quar,z_quar);
  }
  }
});

viewer.scene.addEventListener('stagemouseup', event => {
  enable_angular = false;
  console.log("done");
  gridClient.rootObject.removeChild(robot_direction);
  
});
//receive state of number goal

set_number_goals= function()
{
  if(single_goal_state === true)
  {
    single_goal_state = false;
    console.log("set multiple goal");
    $("#num_goal").text("Single");
    
  }
  else
  {
    single_goal_state = true;
    console.log("set single goals");
    $("#num_goal").text("Multiple");
  }
  
}

start_run = function()
{
  if(single_goal_state === true)
  {
  console.log("Send goal")
  var pose = new ROSLIB.Pose({
  position : positionVec3,
  orientation : orientation
  });
  var goal = new ROSLIB.Goal({
  actionClient : actionClient,
  goalMessage : {
    target_pose : {
      header : {
        frame_id : 'map'
      },
      pose : pose
    }
  }
  });
  goal.on('result',function ()
  {
    if(cancel_state === false)
    {
      alert("Complete mission");

    }
    else
    {
      alert("Cancel misson");
      cancel_state = false;
    }


  });

  goal.send();

}
else
{
  var goal = new ROSLIB.Goal({
    actionClient : actionClient,
    goalMessage : {
      target_pose : {
        header : {
          frame_id : 'map'
        },
        pose : goal_for_send[index]
      }
    }
    });
    goal.on('result',function ()
    {
      if(cancel_state === false)
      {
        alert("Complete a node");
        index = index +1;
        if(index <= goal_for_send.length)
        {
          console.log("dome");
        }
        else
        {
          alert("Complete all misson");
        }
      }
      else
      {
        alert("Cancel misson");
        cancel_state = false;
      }
    });
    goal.send();
}
}
//------------------------------------
}






