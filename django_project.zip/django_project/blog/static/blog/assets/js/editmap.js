
  var enable_add = false;
  var add_list = [];
  var remove_list = [];
  var enable_line = false;
  var all_points = [];
  var all_circle = [];
  var selected_shape = 0;
  var transmit_points = [];
  var func_shape = [];
  var enable_delete = false;
  var center_point_x = 0;
  var center_point_y = 0;
  var zoomLevel = 20;
  var circle_radius = 0;
  var rect_width = 0;
  var rect_length = 0;
  var elip_width = 0;
  var elip_height = 0;
  var rect_setup = document.createElement("div");
  rect_setup.id = "rect-setup"
  rect_setup.innerHTML = 
  `
    <div class = "py-3 mx-auto">
    <h4 style = "margin:auto;"><b>SETUP RECTANGLE SHAPE</b></h4>  
    </div>                               
    <div class = "form-group">
        <label for = "name_section">Name: </label>
        <input type = "text" id = "name_section" class = "float-right" placeholder="Name of area">
    </div>
    <div class = "form-group">
    <label for = "length_section">Length: </label>
    <input type = "text" id ="length_section" class = "float-right" placeholder="Length of area">
    </div>
    <div for = "form-group">
    <label for = "width_section">Width: </label>
    <input type = "text" id = "width_section" class ="float-right" placeholder="Width of area">
    </div>
    <div class = "py-1 mx-auto">
    <p class = "float-center mx-auto"><b>SETUP COLOR</b></p>
    </div>   
    <div class = "form-group">
    <label class = "my-1 mr-2" for="red_section">Red range</label>
    <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="red_section" style = "width: 60%">
    </div>
    <div class = "form-group">
    <label class = "my-1 mr-2" for="green_section">Green range</label>
    <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="green_section" style = "width: 60%">
    </div>
    <div class = "form-group">
    <label class = "my-1 mr-2" for="blue_section">Blue range</label>
    <input type = "range" class="form-range float-right my-1" min = "0" max = "255" step = "1" id="blue_section" style = "width: 60%">
    </div>
    <div class = "form-group">
    <label class = "my-1 mr-2" for="blue_section">Alpha range</label>
    <input type = "range" class="form-range float-right my-1" min = "0" max = "100" step = "1" id = "alpha_section" style = "width: 60%">
    </div>
    
    <div>
        <button class="btn btn-primary" type="button" onclick = "setup()">Setup</button>
        <button class = "btn btn-primary" type = "button" onclick = "Done()">Done</button>
    </div>
  `
  var circle_setup = document.createElement("div");
  circle_setup.id = "circle-setup";
  circle_setup.innerHTML = `
    <div class = "py-3 mx-auto">
        <h4 style = "text-align:center;margin:auto;"><b>SETUP CIRCLE SHAPE</b></h4>  
    </div>                               
    <div class = "form-group">
        <label for = "name_section">Name: </label>
        <input type = "text" id = "name_section" class = "float-right" placeholder="Name of area">
    </div>
    <div class = "form-group">
        <label for = "length_section">Radius: </label>
        <input type = "text" id ="radius_section" class = "float-right" placeholder="Radius of area">
    </div>
    <div class = "py-1 mx-auto">
        <p class = "mx-auto" style="text-align:center"><b>SETUP COLOR</b></p>
    </div>   
    <div class = "form-group">
        <label class = "my-1 mr-2" for="red_section">Red range</label>
        <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="red_section" style = "width: 60%">
    </div>
    <div class = "form-group">
        <label class = "my-1 mr-2" for="green_section">Green range</label>
        <input type = "range" class = "form-range float-right my-1" min = "0" max = "255" step = "1" id="green_section" style = "width: 60%">
    </div>
    <div class = "form-group">
        <label class = "my-1 mr-2" for="blue_section">Blue range</label>
        <input type = "range" class="form-range float-right my-1" min = "0" max = "255" step = "1" id="blue_section" style = "width: 60%">
    </div>
    <div class = "form-group">
        <label class = "my-1 mr-2" for="blue_section">Alpha range</label>
        <input type = "range" class="form-range float-right my-1" min = "0" max = "100" step = "1" id = "alpha_section" style = "width: 60%">
    </div>
    <div class>
        <button class="btn btn-primary" type="button" onclick = "setup()">Setup</button>
        <button class = "btn btn-primary" type = "button" onclick = "Done()">Done</button>
    </div>
  `
    /**
     * Setup all visualization elements when the page is loaded.
     */
    window.onload = function(){
      var ros = new ROSLIB.Ros({
        url : 'ws://localhost:9090'
      });
  
      // Create the main viewer.
      var viewer = new ROS2D.Viewer({
        divID : 'map',
        width : 900,
        height : 900,
      });
 
      
      // Setup the map client.
      var gridClient = new ROS2D.OccupancyGridClient({
        ros : ros,
        rootObject : viewer.scene
      });
      // Scale the canvas to fit to the map
      gridClient.on('change', function(){
        viewer.scaleToDimensions(gridClient.currentGrid.width, gridClient.currentGrid.height);
      });
      var circle_shape = new ROS2D.Circle_area({
              strokeSize: 0.05,
              rootObject: gridClient.rootObject,
              strokeColor: createjs.Graphics.getRGB(255, 0, 255,1),
              fillColor: createjs.Graphics.getRGB(0, 255, 0,0.5)

            });
      var zoomView = new ROS2D.ZoomView({
      rootObject : viewer.scene
      });
      var myimage = viewer.scene.canvas;//document.getElementById("map");
      if (myimage.addEventListener) {
      // IE9, Chrome, Safari, Opera
        myimage.addEventListener("mousewheel", MouseWheelHandler, false);
        // Firefox
        myimage.addEventListener("DOMMouseScroll", MouseWheelHandler, false);

      }
      // IE 6/7/8
      else myimage.attachEvent("onmousewheel", MouseWheelHandler);

      function MouseWheelHandler(e) {
      // cross-browser wheel delta
      var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));

      if(delta > 0) {
        if(zoomLevel > 0) {
          zoomView.zoom(1.1);
          zoomLevel = zoomLevel - 5;
        }
      }
      else {
        if(zoomLevel < 300 ) {
          zoomView.zoom(1/1.1);
          zoomLevel = zoomLevel + 5;
        }
      }

      e.preventDefault();
      return false;
      }

      function getMousePos(canvas, evt) {
      var rect = canvas.getBoundingClientRect();
      return {
        x: evt.clientX - rect.left,
        y: evt.clientY - rect.top
      };
      }

      viewer.scene.canvas.addEventListener('mousemove', function(evt) {
          var mousePos = getMousePos(viewer.scene.canvas, evt);

          zoomView.startZoom(mousePos.x, mousePos.y);
        }, false);

      
      if(enable_add === true)
      {
        conole.log("data");
      }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
      var clickedPolygon = false;
      var selectedPointIndex = null;
  
      var pointCallBack = function(type, event, index) {
        if (type === 'mousedown') {
          if (event.nativeEvent.shiftKey === true) {
            polygon.remPoint(index);
          }
          else {
            selectedPointIndex = index;
          }
        }
        clickedPolygon = true;
      };
  
      var lineCallBack = function(type, event, index) {
        if (type === 'mousedown') {
          if (event.nativeEvent.ctrlKey === true) {
            polygon.splitLine(index);
          }
        }
        clickedPolygon = true;
      }
  
      // Create the polygon
      var polygon = new ROS2D.PolygonMarker({
        rootObject: gridClient.rootObject,
        lineColor : createjs.Graphics.getRGB(100, 100, 255, 1),
        pointCallBack : pointCallBack,
        lineCallBack : lineCallBack,
        pointSize: 0.3,
        lineSize: 0.1,
      });
      
    
      // Add the polygon to the viewer
      viewer.scene.addChild(polygon);
  
      // Event listeners for mouse interaction with the stage
      viewer.scene.mouseMoveOutside = false; // doesn't seem to work
  
      viewer.scene.addEventListener('stagemousemove', function(event) {
        // Move point when it's dragged
        if (selectedPointIndex !== null) {
          var pos = viewer.scene.globalToRos(event.stageX, event.stageY);
          if(selected_shape === 5 || enable_delete === true)
          {
            polygon.movePoint(selectedPointIndex, pos);
          }
        }
      });
      viewer.scene.addEventListener('stagemouseup', function(event) {
        // Add point when not clicked on the polygon
        if (selectedPointIndex !== null) {
          selectedPointIndex = null;
        }
        else if (viewer.scene.mouseInBounds === true && clickedPolygon === false) {
          var pos = viewer.scene.globalToRos(event.stageX, event.stageY);
          if(enable_delete === false)
          {
          if(selected_shape === 1)
          {
            console.log("line");
           
        
          }
          else if(selected_shape === 2)
          {
            console.log("circle");
            circle_radius = parseFloat($("#radius_section").val())
            center_point_x = pos.x;
            center_point_y = pos.y;
            console.log(circle_radius);
            circle_shape.shape.x = center_point_x;
            circle_shape.shape.y = -center_point_y;

          }
          else if(selected_shape === 3)
          {
            console.log("3");
            center_point_x = pos.x;
            center_point_y = pos.y;

            

          }
          else if(selected_shape === 4)
          {
            console.log("4");
            center_point_x = pos.x;
            center_point_y = pos.y;

          }
          else if (selected_shape === 5)
          {
            polygon.addPoint(pos);
            pos.x = 20*pos.x
            pos.y = 400 - 20*pos.y
            var x_point = pos.x.toFixed(0);
            var y_point = pos.y.toFixed(0);
            all_points.push(x_point);
            all_points.push(y_point);
            
          }
        }
        else
        {
            polygon.addPoint(pos);
            pos.x = 20*pos.x
            pos.y = 400 - 20*pos.y
            var x_point = pos.x.toFixed(0);
            var y_point = pos.y.toFixed(0);
            all_points.push(x_point);
            all_points.push(y_point);

        }
          
          
          			
        }
        clickedPolygon = false;
      });
  delete_shape = function()
  {
        if(enable_delete === true)
        {
            func_shape.push(0);
        transmit_points.push(all_points);
        //add_list.push(polygon.pointContainer);
        //for(var j = 0; j<add_list.length;j++)
        //{
          var add_fill = new ROS2D.Remove_mapshape({
            rootObject: gridClient.rootObject,
            points :polygon.pointContainer,
          })

        //}
        all_points = [];
        polygon.pointContainer.removeAllChildren();
        polygon.lineContainer.removeAllChildren();

        }
  }
  //setup shape on top of canvas
  setup = function(){
    if (enable_delete === false)
    {
      if(selected_shape === 1)
      {
        func_shape.push(1);
      }

      else if (selected_shape === 2)
      {
        func_shape.push(2);
      
        var add_circle = new ROS2D.Circle_area({
            strokeSize: 0.05,
            rootObject: gridClient.rootObject,
            strokeColor: createjs.Graphics.getRGB(0, 0,0,1),
            fillColor: createjs.Graphics.getRGB(0, 0, 0),
            radius : circle_radius

        })
        add_circle.shape.x = center_point_x;
        add_circle.shape.y = -center_point_y;
        var center_x = center_point_x*20;
        var center_y = 400 - center_point_y*20;
        var radius = parseInt(circle_radius/0.05);
        all_circle.push(center_x,center_y,radius);
        transmit_point.push(all_circle);
        all_circle = [];
      }
      else if (selected_shape === 3)
      {
        func_shape.push(3);
      }
      else if (selected_shape === 4)
      {
        func_shape.push(4);
      }
      else if (selected_shape === 5)
      {
        func_shape.push(5);
        transmit_points.push(all_points);
        //add_list.push(polygon.pointContainer);
        //for(var j = 0; j<add_list.length;j++)
        //{
          var add_fill = new ROS2D.Add_mapshape({
            rootObject: gridClient.rootObject,
            points :polygon.pointContainer,
          })
        //}
        all_points = [];
        polygon.pointContainer.removeAllChildren();
        polygon.lineContainer.removeAllChildren();
      }
    }
    else
    {
        
        func_shape.push(0);
        transmit_points.push(all_points);
        //add_list.push(polygon.pointContainer);
        //for(var j = 0; j<add_list.length;j++)
        //{
          var add_fill = new ROS2D.Remove_mapshape({
            rootObject: gridClient.rootObject,
            points :polygon.pointContainer,
          })

        //}
        all_points = [];
        polygon.pointContainer.removeAllChildren();
        polygon.lineContainer.removeAllChildren();
    } 


  }
  //select shape and setup panel to draw on map
  select_shape = function()
  {
    selected_shape = document.querySelector('#choose_shape').selectedIndex;
    console.log(selected_shape);
    enable_delete = false;
    if(selected_shape === 1)
    {
        
    }
    else if(selected_shape === 2)
    {
        
        $("#form-setting").append(circle_setup);
        
    }
    else if(selected_shape === 3)
    {
        
        $("#form-setting").append(rect_setup);
    }
    else if(selected_shape === 4)
    {

    }
    else if(selected_shape === 5)
    {

    }

  }
//send all data to server and process data
  send_all = function()
  {
    
    var transmit_data = {map_point: transmit_points,func: func_shape};
    console.log(transmit_data);
    $.ajax({
      url: "{% url 'blog-editmap' %}",
      method : "post",
      type: "POST",
      dataType : "json",
      data : transmit_data,
  
    })
 
  
  }
  //enable delete shape on map
  start_delete = function()
  {
    enable_delete = true;
    console.log("start_del")
  }
 //complete set
 Done = function()
 {
    if(selected_shape === 1)
    {
        
    }
    else if(selected_shape === 2)
    {
        $("#circle-setup").remove();
        
    }
    else if(selected_shape === 3)
    {
        $("#rect-setup").remove();
        
    }
    else if(selected_shape === 4)
    {

    }
    else if(selected_shape === 5)
    {

    }
     
 }
  
    
  }
    
