var socket = io("http://localhost:4000");
            socket.on("connect", () => {
                // either with send()
                socket.send("Hello!");
                // or with emit() and custom event names
                socket.emit("salutations", "Hello!", { "mr": "john" }, Uint8Array.from([1, 2, 3, 4]));
            });
            // handle the event sent with socket.send()
            socket.on("message", data => {
                // console.log(data);
            });

            // handle the event sent with socket.emit()
            socket.on("greetings", (elem1, elem2, elem3) => {
                console.log(elem1, elem2, elem3);
            });
            socket.on("x_data", (data) => {
                x_rec = parseInt(JSON.parse(data)[0]);
                console.log(x_rec);  
            })


var po = new AGV_Display(3, 3, scale_width, image.scene, 0.02, "9");
po.Draw_AGV(330, 330);
var Tim_data = ["1_0", "1_0", "1_0", "1_0"];
po.ChangeAGV_TIM_Status(Tim_data);
var pos = 40
var AGV2 = new AGV_Display(4, 4, scale_width, image.scene, 0.02, "8");
AGV2.Draw_AGV(130, 230);
AGV2.ChangeAGV_TIM_Status(Tim_data);
var draw_Port = new TOOL2D.Draw_all_Ports({
    width:100,
    height: 200,
    Scalesize: scale_width,
    scaleText: 0.1,
    strokeSize: 0.1,
    rootObject: image.scene,
})
draw_Port.Draw(ports_data)
var pos2 = 50;

setInterval(function () {
    var Tim_data = []
    if (pos >= 360) {
        pos -= 5;
        var Tim_data = ["0_0", "0_0", "1_1", "1_3"];
        po.ChangeAGV_TIM_Status(Tim_data);
        po.UpdateAGVstatus(6);
    }
    else if (pos < 360) {
        pos += 5;
        var Tim_data = ["0_0", "1_2", "0_0", "1_1"];
        po.ChangeAGV_TIM_Status(Tim_data);
        po.UpdateAGVstatus(0);
    }
    po.UpdatePositionAGV(pos, 220);
}, 200);
socket.on("Coor_Signal", (data) => {
    x_rec = parseInt(JSON.parse(data)[0]);
    y_rec = parseInt(JSON.parse(data)[1]);
    AGV2.UpdatePositionAGV(x_rec, y_rec);
    if(x_rec <= 40)
    {
        var Tim_data = ["1_0", "1_0", "1_3", "1_0"];
        AGV2.ChangeAGV_TIM_Status(Tim_data);
    }
    if(y_rec >= 360)
    {
        var Tim_data = ["1_0", "1_3", "1_3", "1_0"];
        AGV2.ChangeAGV_TIM_Status(Tim_data);
    }
})