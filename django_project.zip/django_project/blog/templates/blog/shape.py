import cv2
dir = "/home/thang/catkin_ws/src/navigation/map_server/maps/testmap.png"
anh = cv2.imread(dir,1)
print(anh.shape)