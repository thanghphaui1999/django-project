class calculation():
    def __init__(self,a,b):
        self.a = a
        self.b = b
    def sum(self):
        return self.a * self.b
    def multiple(self):
        return self.a * self.b



