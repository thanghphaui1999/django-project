import yaml
import cv2

class create_image():
    def create_preview_image(image,max_width = 150):
        height = image.shape[0]
        width = image.shape[1]
        new_height = height
        new_width = width
        if width < max_width:
            new_width = width
        else:
            new_width = max_width
        resize_ratio = new_width/width
        new_height = int(height*resize_ratio)
        preview_image = cv2.resize(image,(new_width,new_height))
        return preview_image
#process yaml file
class yaml_process():
    def __init__(self,dir):
        self.dir = dir
    def read_yaml(self):
        with open(self.dir, "r") as yamlfile:
            data = yaml.load(yamlfile, Loader=yaml.FullLoader)
            yamlfile.close()
        return data
    def write_yaml(self,write_data):
        with open(self.dir, 'w') as yamlfile:
            data1 = yaml.dump(write_data, yamlfile,sort_keys = False)
            yamlfile.close()
        
    def rewrite_yaml(self,data_dic):
        data = self.read_yaml(self.dir)
        for x,y in data.items():
            for i,j in data_dic.items():
                if x == i:
                    data[x] = j
        self.write_yaml(self.dir,data)
    


    
    
        
