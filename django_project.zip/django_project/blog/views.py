from distutils.log import error
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from django.http import HttpResponse, response
from django.http import JsonResponse
from django.core import serializers
from .savemap import save_last_image
from django.shortcuts import redirect
from .models import Post
from django.contrib.auth.decorators import login_required
from .models import Map_area, Map_save_name_complete, Link_map_LG, Node_map_LG, Manual_Command, tranlist
from .models import SOC_charge, Tranfer, Parking, Port, Manual_Tranfer, AGV_status, LockZone, AGV_info
from django.http import HttpResponseRedirect
import json
from json import dumps
import cv2
import pandas
import random
import numpy as np
import roslaunch
import signal
import threading
import yaml
import time
from .export_tools import create_image, yaml_process
import os
from .draw_map_func import draw_tool
import subprocess
import logging
import math
run_first_time = True
vehicleSpeed = 800  # speed of vehicle(mm/s)
logger = logging.getLogger(__name__)
uuid = roslaunch.rlutil.get_or_generate_uuid(None, False)
roslaunch.configure_logging(uuid)
cli_args1 = ['mir_navigation', 'start_planner.launch', 'map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml',
             'virtual_walls_map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze_virtual_walls.yaml']
roslaunch_file1 = roslaunch.rlutil.resolve_launch_arguments(cli_args1)[0]
roslaunch_args1 = cli_args1[2:]
launch_files = [(roslaunch_file1, roslaunch_args1)]
parent = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
state = True
save_map_dir = "/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps"
enable_map = True
dirname = os.path.dirname(__file__)
filename = os.path.join(dirname, 'config.json')
height_image = 0
width_image = 0
mapScale = 0
IP_domain =''
socketPort = 0
try:
    with open(filename, 'r') as f:
        data =json.load(f)
        height_image = int(data["height_image"])
        width_image = int(data["width_image"])
        IP_domain = data["IP_domain"]
        socketPort = int(data["socketPort"])
        mapScale = float(data["map_ratio"])
except Exception as e:
    print("Cannot find config file")


class database_map_modify():
    def __init__(self):
        pass

    def add_map(self, name, map_height, map_width, username, path):
        savemap = Map_save_name_complete(name=name, map_height=map_height, map_width=map_width, resolution=0.05,
                                         occupied_thresh=0.65, free_thresh=0.196, negate=0, username=username, path=path)
        savemap.save()

    def remove_map(self, map_name):
        Map_save_name_complete.objects.filter(name=map_name).delete()

    def rename_map(self, old_name, new_name):
        Map_save_name_complete.objects.filter(
            name=old_name).update(name=new_name)


def run_launch():
    global state
    if state == True:
        parent.start()
    else:
        parent.shudown()
        state = True


# open_launch = threading.Thread(name = "run_launch", target = parent.start())
# open_launch.start()
# Create your views here.
posts = [{
    'title': "First blog",
    'content': "This blog is about the robot",
    'date_posted': "21-9-2021",
    'author': 'Thang'},
    {
    'title': "Second",
    'content': "This blog is about the fruits",
    'date_posted': "22-9-2021",
    'author': "Nam"
},
    {
    'title': "Third",
    'content': 'This is blog about the animal',
    'author': "Nhat",
    "date_posted": "20-8-2021"
}
]


def convert_boolean(value):
    if value == "true":
        return True
    else:
        return False


def home(request):
    logger.error("Test!!")
    context = {'posts': Post.objects.all(), 'title': 'AGV',
               'text': 'LinuxHint'}
    return render(request, 'blog/home.html', context)


def about(request):
    context = {'title': 'About '}
    return render(request, 'blog/about.html', context)


def Main_dashboard(request):
    context = {'title': 'Dashboard for  AGV'}
    return render(request, 'blog/main_dashboard.html', context)


def index(request):
    return render(request, 'blog/index.html', context={'text': 'LinuxHint'})


def map(request):
    context = {'title': 'map'}
    return render(request, 'blog/map_display.html', context)


def view3d(request):
    return render(request, 'blog/show_3d_view.html')


def test(request):
    return render(request, 'blog/test.html')


def control_AGV(request):
    show_area = Map_area.objects.all()
    post_list = serializers.serialize('json', list(
        show_area), fields=('name', 'posX', 'posY', 'quaZ', 'quaW'))
    context = {'data': post_list}
    return render(request, 'blog/complete_map.html', context)


@csrf_exempt
def mapping(request):
    if request.method == "POST":
        global enable_map
        cmd = ["roslaunch", "mir_navigation", "hector_mapping.launch"]
        proc = subprocess.Popen(cmd)
        func = request.POST.get("func")
        if func == "save_map":
            time.sleep(10)
            proc.terminate()
            # proc.send_signal(signal.SIGINT)
            # os.killpg(os.getpgid(proc.pid), signal.SIGTERM)

    return render(request, 'blog/mapping.html')


@csrf_exempt
def test_frame(request):
    if request.method == "POST":
        data_length = len(request.POST.getlist('case[]', []))
        list_func = request.POST.getlist('case[]', [])
        list_point = request.POST.getlist('map_point[]', [])
        for i in range(2):
            data = request.POST.getlist(f'map_point[{i}][]')
            for j in range(len(data)):
                print(data[j])

    return render(request, 'blog/test_frame_data.html')
@csrf_exempt
def edit_map(request):
    map_database = Map_save_name_complete.objects.all()
    m_data = database_map_modify()
    post_list = serializers.serialize('json', list(map_database), fields=(
        'name', 'path', 'map_height', 'map_width', 'resolution', 'create_date', 'username', 'free_thresh', 'occupied_thresh', 'negate'))
    current_map = 'maze.png'
    map_yaml = yaml_process(
        '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml')
    data = map_yaml.read_yaml()
    current_map = data['image']
    only_map_name = current_map.split('.')[0]
    context = {'data_map': post_list, "current_map": only_map_name}
    if request.method == 'POST':
        func = request.POST.getlist('func[]', [])
        # save new area data to server
        if func[0] == "load_map":
            map_name = request.POST.get('map_name')
            data['image'] = map_name + ".png"
            map_yaml.write_yaml(data)
            image = cv2.imread(
                '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + map_name + ".png")
            parent.shutdown()
            parent_new = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
            open_launch = threading.Thread(
                name="run_launch", target=parent_new.start())
        elif func[0] == "save_area":
            posX = []
            posY = []
            quaZ = []
            quaW = []
            name = []
            length = request.POST.get('dataSize')
            length = int(length)
            area_info = request.POST.getlist(f'AGV_info[]')
            for i in range(length):
                data = request.POST.getlist(f'AGV_info[{i}][]')
                posX.append(data[0])
                posY.append(data[1])
                quaZ.append(data[2])
                quaW.append(data[3])
                name.append(data[4])
                post_map_area = Map_area(name=data[4], posX=float(data[0]), posY=float(
                    data[1]), quaZ=float(data[2]), quaW=float(data[3]))
                post_map_area.save()
            list_data = {"posX": posX, "posY": posY,
                         "quaZ": quaZ, "quaW": quaW, "name": name}
            with open("/home/thang/catkin_ws/src/django_project/save_area.json", "w") as fout:
                json.dump(list_data, fout)
        elif func[0] == "remove_map":
            map_name = request.POST.get('map_name')
            m_data.remove_map(map_name)
        elif func[0] == "rename_map":
            old_name = request.POST.get('map_name')
            new_name = request.POST.get('add_data')
            m_data.rename_map(old_name, new_name)
        else:
            print(func[0])
            global state
            name_map = request.POST.get("map_name")
            if name_map == '':
                name_map = 'maze.png'
            print("name of map", name_map)
            image = cv2.imread(
                '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + current_map)
            draw_on_map = draw_tool(image)
            for i in range(len(func)):
                data = request.POST.getlist(f'map_point[{i}][]')
                current_func = func[i]
                print(current_func)
                if current_func == "1":
                    draw_on_map.draw_line(data)
                elif current_func == "2":
                    draw_on_map.draw_circle(data)
                elif current_func == "3":
                    draw_on_map.draw_rectangle(data)
                elif current_func == "4":
                    draw_on_map.draw_elipse(data)
                elif current_func == "5":
                    draw_on_map.draw_polygon(data)
                elif current_func == "0":
                    draw_on_map.delete_area(data)
            cv2.imwrite(
                "/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/" + name_map + ".png", image)
            preview_map = create_image.create_preview_image(image, 200)
            cv2.imwrite("/home/thang/catkin_ws/src/django_project/blog/static/blog/assets/img/maps/preview_map/" +
                        name_map + ".png", preview_map)
            path_map = "/static/blog/assets/img/maps/preview_map/" + name_map + ".png"
            m_data.add_map(
                name_map, image.shape[0], image.shape[1], 'Thang', path_map)
            parent.shutdown()
            data = map_yaml.read_yaml()
            data['image'] = name_map + ".png"
            map_yaml.write_yaml(data)
            parent_new = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
            open_launch = threading.Thread(
                name="run_launch", target=parent_new.start())
    return render(request, 'blog/edit_map.html', context)
@csrf_exempt
def edittool(request):
    map_database = Map_save_name_complete.objects.all()
    area_database = Map_area.objects.all()
    area_list = serializers.serialize('json', list(
        area_database), fields=('name', 'posX', 'posY', 'quaZ', 'quaW'))
    m_data = database_map_modify()
    post_list = serializers.serialize('json', list(map_database), fields=(
        'name', 'path', 'map_height', 'map_width', 'resolution', 'create_date', 'username'))
    current_map = 'maze.png'
    map_yaml = yaml_process(
        '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml')
    data = map_yaml.read_yaml()
    current_map = data['image']
    only_map_name = current_map.split('.')[0]
    context = {'data_map': post_list,
               "current_map": only_map_name, "data_area": area_list}
    if request.method == 'POST':
        func = request.POST.getlist('func[]', [])
        # save new area data to server
        if func[0] == "load_map":
            map_name = request.POST.get('map_name')
            data['image'] = map_name + ".png"
            map_yaml.write_yaml(data)
            image = cv2.imread(
                '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + map_name + ".png")
            parent.shutdown()
            parent_new = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
            open_launch = threading.Thread(
                name="run_launch", target=parent_new.start())
        elif func[0] == "save_area":
            posX = []
            posY = []
            quaZ = []
            quaW = []
            name = []
            length = request.POST.get('dataSize')
            length = int(length)
            area_info = request.POST.getlist(f'AGV_info[]')
            for i in range(length):
                data = request.POST.getlist(f'AGV_info[{i}][]')
                posX.append(data[0])
                posY.append(data[1])
                quaZ.append(data[2])
                quaW.append(data[3])
                name.append(data[4])
                post_map_area = Map_area(name=data[4], posX=float(data[0]), posY=float(
                    data[1]), quaZ=float(data[2]), quaW=float(data[3]))
                post_map_area.save()
            list_data = {"posX": posX, "posY": posY,
                         "quaZ": quaZ, "quaW": quaW, "name": name}
            with open("/home/thang/catkin_ws/src/django_project/save_area.json", "w") as fout:
                json.dump(list_data, fout)
        elif func[0] == "remove_map":
            map_name = request.POST.get('map_name')
            m_data.remove_map(map_name)
        elif func[0] == "rename_map":
            old_name = request.POST.get('map_name')
            new_name = request.POST.get('add_data')
            m_data.rename_map(old_name, new_name)
        else:
            print(func[0])
            global state
            name_map = request.POST.get("map_name")
            if name_map == '':
                name_map = 'maze.png'
            print("name of map", name_map)
            image = cv2.imread(
                '/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + current_map)
            draw_on_map = draw_tool(image)
            for i in range(len(func)):
                data = request.POST.getlist(f'map_point[{i}][]')
                current_func = func[i]
                print(current_func)
                if current_func == "1":
                    draw_on_map.draw_line(data)
                elif current_func == "2":
                    draw_on_map.draw_circle(data)
                elif current_func == "3":
                    draw_on_map.draw_rectangle(data)
                elif current_func == "4":
                    draw_on_map.draw_elipse(data)
                elif current_func == "5":
                    draw_on_map.draw_polygon(data)
                elif current_func == "0":
                    draw_on_map.delete_area(data)
            cv2.imwrite(
                "/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/" + name_map + ".png", image)
            preview_map = create_image.create_preview_image(image, 200)
            cv2.imwrite("/home/thang/catkin_ws/src/django_project/blog/static/blog/assets/img/maps/preview_map/" +
                        name_map + ".png", preview_map)
            path_map = "/static/blog/assets/img/maps/preview_map/" + name_map + ".png"
            m_data.add_map(
                name_map, image.shape[0], image.shape[1], 'Thang', path_map)
            parent.shutdown()
            data = map_yaml.read_yaml()
            data['image'] = name_map + ".png"
            map_yaml.write_yaml(data)
            parent_new = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
            open_launch = threading.Thread(
                name="run_launch", target=parent_new.start())
    return render(request, 'blog/edit_AGV_map.html', context)


def moving_AGV(request):
    show_area = Map_area.objects.all()
    post_list = serializers.serialize('json', list(
        show_area), fields=('name', 'posX', 'posY', 'quaZ', 'quaW'))
    context = {'data': post_list}
    return render(request, 'blog/moving_AGV.html', context)


@csrf_exempt
def mapping_page(request):
    if request.method == "POST":
        global enable_map
        global run_first_time
        if run_first_time == True:
            cmd_mapping = ["roslaunch", "mir_navigation",
                           "hector_mapping.launch"]
            cmd_update_map = ["roslaunch", "mir_navigation", "save_map.launch"]
            global proc_updtae_map
            global proc
            proc = subprocess.Popen(cmd_mapping)
            proc_updtae_map = subprocess.Popen(cmd_update_map)
            run_first_time = False

        func = request.POST.get("func")
        if func == "save_map":
            save_func = save_last_image()
            save_func.savemap()
            time.sleep(10)
            proc_updtae_map.terminate()
            proc.terminate()
    return render(request, 'blog/mapping_page.html')
Qtable = -20*np.ones((420,6))
startNode = 77
sourceNode = 76
destNode = 79
learning_rate = 0.2
discountFactor = 0.9
numLoop = 1000
epsilon = 0.7
trip_len = 50
start = [sourceNode, destNode, startNode]
goal = [destNode, destNode, destNode]
dictData = {"state": [], "reward": [], "nextState": [], "action": [], "distance":[]}
@csrf_exempt
def LG_map(request):
    nodes_data = Node_map_LG.objects.all()
    links_data = Link_map_LG.objects.all()
    Port_database = Port.objects.all()
    LockZone_database = LockZone.objects.all()
    port_list = serializers.serialize('json', list(Port_database), fields=(
        'PORT_ID', 'PORT_name', 'Height', 'Width', 'CarrierType', 'Monitor_X', 'Monitor_Y', 'Direct'))
    nodes_list = serializers.serialize('json', list(
        nodes_data), fields=('X', 'Y', 'TYPE', 'ID_NODE', 'TURN'))
    links_list = serializers.serialize('json', list(links_data), fields=(
        'ID_LINK', 'START', 'END', 'DIST', 'V', 'IR_F', 'IR_B', "IR_L", "IR_R", "NUM", "TYPE", "TURN", "DIR", "E_DIR", "FB", "V_DIR"))
    lockZone_list = serializers.serialize('json', list(
        LockZone_database), fields=('LockID', "Use", "ListNode"))
    initialData = {'height_image': height_image, 'width_image': width_image, 'map_ratio': mapScale, 'IP_domain': IP_domain, 'socketPort':socketPort}
    context = {'nodes_data': nodes_list, "links_data": links_list,
               'ports_data': port_list, 'lockZone_data': lockZone_list, "initialData": initialData}
    if request.method == "POST":
        func = request.POST.get('func')
        prefix = func.split('_')[0]
        if prefix == "node":
            if func == "node_data":
                ID_nodes = request.POST.get("ID")
                Type_nodes = request.POST.get("Type")
                X_nodes = request.POST.get("X")
                Y_nodes = request.POST.get("Y")
                Turn_nodes = request.POST.get("Turn")
                add_node = Node_map_LG(ID_NODE=int(ID_nodes), X=int(X_nodes), Y=int(Y_nodes),
                                       TYPE=int(Type_nodes), TURN=int(Turn_nodes))
                add_node.save()
                if(int(Type_nodes) == 1):
                    add_Port = Port(PORT_ID=int(ID_nodes), Monitor_X=int(X_nodes),
                                    Monitor_Y=int(Y_nodes), CarrierType="Box",
                                    PORT_name="default", Direct=0, Height=2000, Width=2000, Node=ID_nodes)
                    add_Port.save()
            elif func == "node_modify":
                ID_nodes = request.POST.get("ID")
                Type_nodes = request.POST.get("Type")
                X_nodes = request.POST.get("X")
                Y_nodes = request.POST.get("Y")
                Turn_nodes = request.POST.get("Turn")
                node = Node_map_LG.objects.get(ID_NODE=int(ID_nodes))
                try:
                    linksStart = Link_map_LG.objects.filter(START=ID_nodes)
                    for i in linksStart:

                        e = Node_map_LG.objects.get(ID_NODE=i.END)
                        new_dis = math.sqrt(
                            math.pow((int(X_nodes) - e.X), 2) + math.pow((int(Y_nodes) - e.Y), 2))*1000
                        new_Time = new_dis*mapScale*1000/vehicleSpeed
                        i.DIST = new_dis
                        i.Time = new_Time
                        i.save()
                except:
                    pass
                try:
                    linksEnd = Link_map_LG.objects.filter(END=ID_nodes)
                    for i in linksEnd:
                        s = Node_map_LG.objects.get(ID_NODE=i.START)
                        new_dis = math.sqrt(
                            math.pow((int(X_nodes) - s.X), 2) + math.pow((int(Y_nodes) - s.Y), 2))*1000
                        i.DIST = new_dis
                        new_Time = new_dis*mapScale*1000/vehicleSpeed
                        i.Time = new_Time
                        i.save()
                except:
                    pass
                if node.TYPE == 1 and int(Type_nodes) != 1:
                    port = Port.objects.filter(PORT_ID=int(ID_nodes)).delete()
                elif node.TYPE != 1 and int(Type_nodes) == 1:
                    add_Port = Port(PORT_ID=int(ID_nodes), Monitor_X=int(X_nodes),
                                    Monitor_Y=int(Y_nodes), CarrierType="Box",
                                    PORT_name="default", Direct=0, Height=2000, Width=2000)
                    add_Port.save()
                
                elif node.TYPE == 1 and int(Type_nodes) == 1:
                    port = Port.objects.get(PORT_ID=int(ID_nodes))
                    port.Monitor_Y = Y_nodes
                    port.Monitor_X = X_nodes
                    port.save()
                node.X = int(X_nodes)
                node.Y = int(Y_nodes)
                node.TYPE = int(Type_nodes)
                node.TURN = int(Turn_nodes)
                node.save()
            elif func == "node_remove":
                ID_nodes = request.POST.get("ID")
                Node_map_LG.objects.filter(ID_NODE=int(ID_nodes)).delete()
                try:
                    port = Port.objects.filter(PORT_ID=int(ID_nodes)).delete()
                except:
                    pass
                try:
                    Link_map_LG.objects.filter(START=int(ID_nodes)).delete()
                except:
                    pass
                try:
                    Link_map_LG.objects.filter(END=int(ID_nodes)).delete()
                except:
                    pass
            elif func == "node_multiple_remove":
                ID_nodes = request.POST.getlist("ID[]", [])
                for i in ID_nodes:
                    print("val", i)
                    Node_map_LG.objects.filter(ID_NODE=int(i)).delete()
                    try:
                        port = Port.objects.filter(PORT_ID=int(i)).delete()
                    except:
                        pass
                    try:
                        Link_map_LG.objects.filter(START=int(i)).delete()
                    except:
                        pass
                    try:
                        Link_map_LG.objects.filter(END=int(i)).delete()
                    except:
                        pass

            nodes_data = Node_map_LG.objects.all()
            nodes_list = serializers.serialize('json', list(
                nodes_data), fields=('X', 'Y', 'TYPE', 'ID_NODE', 'TURN'))
            return JsonResponse({'nodes_data': nodes_list})
        elif prefix == "link":
            if func == "link_data":
                ID_links = request.POST.get('ID')
                Start_links = request.POST.get('Start')
                End_links = request.POST.get('End')
                Type_links = request.POST.get('Type')
                Turn_links = request.POST.get('Turn')
                V_links = request.POST.get('V')
                Dir_links = request.POST.get('Dir')
                EDir_links = request.POST.get('E_Dir')
                Dis_links = request.POST.get('Distance')
                Ir_f_links = request.POST.get('Ir_f')
                Ir_b_links = request.POST.get('Ir_b')
                Ir_r_links = request.POST.get('Ir_r')
                Ir_l_links = request.POST.get('Ir_l')
                FB_links = request.POST.get('FB')
                Vdir_links = request.POST.get('V_Dir')
                Time_period = int(Dis_links)*mapScale*1000/800
                add_link = Link_map_LG(ID_LINK=int(ID_links), DIST=int(Dis_links), V=int(V_links),
                                       IR_F=convert_boolean(Ir_f_links), IR_B=convert_boolean(Ir_b_links), IR_L=convert_boolean(Ir_l_links), IR_R=convert_boolean(Ir_r_links),
                                       START=int(Start_links), END=int(End_links), TYPE=int(Type_links), TURN=int(Turn_links), FB=int(FB_links), NUM=10,
                                       DIR=int(Dir_links), E_DIR=int(EDir_links), V_DIR=int(Vdir_links), Time=Time_period)
                add_link.save()
            elif func == "link_modify":
                ID_link = request.POST.get("ID")
                
                Type_links = request.POST.get('Type')
                Turn_links = request.POST.get('Turn')
                V_links = request.POST.get('V')
                Ir_f_links = request.POST.get('Ir_f')
                Ir_b_links = request.POST.get('Ir_b')
                Ir_r_links = request.POST.get('Ir_r')
                Ir_l_links = request.POST.get('Ir_l')
                FB_links = request.POST.get('FB')
                Dir_links = request.POST.get('Dir')
                EDir_links = request.POST.get('E_Dir')
                VDir_links = request.POST.get('V_Dir')
                print("FB_link: {}".format(FB_links))
                link = Link_map_LG.objects.get(ID_LINK=int(ID_link))
                link.TYPE = Type_links
                link.TURN = Turn_links
                link.V = V_links
                link.FB = FB_links
                link.IR_F = convert_boolean(Ir_f_links)
                link.IR_B = convert_boolean(Ir_b_links)
                link.IR_L = convert_boolean(Ir_l_links)
                link.IR_R = convert_boolean(Ir_r_links)
                link.DIR = Dir_links
                link.E_DIR = EDir_links
                link.V_DIR = VDir_links
                print("Vdir value: {}".format(VDir_links))
                print("E_dir value: {}".format(EDir_links))
                link.save()
            elif func == "link_remove":
                try:
                    ID_link = request.POST.get("ID")
                    Link_map_LG.objects.filter(ID_LINK=int(ID_link)).delete()
                except:
                    print("Cannot find link")
            links_data = Link_map_LG.objects.all()
            links_list = serializers.serialize('json', list(links_data), fields=(
                'ID_LINK', 'START', 'END', 'DIST', 'V', 'IR_F', 'IR_B', "IR_L", "IR_R", "NUM", "TYPE", "TURN", "DIR", "E_DIR", "FB", "V_DIR"))
            return JsonResponse({'links_data': links_list})
        elif prefix == "lockZone":
            LockID = request.POST.get("LockID")
            if func == "lockZone_add":
                addNode = request.POST.get("NodeID")
                item = LockZone.objects.get(LockID=LockID)
                jsonDec = json.decoder.JSONDecoder()
                ListNode = jsonDec.decode(item.ListNode)
                if(addNode in ListNode):
                    print("The Node have already exist")
                else:
                    ListNode.append(addNode)
                    item.ListNode = json.dumps(ListNode)
                    item.save()
            elif func == "lockZone_remove":
                removeNode = request.POST.get("NodeID")
                item = LockZone.objects.get(LockID=LockID)
                jsonDec = json.decoder.JSONDecoder()
                ListNode = jsonDec.decode(item.ListNode)
                if(removeNode not in ListNode):
                    print("The Node haven't added to LockZone yet")
                else:
                    ListNode.remove(removeNode)
                    item.ListNode = json.dumps(ListNode)
                    item.save()
            elif func == "lockZone_use":
                state = request.POST.get("state")
                item = LockZone.objects.get(LockID=LockID)
                item.Use = convert_boolean(state)
                item.save()
            lockZone_data = LockZone.objects.all()
            lockZone_list = serializers.serialize('json', list(
                lockZone_data), fields=("LockID", "Use", "ListNode"))
            return JsonResponse({'lockZone_data': lockZone_list})
        elif func == "getPolicy":
            print("Policy",1)
            print(Qtable)
            np.savetxt('np.csv', Qtable, fmt='%.2f', delimiter=',', header=" #1,  #2,  #3,  #4, #5, #6")
            def extractPolicy(initialState):
                policy = []
                state = []
                Index = dictData["state"].index(initialState)
                loop = 0
                while True:
                    loop += 1
                    action = np.nanargmax(Qtable[Index])
                    policy.append(action)
                    nextState = dictData["nextState"][Index][action]
                    Index = dictData["state"].index(nextState)
                    state.append((Index, action, nextState))
                    if nextState == goal or loop == 200:
                        break
                return policy,state
            policy,state = extractPolicy(start)
            print(policy)




        elif func == "reinforce":
            
            allNodes = Node_map_LG.objects.all()
            allLinks = Link_map_LG.objects.all()
            allPorts = Port.objects.all()
            numNode = len(Node_map_LG.objects.all())
            numPort = len(allPorts)
            goodPos = []
            def setReward(completedAcquired, completedDeposit,distance,wrongAction):
                reward = -(distance*0.02)/1000
                if completedAcquired:
                    reward += 40
                if completedDeposit:
                    reward += 70
                if wrongAction:
                    reward -= 20
                return reward
            for i in allPorts:
                PortID = i.PORT_ID
                goodPos.append(PortID)
            goodPos.append("onAGV")
            for i in allNodes:
                for goodLoc in goodPos:
                    for Dest in allPorts:
                        dictData["state"].append([goodLoc, Dest.PORT_ID, i.ID_NODE])
                        dictData["action"].append([])
                        dictData["reward"].append(-10*np.ones((6)))
                        dictData["nextState"].append([None]*6)
                        dictData["distance"].append(90000*np.ones((6)))
            for j,i in enumerate(dictData["state"]):
                for t in allLinks:
                    startNode = t.START
                    linkID = t.ID_LINK
                    endNode = t.END
                    if i[2] == startNode:
                        dictData["action"][j].append(linkID)
            for j,i in enumerate(dictData["state"]):
                for t in range(6):
                    if i[1] == i[2] and t == 5:
                        if i[0] == "onAGV":
                            dictData["nextState"][j][t] = [i[1],i[1],i[1]]
                        else:
                            dictData["nextState"][j][t] = [i[0],i[1],i[1]]
                    elif i[0] == i[2] and t == 4:
                        dictData["nextState"][j][t] = ["onAGV",i[1], None]
                    elif i[2] in goodPos and t == 5:
                        dictData["nextState"][j][t] = [i[2],i[1], None]
                    else:
                        dictData["nextState"][j][t] = [i[0], i[1], None]
            for j,i in enumerate(dictData["state"]): 
                startNode = Node_map_LG.objects.get(ID_NODE = i[2])
                startNodeX = startNode.X
                startNodeY = startNode.Y
                for t in dictData["action"][j]:
                    link = Link_map_LG.objects.get(ID_LINK = t)
                    distance = link.DIST
                    endNodeID = link.END
                    endNode = Node_map_LG.objects.get(ID_NODE = endNodeID)
                    X_endNode = endNode.X
                    Y_endNode = endNode.Y
                    isGoal = False
                    isStart = False
                    if Y_endNode > startNodeY:
                        dictData["nextState"][j][2][2] = int(endNodeID)
                        dictData["nextState"][j][5][2] = int(i[2])
                        dictData["nextState"][j][4][2] =int(i[2])
                        dictData["distance"][j][2] = 50000
                    if Y_endNode < startNodeY:
                        dictData["nextState"][j][3][2] = int(endNodeID)
                        dictData["nextState"][j][5][2] = int(i[2])
                        dictData["nextState"][j][4][2] = int(i[2])
                        dictData["distance"][j][3] = 50000
                        
                    if X_endNode >startNodeX:
                        
                        dictData["nextState"][j][0][2] = int(endNodeID)
                        dictData["nextState"][j][5][2] = int(i[2])
                        dictData["nextState"][j][4][2] = int(i[2])
                        dictData["distance"][j][0] = 50000
                    if X_endNode < startNodeX:
                        dictData["nextState"][j][1][2] = int(endNodeID)
                        dictData["nextState"][j][5][2] = int(i[2])
                        dictData["nextState"][j][4][2] = int(i[2])
                        dictData["distance"][j][1] = 50000
            for j,i in enumerate(dictData["nextState"]):
                for t in range(6):
                    if dictData["nextState"][j][t][2] == None:
                        dictData["nextState"][j][t] = None
                    if t == 4 and dictData["nextState"][j][t][2] not in goodPos:
                        dictData["nextState"][j][t] = None
                    if t == 5 and dictData["nextState"][j][t][2] not in goodPos:
                        dictData["nextState"][j][t] = None
            #completedAcquired, completedDeposit,distance,wrongAction
            for j,i in enumerate(dictData["state"]):
                for t in range(6):
                    completedDeposit = False
                    completedAcquired = False
                    wrongAction = False
                    distance = dictData["distance"][j][t]
                    for de in allPorts:
                        for so in allPorts:
                            destNode = de.PORT_ID
                            sourceNode = so.PORT_ID
                            if dictData["nextState"][j][t] != None:
                                if dictData["nextState"][j][t] == [destNode, destNode, destNode] and dictData["state"][j] == ["onAGV", destNode, destNode]:
                                    completedDeposit = True 
        
                                if dictData["nextState"][j][t] == ["onAGV", destNode, sourceNode] and dictData["state"][j] == [sourceNode, destNode,sourceNode]:
                                    completedAcquired = True
                                if t == 5 and dictData["state"][j][2] != sourceNode:
                                    wrongAction = True
                                if t == 4 and dictData["state"][j][2] != sourceNode:
                                    wrongAction = True
                                if t == 5 and dictData["state"][j][2] != destNode:
                                    wrongAction = True
                                if t == 4 and dictData["state"][j][2] != destNode:
                                    wrongAction = True
                                reward = setReward(completedAcquired,completedDeposit, distance, wrongAction)
                                dictData["reward"][j][t] = reward
                            else:
                                dictData["reward"][j][t] = None
            index = dictData["state"].index([76,79,15])
            print("satte", dictData["state"][index])
            print("cahc")
            print("sds")
            print(dictData["reward"][index])
            print(dictData["nextState"][index])
            #__________________algorithm
            for j,i in enumerate(dictData["state"]):
                for t in range(6):
                    if dictData["nextState"][j][t] == None:
                        Qtable[j][t] = None
    
            def random_policy(start):
                index = dictData["state"].index(start)
                listAC = dictData["nextState"][index]
                K = None
                res = random.choice(list(filter(lambda ele: ele != K, listAC)))
                return listAC.index(res)
            def EnviromentStep(action,State):
                isDone = False
                preStateIndex = dictData["state"].index(State)
                nextState = dictData["nextState"][preStateIndex][action]
                reward = dictData["reward"][preStateIndex][action]
                
                if nextState == goal:
                    isDone = True
                return nextState, reward, isDone
            def Qvalue(state,action):
                index = dictData["state"].index(state)
                return Qtable[index][action]
            def UpdateQvalue(state,action,newQValue):
                index = dictData["state"].index(state)
                Qtable[index][action] = newQValue
            def SARSA_rule(Qsa, Qs_a_, r, learning_rate, disFactor):
                return Qsa + learning_rate*(r + disFactor*Qs_a_ - Qsa)
            def EpsilonGreadyPolicy(state, epsilon):
                index = dictData["state"].index(state)
                listAC = dictData["nextState"][index]
                if np.random.uniform(low=0.0, high=1.0) < epsilon:
                    K = None
                    res = random.choice(list(filter(lambda ele: ele != K, listAC)))
                    return listAC.index(res)
                else:
                    maxAction = np.nanargmax(Qtable[index])
                    return maxAction
            def update_q_table(prev_state, action, reward, nextstate, alpha, gamma):
                
                index = dictData["state"].index(nextstate)
                index_pre = dictData["state"].index(prev_state)
                maxAction = np.nanargmax(Qtable[index])
                    #print(maxAction)
                Qtable[index_pre][action] += alpha * (reward + gamma * Qtable[index][maxAction] - Qtable[index_pre ][action])
                    #print("max", maxAction)
                
                
            print(Qtable.shape)
            loop = 0
            for beginnode in allNodes:
                for first in allPorts:
                    for end in allPorts:
                        startNode = beginnode.ID_NODE
                        sourceNode = first.PORT_ID
                        destNode = end.PORT_ID
                        start = [sourceNode, destNode, startNode]
                        goal = [destNode, destNode, destNode]
                        for i in range(numLoop):
                            state = start
                            #action = random_policy(start)
                            loop +=1
                            print(loop)
                            len_ = 0
                            while True:
                                action = EpsilonGreadyPolicy(state, epsilon)
                                nextstate, reward, isDone = EnviromentStep(action,state)
                                #ewQsa = SARSA_rule(Qvalue(state,action),Qvalue(nextState,nextAction),reward, learning_rate,discountFactor)
                                #UpdateQvalue(state,action, newQsa)
                                update_q_table(state, action, reward, nextstate, learning_rate,discountFactor)
                                state = nextstate
                                len_ +=1
                                #action = nextAction
                                if state[0] == "onAGV" and state[2]!= destNode and action == 5:
                                    break
                                if state[0] == sourceNode and state[2]!= sourceNode and action == 4:
                                    break
                                if isDone:
                                    break
                                #if len_ > trip_len:
                                    #break
                    print("train_complete")
                    list_po = []
                    Q = np.ones((1,4))
                    Q[0][2] =2
                    def teEpsilonGreadyPolicy(state, epsilon):
                        index = dictData["state"].index(state)
                        listAC = dictData["nextState"][index]
                        if np.random.uniform(low=0.0, high=1.0) < epsilon:
                            K = None
                            res = random.choice(list(filter(lambda ele: ele != K, listAC)))
                            list_po.append(listAC.index(res))
                        else:
                            maxAction = np.nanargmax(Q[0])
                            list_po.append(maxAction)
                    for i in range(100):
                        val = teEpsilonGreadyPolicy([76,79,15],0.8)
                    print(list_po)
                

  
                 
                    
                    #globalDistance = math.sqrt(math.pow((X_startNode - goalNode_X),2) + math.pow((Y_startNode - goalNode_Y),2))
                    

                


# def findAction(startID, endI)

    return render(request, "blog/LG_map.html", context)


@csrf_exempt
def LG_AGV_setting(request):
    SOC_Charge_database = SOC_charge.objects.all()
    Tranfer_database = Tranfer.objects.all()
    Parking_database = Parking.objects.all()
    Port_database = Port.objects.all()
    AGV_database = AGV_info.objects.all()
    AGV_info_ = AGV_status.objects.all()
    Tranfer_data_list = serializers.serialize('json', list(
        Tranfer_database), fields=('UseTranfer', 'UseAGV', 'CarrierType', 'AGV_ID', 'PortList'))
    Parking_data_list = serializers.serialize('json', list(
        Parking_database), fields=('AutoParking', 'Parking_Wait', 'AGV_ID',))
    SOC_Charge_list = serializers.serialize('json', list(SOC_Charge_database), fields=(
        'AutoCharge', 'ForceCharge', 'NormalCharge', 'StopCharge', 'MinCharge', 'AGV_ID'))
    Port_list = serializers.serialize('json', list(Port_database), fields=(
        'PORT_ID', 'PORT_name', 'Height', 'Width', 'CarrierType', 'Monitor_X', 'Monitor_Y', 'Direct', 'Node'))
    AGV_list = serializers.serialize('json', list(AGV_database),fields = ('AGV_ID', 'Name','Height','Width','Port', 'IP','Mode'))
    AGV_database = serializers.serialize("json", list(AGV_info_), fields=("id", "current_node", "current_link", "batvol", "batsoc", "moving", "arriving", "acquiring",
                                                                         "depositing", "charging", "manual", "down", "active", "havecmd", "canceled", "jobfinishied", "escapes", "loaded", "entermap",
                                                                         "charger_in_left", "charger_out_left", "charger_in_right", "charger_out_right", "East", "West", "North", "South",
                                                                         "Event", "dest_node", "X", "Y", "angle", "Width", "Height", "TimNorth", "TimSouth", "TimWest", "TimEast", "Error"))
    
    Send_database = {"Tranfer_data": Tranfer_data_list, "Port_data": Port_list,
                     "Parking_data": Parking_data_list, "SOC_Charge_data": SOC_Charge_list,"AGV_data":AGV_list, "AGV_status": AGV_database}
    if request.method == "POST":
        func = request.POST.get("func")
        if func == "AGV_setting":
            ID = int(request.POST.get("AGV_ID"))
            Database_name = request.POST.get("Database")
            Column_name = request.POST.get("Column")
            data = request.POST.get("Data")
            if Database_name == "SOC_Charge":
                try:
                    item = SOC_charge.objects.get(AGV_ID=ID)
                    # try:
                    if Column_name == "AutoCharge":
                        item.AutoCharge = convert_boolean(data)
                    elif Column_name == "ForceCharge":
                        item.ForceCharge = int(data)
                    elif Column_name == "NormalCharge":
                        item.NormalCharge = int(data)
                    elif Column_name == "StopCharge":
                        item.StopCharge = int(data)
                    elif Column_name == "MinCharge":
                        item.MinCharge = int(data)
                    item.save()
                    SOC_Charge_database = SOC_charge.objects.all()
                    SOC_Charge_list = serializers.serialize('json', list(SOC_Charge_database), fields=(
                        'AutoCharge', 'ForceCharge', 'NormalCharge', 'StopCharge', 'MinCharge', 'AGV_ID'))
                    return JsonResponse({'SOC_Charge_data': SOC_Charge_list})
                    # except:
                except:
                    print("Cannot find AGV with receive ID in SOC_charge")
            elif Database_name == "Tranfer":
                try:
                    item = Tranfer.objects.get(AGV_ID=ID)
                    try:
                        if Column_name == "UseTranfer":
                            item.UseTranfer = convert_boolean(data)
                        elif Column_name == "UseAGV":
                            item.UseAGV = convert_boolean(data)
                        elif Column_name == "CarrierType":
                            item.CarrierType = int(data)
                        elif Column_name == "Add_Port":
                            add_a_port = data
                            jsonDec = json.decoder.JSONDecoder()
                            PortList = jsonDec.decode(item.PortList)
                            if isinstance(PortList, list):
                                if(data in PortList):
                                    print("The Port have already exist")
                                else:
                                    PortList.append(data)
                            else:
                                PortList = []
                                PortList.append(data)
                            item.PortList = json.dumps(PortList)
                        elif Column_name == "Delete_Port":
                            jsonDec = json.decoder.JSONDecoder()
                            PortList = jsonDec.decode(item.PortList)
                            if (data in PortList):
                                PortList.remove(data)
                                item.PortList = json.dumps(PortList)
                            else:
                                print("the Port haven't yet add to list")
                        item.save()
                        Tranfer_database = Tranfer.objects.all()
                        Tranfer_data_list = serializers.serialize('json', list(
                            Tranfer_database), fields=('UseTranfer', 'UseAGV', 'CarrierType', 'AGV_ID', 'PortList'))
                        return JsonResponse({'Tranfer_data': Tranfer_data_list})
                    except:
                        print("false")
                except:
                    print("Cannot find AGV with receive ID in Tranfer")
            elif Database_name == "Parking":
                try:
                    item = Parking.objects.get(AGV_ID=ID)
                    try:
                        if Column_name == "AutoParking":
                            item.AutoParking = convert_boolean(data)
                        elif Column_name == "Parking_Wait":
                            item.Parking_Wait = int(data)
                        item.save()
                        Parking_database = Parking.objects.all()
                        Parking_data_list = serializers.serialize('json', list(
                            Parking_database), fields=('AutoParking', 'Parking_Wait', 'AGV_ID'))
                        return JsonResponse({'Parking_data': Parking_data_list})
                    except:
                        print("Cannot access the item of data")
                except:
                    print("Cannot find AGV with receive ID in Parking")
        elif func == "Port_setting":
            ID = int(request.POST.get("PORT_ID"))
            Database_name = request.POST.get("Database")
            Column_name = request.POST.get("Column")
            data = request.POST.get("Data")
            if Database_name == "Port":
                try:
                    item = Port.objects.get(PORT_ID = ID)
                    try:
                        if Column_name == "CarrierType":
                            item.CarrierType = data
                        elif Column_name == "Name":
                            item.PORT_name = data
                        elif Column_name == "Direct":
                            item.Direct = int(data)
                        item.save()
                        Port_database = Port.objects.all()
                        Port_list = serializers.serialize('json', list(Port_database), fields=(
                            'PORT_ID', 'PORT_name', 'Height', 'Width', 'CarrierType', 'Monitor_X', 'Monitor_Y', 'Direct', 'Node'))
                        return JsonResponse({'Port_data': Port_list})
                    except:
                        print("Cannot access the item of data")
                except:
                    print("Cannot find Port with receive ID")
                    
        elif func == "InfoAGV_create":
            AGV_ID = request.POST.get("AGV_ID")
            AGV_IP = request.POST.get("AGV_IP")
            AGV_Mode = request.POST.get("AGV_mode")
            AGV_Width = request.POST.get("AGV_width")
            AGV_Height = request.POST.get("AGV_height")
            AGV_Port = request.POST.get("AGV_port")
            AGV_Name = request.POST.get("AGV_name")
            listID = []
            for i in AGV_info.objects.all():
                listID.append(i.AGV_ID)
            print("data", listID)
            if int(AGV_ID) in listID:
                return JsonResponse({'Message': "The ID has already exist"})
            else:
                newAGV = AGV_info(AGV_ID = AGV_ID, Name = AGV_Name, Port = AGV_Port, Height = AGV_Height, Width = AGV_Width, Mode = AGV_Mode,IP =AGV_IP)
                newAGV.save()
                newSOC = SOC_charge(AGV_ID = AGV_ID, MinCharge = 50, StopCharge = 50, NormalCharge = 50, ForceCharge = 50, AutoCharge = True)
                newSOC.save()
                newPark = Parking(AGV_ID = AGV_ID, Parking_Wait = 50, AutoParking = False)
                newPark.save()
                defaultPort = []
                newTranfer = Tranfer(AGV_ID = AGV_ID, UseTranfer = True, UseAGV = True, CarrierType = 1, PortList = json.dumps(defaultPort))
                newTranfer.save()
                AGV_database = AGV_info.objects.all()
                AGV_list = serializers.serialize('json', list(AGV_database),fields = ('AGV_ID', 'Name','Height','Width','Port', 'IP','Mode'))
                return JsonResponse({'AGV_data': AGV_list,'Message': "Create new AGV completed"})
        elif func == "InfoAGV_modify":
            columnName = request.POST.get("Column")
            value = request.POST.get("Data")
            AGVID = request.POST.get("AGV_ID")
            AGVitem = AGV_info.objects.get(AGV_ID = int(AGVID))
            if columnName == "IP":
                AGVitem.IP = value
            elif columnName == "Name":
                AGVitem.Name = value
            elif columnName == "Port":
                AGVitem.Port = value
            elif columnName == "Height":
                AGVitem.Height = value
            elif columnName == "Width":
                AGVitem.Width = value
            elif columnName == "Mode":
                AGVitem.Mode = value
            elif columnName == "ID":
                AGVitem.AGV_ID = value
            AGVitem.save()
            AGV_database = AGV_info.objects.all()
            AGV_list = serializers.serialize('json', list(AGV_database),fields = ('AGV_ID', 'Name','Height','Width','Port', 'IP','Mode'))
            return JsonResponse({'AGV_data': AGV_list,'Message': "Change AGV data completed"})
        elif func == "InfoAGV_remove":
            AGVID = request.POST.get("AGV_ID")
            print("ID",AGVID)
            AGV_info.objects.filter(AGV_ID = AGVID).delete()
            Parking.objects.filter(AGV_ID = AGVID).delete()
            SOC_charge.objects.filter(AGV_ID = AGVID).delete()
            Tranfer.objects.filter(AGV_ID = AGVID).delete()
            AGV_database = AGV_info.objects.all()
            AGV_list = serializers.serialize('json', list(AGV_database),fields = ('AGV_ID', 'Name','Height','Width','Port', 'IP','Mode'))
            return JsonResponse({'AGV_data': AGV_list})

    return render(request, "blog/LG_setting.html", Send_database)
def Init_new_AGV_data(number_AGV):
    for i in range(number_AGV):
        if number_AGV > SOC_charge.objects.count():
            new_SOC_item = SOC_charge(
                AGV_ID=i, AutoCharge=True, ForceCharge=40, NormalCharge=50, StopCharge=50, MinCharge=50)
            new_Parking_item = Parking(
                AGV_ID=i, AutoParking=False, Parking_Wait=50)
            new_Tranfer_item = Tranfer(
                AGV_ID=i, UseTranfer=False, UseAGV=True, CarrierType=0)
            new_SOC_item.save()
            new_Parking_item.save()
            new_Tranfer_item.save()
@login_required
@csrf_exempt
def LG_display(request):
    nodes_data = Node_map_LG.objects.all()
    links_data = Link_map_LG.objects.all()
    AGV_info_ = AGV_status.objects.all()
    Port_database = Port.objects.all()
    LockZone_database = LockZone.objects.all()
    AGV_database = AGV_info.objects.all()
    port_list = serializers.serialize('json', list(Port_database), fields=(
        'PORT_ID', 'PORT_name', 'Height', 'Width', 'CarrierType', 'Monitor_X', 'Monitor_Y', 'Direct'))
    nodes_list = serializers.serialize('json', list(
        nodes_data), fields=('X', 'Y', 'TYPE', 'ID_NODE', 'TURN'))
    lockZone_list = serializers.serialize('json', list(
        LockZone_database), fields=('LockID', "Use", "ListNode"))
    initialData = {'height_image': height_image, 'width_image': width_image, 'map_ratio': mapScale, 'IP_domain': IP_domain, 'socketPort':socketPort}
    AGV_list = serializers.serialize('json', list(AGV_database),fields = ('AGV_ID', 'Name','Height','Width','Port', 'IP','Mode'))
    links_list = serializers.serialize('json', list(links_data), fields=(
        'ID_LINK', 'START', 'END', 'DIST', 'V', 'IR_F', 'IR_B', "IR_L", "IR_R", "NUM", "TYPE", "TURN", "DIR", "E_DIR", "FB", "V_DIR"))
    AGV_database = serializers.serialize("json", list(AGV_info_), fields=("id", "current_node", "current_link", "batvol", "batsoc", "moving", "arriving", "acquiring",
                                                                         "depositing", "charging", "manual", "down", "active", "havecmd", "canceled", "jobfinishied", "escapes", "loaded", "entermap",
                                                                         "charger_in_left", "charger_out_left", "charger_in_right", "charger_out_right", "East", "West", "North", "South",
                                                                         "Event", "dest_node", "X", "Y", "angle", "Width", "Height", "TimNorth", "TimSouth", "TimWest", "TimEast", "Error"))
    context = {'nodes_data': nodes_list, "links_data": links_list,
               'ports_data': port_list, "AGV_database": AGV_database, 'lockZone_data': lockZone_list,'AGV_data':AGV_list, 'initialData':json.dumps(initialData)}
    if request.method == 'POST':
        func = request.POST.get('func')
        if func == "Tranfer_command":
            AGV_ID = int(request.POST.get('AGV'))
            Source = request.POST.get('Source')
            Dest = request.POST.get("Dest")
            Carrier = "1111"
            Priority = 1
            new_tranfer = Manual_Tranfer(
                AGV_ID=AGV_ID, SOURCE=Source, DES=Dest, CARRIER=Carrier, PRI=Priority)
            new_tranfer.save()
            return JsonResponse({"Message": "done"})
        elif func == "Charge_command":
            AGV_ID = int(request.POST.get('ID'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.Charge = True
            AGV.save()
            newTran = tranlist(command=4, start=0, stop=0,
                               status=json.dump([0, 0, 0, 0]), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
        elif func == "Parking_command":
            AGV_ID = int(request.POST.get('ID'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.Parking = True
            AGV.save()
            newTran = tranlist(command=7, start=0, stop=0,
                               status=json.dumps([0, 0, 0, 0]), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
        elif func == "EMS_command":
            AGV_ID = int(request.POST.get('ID'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.EMS = True
            AGV.save()
            newTran = tranlist(command=8, start=0, stop=0,
                               status=json.dumps([0, 0, 0, 0]), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
        elif func == "Stop_command":
            AGV_ID = int(request.POST.get('ID'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.ChargeStop = True
            AGV.save()
            newTran = tranlist(command=6, start=0, stop=0,
                               status=json.dumps([0, 0, 0, 0]), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
        elif func == "Delete_command":
            AGV_ID = int(request.POST.get('ID'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.Delete = True
            AGV.save()
            return JsonResponse({"Message": "done"})
        elif func == "Turn_command":
            AGV_ID = int(request.POST.get('ID'))
            Angle = int(request.POST.get('Angle'))
            Direction = int(request.POST.get('direction'))
            AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            AGV.Angle = Angle
            AGV.Direction = Direction
            AGV.Turn = True
            AGV.save()
            angleStatus = [Angle + Direction, 0, 0, 0]
            # if (Angle == 1):
            #     angleStatus = [1, 0, 0, 0]
            # elif(Angle == 2):
            #     angleStatus = [0, 1, 0, 0]
            # elif(Angle == 3):
            #     angleStatus = [0, 0, 1, 0]
            # elif(Angle == 4):
            #     angleStatus = [0, 0, 0, 1]
            newTran = tranlist(command=5, start=0, stop=0,
                               status=json.dumps(angleStatus), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
        elif func == "Dest_command":
            AGV_ID = int(request.POST.get('ID'))
            Dest = int(request.POST.get('dest'))
            startNode = AGV_status.objects.get(id = AGV_ID)
            currentNode = startNode.current_node
            #AGV = Manual_Command.objects.get(AGV_ID=AGV_ID)
            #AGV.Dest = Dest
            #AGV.MOVING = True
            #AGV.save()
            newTran = tranlist(command=1, start=currentNode, stop=Dest,
                               status=json.dumps([0, 0, 0, 0]), agv=AGV_ID)
            newTran.save()
            return JsonResponse({"Message": "done"})
    return render(request, "blog/LG_display.html", context)


@csrf_exempt
def test_data(request):
    nodes_data = Node_map_LG.objects.all()
    nodes_list = serializers.serialize('json', list(
        nodes_data), fields=('X', 'Y', 'TYPE', 'ID_NODE', 'TURN'))
    context = {'nodes_data': nodes_list}
    if request.method == 'POST':
        func = request.POST.get('func')
        if func == "TAKEDATA":
            source = int(request.POST.get('SOURCE'))
            dest = int(request.POST.get('DEST'))
            start  = int(request.POST.get('START'))
            initialState = [source,dest,start]
            goal = [dest,dest,dest]
            def extractPolicy(initialState):
                policy = []
                state = []
                Index = dictData["state"].index(initialState)
                loop = 0
                while True:
                    loop += 1
                    action = np.nanargmax(Qtable[Index])
                    policy.append(action)
                    nextState = dictData["nextState"][Index][action]
                    Index = dictData["state"].index(nextState)
                    state.append((Index, action, nextState))
                    if nextState == goal or loop == 200:
                        break
                return policy,state
            policy,state = extractPolicy(initialState)
            np.savetxt('np.csv', Qtable, fmt='%.2f', delimiter=',', header=" #1,  #2,  #3,  #4, #5, #6")
            try:
                np.savetxt('state.csv',dictData["state"],fmt='%.2f', delimiter=',', header=" #status,  #dest,  #nodeID")
            except:
                pass
            print(policy)
    return render(request, "blog/test_dat.html", context)


Init_new_AGV_data(8)
