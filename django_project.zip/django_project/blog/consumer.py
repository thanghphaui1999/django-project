import json
# Import WebsocketConsumer
from channels.generic.websocket import WebsocketConsumer
# Import datetime module
from datetime import datetime
# Import  sleep module
from time import sleep
import logging



# Define the consumer class to send the data through WebsocketConsumer
class ws_consumer(WebsocketConsumer):
    def connect(self):
        self.accept()
        print('new client')
        logging.info("Success connet to ROS")
    
    def receive(self,text_data):
        try:
            text_data_json = json.loads(text_data)
            message = text_data_json['message']
            self.send(text_data=json.dumps({
            'message': message
            }))
        except:
           pass
    def disconnect(self,message):
        logging.info("Disconnect to ROS server")
    
        