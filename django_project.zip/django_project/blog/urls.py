from io import DEFAULT_BUFFER_SIZE
from django.urls import path
from . import views
urlpatterns = [
    path('',views.home, name = 'blog-home'),
    path('about/',views.about,name = 'blog-about'),
    path('dashboard/',views.Main_dashboard,name = "blog-dashoard"),
    path('map/',views.map, name = 'blog-map'),
    path('test/',views.test,name = 'blog-test'),
    path('controlAGV/', views.control_AGV, name = "blog-AGV" ),
    path('editmap',views.edit_map,name = "blog-editmap"),
    path('test_frame',views.test_frame,name = "blog-testframe"),
    path('mapping/', views.mapping, name = "blog-mapping"),
    path('editTool/',views.edittool, name = "blog-editTool"),
    path('movingAGV/',views.moving_AGV,name = "blog-movingAGV"),
    path('mapping_page/',views.mapping_page,name = "blog-mapping_page"),
    path('LG_map/',views.LG_map,name = "blog-LGmap"),
    path('LG_AGV_setting', views.LG_AGV_setting, name = "blog-AGV-setting"),
    path('LG_control',views.LG_display,name = "blog-LG-display"),
    path('test_data',views.test_data, name = "blog-TestData")

]












