from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import json
class Post(models.Model):
    title = models.CharField(max_length= 100)
    content = models.TextField()
    date_posted = models.DateTimeField(default = timezone.now)
    author = models.ForeignKey(User, on_delete = models.CASCADE)
    def __str__(self):
        return self.title
class Map(models.Model):
    name = models.CharField(max_length=100)
    content = models.TextField()
    date_posted = models.DateTimeField(default = timezone.now)
    author = models.ForeignKey(User, on_delete = models.CASCADE)
class Speed(models.Model):
    linear_x = models.FloatField()
    angular = models.FloatField()
    linear_y = models.FloatField()
    acceleration = models.FloatField()
class Map_area(models.Model):
    name = models.CharField(max_length = 100)
    posX = models.FloatField()
    posY = models.FloatField()
    quaZ = models.FloatField()
    quaW = models.FloatField()
class Map_save_name(models.Model):
    name = models.CharField(max_length = 100)
    path = models.FilePathField()
    map_height = models.IntegerField()
    map_width = models.IntegerField()
    resolution = models.FloatField()
    create_date = models.DateTimeField(default = timezone.now)
    username = models.CharField(max_length = 100)
    free_thresh = models.FloatField()
    occupied_thresh = models.FloatField()
    negate = models.FloatField()
class Map_save_name_complete(models.Model):
    name = models.CharField(max_length = 100)
    path = models.CharField(max_length = 120)
    map_height = models.IntegerField()
    map_width = models.IntegerField()
    resolution = models.FloatField()
    create_date = models.DateTimeField(default = timezone.now)
    username = models.CharField(max_length = 100)
    free_thresh = models.FloatField()
    occupied_thresh = models.FloatField()
    negate = models.FloatField()
class Node_map(models.Model):
    X = models.IntegerField()
    Y = models.IntegerField()
    TYPE = models.IntegerField()
    ID_NODE = models.IntegerField()
    TURN = models.IntegerField()
class Link_map(models.Model):
    
    ID_LINK = models.IntegerField()
    START = models.IntegerField()
    END = models.IntegerField()
    DIST = models.IntegerField()
    V = models.IntegerField()
    IR_F = models.BooleanField()
    IR_B = models.BooleanField()
    IR_L = models.BooleanField()
    IR_R = models.BooleanField()
    NUM = models.IntegerField()
    TYPE = models.IntegerField()
    TURN = models.IntegerField()
    DIR = models.IntegerField()
    E_DIR = models.IntegerField()
    FB = models.IntegerField()
    
    def set_lock(self,data):
        self.lock_AGV = json.dumps(data)
    def get_lock (self):
        return json.loads(self.lock_AGV)
class Node_map_LG(models.Model):
    X = models.IntegerField()
    Y = models.IntegerField()
    TYPE = models.IntegerField()
    ID_NODE = models.IntegerField()
    TURN = models.IntegerField()
class Link_map_LG(models.Model):
    ID_LINK = models.IntegerField()
    START = models.IntegerField()
    END = models.IntegerField()
    DIST = models.IntegerField()
    V = models.IntegerField()
    IR_F = models.BooleanField()
    IR_B = models.BooleanField()
    IR_L = models.BooleanField()
    IR_R = models.BooleanField()
    NUM = models.IntegerField()
    TYPE = models.IntegerField()
    TURN = models.IntegerField()
    DIR = models.IntegerField()
    E_DIR = models.IntegerField()
    FB = models.IntegerField()
    V_DIR = models.IntegerField(default = 4)
    Time = models.IntegerField(default = 0)
    
    def set_lock(self,data):
        self.lock_AGV = json.dumps(data)
    def get_lock (self):
        return json.loads(self.lock_AGV)
class SOC_charge(models.Model):
    AGV_ID = models.IntegerField(default=1)
    AutoCharge = models.BooleanField()
    ForceCharge = models.IntegerField()
    NormalCharge = models.IntegerField()
    StopCharge = models.IntegerField()
    MinCharge = models.IntegerField()
class Tranfer(models.Model):
    AGV_ID = models.IntegerField(default = 1)
    UseTranfer =  models.BooleanField()
    UseAGV = models.BooleanField()
    CarrierType = models.IntegerField()
    PortList = models.TextField(default = "0")
class Parking(models.Model):
    AGV_ID = models.IntegerField(default = 1)
    AutoParking = models.BooleanField()
    Parking_Wait = models.IntegerField()
class Port(models.Model):
    PORT_ID = models.IntegerField()
    PORT_name = models.CharField(max_length = 100)
    Height =  models.IntegerField()
    Width = models.IntegerField()
    CarrierType = models.CharField(max_length = 100)
    Monitor_X = models.IntegerField()
    Monitor_Y = models.IntegerField()
    Node = models.IntegerField(default = 1)
    #0:East
    #1:West
    #2:South
    #3:North
    #4:None
    Direct = models.IntegerField(default = 0)
class Manual_Tranfer(models.Model):
    AGV_ID = models.IntegerField()
    SOURCE = models.TextField(default = "PORT 1")
    DES = models.TextField(default = "PORT 1")
    CARRIER = models.CharField(max_length = 100)
    PRI = models.IntegerField()
class Manual_Command(models.Model):
    AGV_ID = models.IntegerField()
    Dest = models.IntegerField()
    Direction = models.IntegerField()
    Angle = models.IntegerField()
    EMS = models.BooleanField()
    Charge = models.BooleanField()
    ChargeStop = models.BooleanField()
    Parking = models.BooleanField()
    Delete = models.BooleanField()
    MOVING = models.BooleanField(default = False)
    TURN = models.BooleanField(default = False)
class AGV_info_test(models.Model):
    X = models.IntegerField()
    Y = models.IntegerField()
    AGV_ID = models.IntegerField()
    NAME = models.CharField(max_length = 100)
    WIDTH = models.FloatField(default = 2.5)
    HEIGHT = models.FloatField(default = 2.5)
    STATUS = models.IntegerField(default = 0)
class LockZone(models.Model):
    LockID = models.IntegerField()
    Use = models.BooleanField()
    ListNode = models.TextField()
class AGV_status(models.Model):
    current_node = models.IntegerField()
    current_link = models.IntegerField()
    batvol = models.IntegerField()
    batsoc = models.IntegerField()
    moving = models.BooleanField()
    arriving = models.BooleanField()
    acquiring = models.BooleanField()
    depositing = models.BooleanField()
    charging = models.BooleanField()
    manual = models.BooleanField()
    down = models.BooleanField()
    active = models.BooleanField()
    havecmd = models.BooleanField()
    canceled = models.BooleanField()
    jobfinishied = models.BooleanField()
    escapes = models.BooleanField()
    loaded = models.BooleanField()
    entermap = models.BooleanField()
    charger_in_left = models.BooleanField()
    charger_out_left = models.BooleanField() 
    charger_in_right = models.BooleanField()
    charger_out_right = models.BooleanField()
    East = models.BooleanField()
    West = models.BooleanField()
    South = models.BooleanField()
    North = models.BooleanField()
    Event = models.BooleanField()
    dest_node = models.IntegerField()
    X = models.IntegerField()
    Y = models.IntegerField()
    angle = models.IntegerField()
    map_version = models.IntegerField()
    node_around_path = models.TextField()
    node_safety = models.TextField(default = "0")
    nodes = models.TextField(default ="0")
    times = models.IntegerField(default = 0)
    link_path = models.TextField()
    link_safety = models.TextField()
    Height = models.FloatField(default = 1.5)
    Width = models.FloatField(default = 0.7)
    TimNorth = models.TextField(max_length = 4, default = "1_1")
    TimSouth = models.TextField(max_length = 4, default = "1_1")
    TimWest = models.TextField(max_length = 4, default = "1_1")
    TimEast = models.TextField(max_length = 4, default = "1_1")
    Error = models.TextField(default = "0")
class tranlist(models.Model):
    command = models.IntegerField()
    start = models.IntegerField()
    stop = models.IntegerField()
    status = models.TextField()
    agv = models.IntegerField()
class all_tranlist(models.Model):
    command = models.IntegerField()
    start = models.IntegerField()
    stop = models.IntegerField()
    status = models.TextField()
    agv = models.IntegerField()
class AGV_info(models.Model):
    AGV_ID = models.IntegerField()
    Name = models.CharField(max_length = 100)
    Height = models.FloatField()
    Width = models.FloatField()
    Port = models.IntegerField()
    IP = models.TextField(max_length =100)
    Mode = models.IntegerField()










    
    




















    
    



