


    




   





from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse, response
from django.http import JsonResponse
from django.core import serializers
from .models import Post
from .models import Map_area,Map_save_name_complete
import logging
import json
from json import dumps
import cv2
import numpy as np                                                                                  
import roslaunch
import signal
import threading
import yaml
import time
from .export_tools import create_image,yaml_process
import os
from .draw_map_func import draw_tool
import subprocess
logger = logging.getLogger(__name__)
uuid = roslaunch.rlutil.get_or_generate_uuid(None, False)
roslaunch.configure_logging(uuid)
cli_args1 = ['mir_navigation', 'start_planner.launch', 'map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml','virtual_walls_map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze_virtual_walls.yaml']
roslaunch_file1 = roslaunch.rlutil.resolve_launch_arguments(cli_args1)[0]
roslaunch_args1 = cli_args1[2:]
launch_files = [(roslaunch_file1, roslaunch_args1)]
parent = roslaunch.parent.ROSLaunchParent(uuid, launch_files)
state = True
save_map_dir = "/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps"
enable_map = True
cmd_runmap= ["roslaunch","mir_navigation","start_planner.launch","map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml","virtual_walls_map_file:=/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze_virtual_walls.yaml"]
proc_runmap = subprocess.Popen(cmd_runmap)
class database_map_modify():
    def __init__(self):
        pass
    def add_map(self,name, map_height, map_width, username, path):
        savemap = Map_save_name_complete(name = name, map_height = map_height, map_width = map_width, resolution = 0.05, occupied_thresh = 0.65, free_thresh = 0.196,negate = 0,username = username ,path = path)
        savemap.save()
    def remove_map(self,map_name):
        Map_save_name_complete.objects.filter(name = map_name).delete()
    def rename_map(self,old_name,new_name):
        Map_save_name_complete.objects.filter(name = old_name).update(name = new_name)
def run_launch():
    global state
    if state == True:
        parent.start()
    else:
        parent.shudown()
        state = True
#open_launch = threading.Thread(name = "run_launch", target = parent.start())
#open_launch.start()
# Create your views here.
posts = [{
    'title':"First blog",
    'content': "This blog is about the robot" ,
    'date_posted':"21-9-2021",
    'author': 'Thang'},
    {
    'title':"Second",
    'content':"This blog is about the fruits",
    'date_posted': "22-9-2021",
    'author':"Nam"
    },
    {
    'title':"Third",
    'content':'This is blog about the animal',
    'author':"Nhat",
    "date_posted": "20-8-2021"  
    }
    ]
def home(request):
    logger.error("Test!!")
    context = {'posts':Post.objects.all(),'title':'AGV','text': 'LinuxHint'}
    return render(request, 'blog/home.html',context)
def about(request):
    context = {'title': 'About '}
    return render(request, 'blog/about.html',context)
def Main_dashboard(request):
    context = {'title': 'Dashboard for  AGV'}
    return render(request, 'blog/main_dashboard.html',context)
def index(request):
    return render(request, 'blog/index.html', context={'text': 'LinuxHint'})
def map(request):
    context = {'title': 'map'}
    return render(request, 'blog/map_display.html',context)
def view3d(request):
    return render(request,'blog/show_3d_view.html')
def test(request):
    return render(request, 'blog/test.html')
def control_AGV(request):
    show_area = Map_area.objects.all()
    post_list = serializers.serialize('json',list(show_area),fields = ('name','posX','posY','quaZ','quaW'))
    context = {'data': post_list}
    return render(request, 'blog/complete_map.html',context)
@csrf_exempt
def mapping(request):
    if request.method == "POST":
        global enable_map
        cmd = ["roslaunch","mir_navigation","hector_mapping.launch"]
        proc = subprocess.Popen(cmd)
        func = request.POST.get("func")
        if func == "save_map":
            time.sleep(10)
            proc.terminate()
            #proc.send_signal(signal.SIGINT)
            #os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            
    return render(request, 'blog/mapping.html')
@csrf_exempt
def test_frame(request):
    if request.method == "POST":
        data_length = len(request.POST.getlist('case[]',[]))
        list_func = request.POST.getlist('case[]',[])
        list_point = request.POST.getlist('map_point[]',[])
        for i in range(2):
            data = request.POST.getlist(f'map_point[{i}][]') 
            for j in range(len(data)):
                print(data[j])
            
    return render(request,'blog/test_frame_data.html')
@csrf_exempt
def edit_map(request):
    map_database = Map_save_name_complete.objects.all()
    m_data = database_map_modify()
    post_list = serializers.serialize('json',list(map_database),fields = ('name','path','map_height','map_width','resolution','create_date','username','free_thresh','occupied_thresh','negate'))
    current_map = 'maze.png'
    map_yaml = yaml_process('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml')
    data = map_yaml.read_yaml()
    current_map = data['image']
    only_map_name = current_map.split('.')[0]
    context = {'data_map': post_list,"current_map": only_map_name}
    if request.method == 'POST':
        func = request.POST.getlist('func[]',[])
        #save new area data to server
        if func[0] == "load_map":
            map_name = request.POST.get('map_name')
            data['image'] = map_name + ".png"
            map_yaml.write_yaml(data) 
            image = cv2.imread('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + map_name + ".png")
        elif func[0] == "save_area":
            posX = []
            posY = []
            quaZ = []
            quaW = []
            name = []
            length = request.POST.get('dataSize')
            length = int(length)
            area_info = request.POST.getlist(f'AGV_info[]')
            for i in range(length):
                data = request.POST.getlist(f'AGV_info[{i}][]')
                posX.append(data[0])
                posY.append(data[1])
                quaZ.append(data[2])
                quaW.append(data[3])
                name.append(data[4])
                post_map_area = Map_area(name = data[4], posX = float(data[0]), posY = float(data[1]),quaZ = float(data[2]),quaW = float(data[3]))
                post_map_area.save()
            list_data = {"posX":posX,"posY":posY, "quaZ": quaZ,"quaW":quaW,"name": name}
            with open("/home/thang/catkin_ws/src/django_project/save_area.json","w") as fout:
                json.dump(list_data,fout)
        elif func[0] == "remove_map":
            map_name = request.POST.get('map_name')
            m_data.remove_map(map_name)
        elif func[0] == "rename_map":
            old_name = request.POST.get('map_name')
            new_name = request.POST.get('add_data')
            m_data.rename_map(old_name,new_name)
        else:
            print(func[0])
            global state
            name_map = request.POST.get("map_name")
            if name_map == '':
                name_map = 'maze.png'
            print("name of map",name_map)
            image = cv2.imread('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/'+ current_map)
            draw_on_map = draw_tool(image)
            for i in range (len(func)):
                data = request.POST.getlist(f'map_point[{i}][]')
                current_func = func[i]
                print(current_func)
                if current_func  == "1":
                    draw_on_map.draw_line(data)                
                elif current_func == "2":
                    draw_on_map.draw_circle(data)
                elif current_func == "3":             
                    draw_on_map.draw_rectangle(data)
                elif current_func == "4":
                    draw_on_map.draw_elipse(data)
                elif current_func == "5":
                    draw_on_map.draw_polygon(data)
                elif current_func == "0":
                    draw_on_map.delete_area(data)  
            cv2.imwrite("/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/" + name_map + ".png", image)
            preview_map = create_image.create_preview_image(image,200)
            cv2.imwrite("/home/thang/catkin_ws/src/django_project/blog/static/blog/assets/img/maps/preview_map/" + name_map + ".png", preview_map)
            path_map = "/static/blog/assets/img/maps/preview_map/" + name_map + ".png"
            m_data.add_map(name_map,image.shape[0],image.shape[1], 'Thang', path_map)
            data = map_yaml.read_yaml()
            data['image'] = name_map + ".png"
            map_yaml.write_yaml(data)
           
          
    return render(request,'blog/edit_map.html',context)

@csrf_exempt
def edittool(request):
    map_database = Map_save_name_complete.objects.all()
    area_database = Map_area.objects.all()
    area_list = serializers.serialize('json',list(area_database),fields = ('name','posX','posY','quaZ','quaW'))
    m_data = database_map_modify()
    post_list = serializers.serialize('json',list(map_database),fields = ('name','path','map_height','map_width','resolution','create_date','username'))
    current_map = 'maze.png'
    map_yaml = yaml_process('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/maze.yaml')
    data = map_yaml.read_yaml()
    current_map = data['image']
    only_map_name = current_map.split('.')[0]
    context = {'data_map': post_list,"current_map": only_map_name,"data_area": area_list}
    if request.method == 'POST':
        func = request.POST.getlist('func[]',[])
        #save new area data to server
        if func[0] == "load_map":
            map_name = request.POST.get('map_name')
            data['image'] = map_name + ".png"
            map_yaml.write_yaml(data) 
            image = cv2.imread('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/' + map_name + ".png")
            time.sleep(10)
            proc_runmap.terminate()
            
            
        elif func[0] == "save_area":
            posX = []
            posY = []
            quaZ = []
            quaW = []
            name = []
            length = request.POST.get('dataSize')
            length = int(length)
            area_info = request.POST.getlist(f'AGV_info[]')
            for i in range(length):
                data = request.POST.getlist(f'AGV_info[{i}][]')
                posX.append(data[0])
                posY.append(data[1])
                quaZ.append(data[2])
                quaW.append(data[3])
                name.append(data[4])
                post_map_area = Map_area(name = data[4], posX = float(data[0]), posY = float(data[1]),quaZ = float(data[2]),quaW = float(data[3]))
                post_map_area.save()
            list_data = {"posX":posX,"posY":posY, "quaZ": quaZ,"quaW":quaW,"name": name}
            with open("/home/thang/catkin_ws/src/django_project/save_area.json","w") as fout:
                json.dump(list_data,fout)
        elif func[0] == "remove_map":
            map_name = request.POST.get('map_name')
            m_data.remove_map(map_name)
        elif func[0] == "rename_map":
            old_name = request.POST.get('map_name')
            new_name = request.POST.get('add_data')
            print(old_name)
            print(new_name)
            m_data.rename_map(old_name,new_name)
        else:
            print(func[0])
            global state
            name_map = request.POST.get("map_name")
            if name_map == '':
                name_map = 'maze.png'
            print("name of map",name_map)
            image = cv2.imread('/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/'+ current_map)
            draw_on_map = draw_tool(image)
            for i in range (len(func)):
                data = request.POST.getlist(f'map_point[{i}][]')
                current_func = func[i]
                print(current_func)
                if current_func  == "1":
                    draw_on_map.draw_line(data)                
                elif current_func == "2":
                    draw_on_map.draw_circle(data)
                elif current_func == "3":             
                    draw_on_map.draw_rectangle(data)
                elif current_func == "4":
                    draw_on_map.draw_elipse(data)
                elif current_func == "5":
                    draw_on_map.draw_polygon(data)
                elif current_func == "0":
                    draw_on_map.delete_area(data)  
            cv2.imwrite("/home/thang/rtcrobot/src/mir_robot/mir_gazebo/maps/" + name_map + ".png", image)
            preview_map = create_image.create_preview_image(image,200)
            cv2.imwrite("/home/thang/catkin_ws/src/django_project/blog/static/blog/assets/img/maps/preview_map/" + name_map + ".png", preview_map)
            path_map = "/static/blog/assets/img/maps/preview_map/" + name_map + ".png"
            m_data.add_map(name_map,image.shape[0],image.shape[1], 'Thang', path_map)
            data = map_yaml.read_yaml()
            data['image'] = name_map + ".png"
            map_yaml.write_yaml(data)
            proc_runmap.kill()
           
            

            
    return render(request,'blog/edit_AGV_map.html',context)
def moving_AGV(request):
    show_area = Map_area.objects.all()
    post_list = serializers.serialize('json',list(show_area),fields = ('name','posX','posY','quaZ','quaW'))
    context = {'data': post_list}
    return render(request, 'blog/moving_AGV.html',context)
@csrf_exempt
def mapping_page(request):
    if request.method == "POST":
        global enable_map
        cmd_mapping = ["roslaunch","mir_navigation","hector_mapping.launch"]
        cmd_update_map = ["roslaunch","mir_navigation","save_map.launch"]
        proc = subprocess.Popen(cmd_mapping)
        proc_update_map = subprocess.Popen(cmd_update_map)
        func = request.POST.get("func")
        if func == "save_map":
            time.sleep(10)
            proc.terminate()
            proc_update_map.terminate()
    return render(request,'blog/mapping_page.html')


    




   






