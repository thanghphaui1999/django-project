import cv2
import numpy as np
class draw_tool():
    def __init__(self,image):
        self.image = image
    def draw_circle(self,data):
        center_x = int(data[0])
        center_y = int(data[1])
        width  = int(data[2])
        height = int(data[3])
        cv2.ellipse(self.image,(center_x,center_y),(width,height),0,0,360,(0,0,0),-1)
    def draw_rectangle(self,data):
        top_x = int(data[0])
        top_y = int(data[1])
        bottom_x = int(data[2])
        bottom_y = int(data[3])
        cv2.rectangle(self.image,(top_x,top_y),(bottom_x,bottom_y),(0,0,0),-1)
    def draw_polygon(self,data):
        all_point = []
        for j in range(0,len(data),2):
            x_val = int(data[j])
            y_val = int(data[j +1])
            all_point.append((x_val,y_val))
            all_point_array = np.array(all_point)
            cv2.fillPoly(self.image,[all_point_array],color = (0,0,0))
    def draw_elipse(self,data):
        center_x = int(data[0])
        center_y = int(data[1])
        width  = int(data[2])
        height = int(data[3])
        cv2.ellipse(self.image,(center_x,center_y),(width,height),0,0,360,(0,0,0),-1)
    def draw_line(self,data):
        start_point_x= int(data[0])
        start_point_y = int(data[1])
        end_point_x = int(data[2])
        end_point_y = int(data[3])
        thick_line  = int(data[4])
        cv2.line(self.image,(start_point_x,start_point_y),(end_point_x,end_point_y),(0,0,0),thick_line)
    def delete_area(self,data):
        all_point = []
        for j in range(0,len(data),2):
            x_val = int(data[j])
            y_val = int(data[j +1])
            all_point.append((x_val,y_val))             
            all_point_array = np.array(all_point)
            cv2.fillPoly(self.image,[all_point_array],color = (255,255,255))
        
        