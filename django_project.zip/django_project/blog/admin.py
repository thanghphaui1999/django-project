#from typing import _get_type_hints_obj_allowed_types
from django.contrib import admin
from .models import Post

# Register your models here.
admin.site.register(Post)
